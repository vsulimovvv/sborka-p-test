/******/ (function(modules) { // webpackBootstrap
/******/ 	function hotDisposeChunk(chunkId) {
/******/ 		delete installedChunks[chunkId];
/******/ 	}
/******/ 	var parentHotUpdateCallback = window["webpackHotUpdate"];
/******/ 	window["webpackHotUpdate"] = // eslint-disable-next-line no-unused-vars
/******/ 	function webpackHotUpdateCallback(chunkId, moreModules) {
/******/ 		hotAddUpdateChunk(chunkId, moreModules);
/******/ 		if (parentHotUpdateCallback) parentHotUpdateCallback(chunkId, moreModules);
/******/ 	} ;
/******/
/******/ 	// eslint-disable-next-line no-unused-vars
/******/ 	function hotDownloadUpdateChunk(chunkId) {
/******/ 		var script = document.createElement("script");
/******/ 		script.charset = "utf-8";
/******/ 		script.src = __webpack_require__.p + "" + chunkId + "." + hotCurrentHash + ".hot-update.js";
/******/ 		if (null) script.crossOrigin = null;
/******/ 		document.head.appendChild(script);
/******/ 	}
/******/
/******/ 	// eslint-disable-next-line no-unused-vars
/******/ 	function hotDownloadManifest(requestTimeout) {
/******/ 		requestTimeout = requestTimeout || 10000;
/******/ 		return new Promise(function(resolve, reject) {
/******/ 			if (typeof XMLHttpRequest === "undefined") {
/******/ 				return reject(new Error("No browser support"));
/******/ 			}
/******/ 			try {
/******/ 				var request = new XMLHttpRequest();
/******/ 				var requestPath = __webpack_require__.p + "" + hotCurrentHash + ".hot-update.json";
/******/ 				request.open("GET", requestPath, true);
/******/ 				request.timeout = requestTimeout;
/******/ 				request.send(null);
/******/ 			} catch (err) {
/******/ 				return reject(err);
/******/ 			}
/******/ 			request.onreadystatechange = function() {
/******/ 				if (request.readyState !== 4) return;
/******/ 				if (request.status === 0) {
/******/ 					// timeout
/******/ 					reject(
/******/ 						new Error("Manifest request to " + requestPath + " timed out.")
/******/ 					);
/******/ 				} else if (request.status === 404) {
/******/ 					// no update available
/******/ 					resolve();
/******/ 				} else if (request.status !== 200 && request.status !== 304) {
/******/ 					// other failure
/******/ 					reject(new Error("Manifest request to " + requestPath + " failed."));
/******/ 				} else {
/******/ 					// success
/******/ 					try {
/******/ 						var update = JSON.parse(request.responseText);
/******/ 					} catch (e) {
/******/ 						reject(e);
/******/ 						return;
/******/ 					}
/******/ 					resolve(update);
/******/ 				}
/******/ 			};
/******/ 		});
/******/ 	}
/******/
/******/ 	var hotApplyOnUpdate = true;
/******/ 	// eslint-disable-next-line no-unused-vars
/******/ 	var hotCurrentHash = "cea4bdbab87b8af6d29b";
/******/ 	var hotRequestTimeout = 10000;
/******/ 	var hotCurrentModuleData = {};
/******/ 	var hotCurrentChildModule;
/******/ 	// eslint-disable-next-line no-unused-vars
/******/ 	var hotCurrentParents = [];
/******/ 	// eslint-disable-next-line no-unused-vars
/******/ 	var hotCurrentParentsTemp = [];
/******/
/******/ 	// eslint-disable-next-line no-unused-vars
/******/ 	function hotCreateRequire(moduleId) {
/******/ 		var me = installedModules[moduleId];
/******/ 		if (!me) return __webpack_require__;
/******/ 		var fn = function(request) {
/******/ 			if (me.hot.active) {
/******/ 				if (installedModules[request]) {
/******/ 					if (installedModules[request].parents.indexOf(moduleId) === -1) {
/******/ 						installedModules[request].parents.push(moduleId);
/******/ 					}
/******/ 				} else {
/******/ 					hotCurrentParents = [moduleId];
/******/ 					hotCurrentChildModule = request;
/******/ 				}
/******/ 				if (me.children.indexOf(request) === -1) {
/******/ 					me.children.push(request);
/******/ 				}
/******/ 			} else {
/******/ 				console.warn(
/******/ 					"[HMR] unexpected require(" +
/******/ 						request +
/******/ 						") from disposed module " +
/******/ 						moduleId
/******/ 				);
/******/ 				hotCurrentParents = [];
/******/ 			}
/******/ 			return __webpack_require__(request);
/******/ 		};
/******/ 		var ObjectFactory = function ObjectFactory(name) {
/******/ 			return {
/******/ 				configurable: true,
/******/ 				enumerable: true,
/******/ 				get: function() {
/******/ 					return __webpack_require__[name];
/******/ 				},
/******/ 				set: function(value) {
/******/ 					__webpack_require__[name] = value;
/******/ 				}
/******/ 			};
/******/ 		};
/******/ 		for (var name in __webpack_require__) {
/******/ 			if (
/******/ 				Object.prototype.hasOwnProperty.call(__webpack_require__, name) &&
/******/ 				name !== "e" &&
/******/ 				name !== "t"
/******/ 			) {
/******/ 				Object.defineProperty(fn, name, ObjectFactory(name));
/******/ 			}
/******/ 		}
/******/ 		fn.e = function(chunkId) {
/******/ 			if (hotStatus === "ready") hotSetStatus("prepare");
/******/ 			hotChunksLoading++;
/******/ 			return __webpack_require__.e(chunkId).then(finishChunkLoading, function(err) {
/******/ 				finishChunkLoading();
/******/ 				throw err;
/******/ 			});
/******/
/******/ 			function finishChunkLoading() {
/******/ 				hotChunksLoading--;
/******/ 				if (hotStatus === "prepare") {
/******/ 					if (!hotWaitingFilesMap[chunkId]) {
/******/ 						hotEnsureUpdateChunk(chunkId);
/******/ 					}
/******/ 					if (hotChunksLoading === 0 && hotWaitingFiles === 0) {
/******/ 						hotUpdateDownloaded();
/******/ 					}
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 		fn.t = function(value, mode) {
/******/ 			if (mode & 1) value = fn(value);
/******/ 			return __webpack_require__.t(value, mode & ~1);
/******/ 		};
/******/ 		return fn;
/******/ 	}
/******/
/******/ 	// eslint-disable-next-line no-unused-vars
/******/ 	function hotCreateModule(moduleId) {
/******/ 		var hot = {
/******/ 			// private stuff
/******/ 			_acceptedDependencies: {},
/******/ 			_declinedDependencies: {},
/******/ 			_selfAccepted: false,
/******/ 			_selfDeclined: false,
/******/ 			_selfInvalidated: false,
/******/ 			_disposeHandlers: [],
/******/ 			_main: hotCurrentChildModule !== moduleId,
/******/
/******/ 			// Module API
/******/ 			active: true,
/******/ 			accept: function(dep, callback) {
/******/ 				if (dep === undefined) hot._selfAccepted = true;
/******/ 				else if (typeof dep === "function") hot._selfAccepted = dep;
/******/ 				else if (typeof dep === "object")
/******/ 					for (var i = 0; i < dep.length; i++)
/******/ 						hot._acceptedDependencies[dep[i]] = callback || function() {};
/******/ 				else hot._acceptedDependencies[dep] = callback || function() {};
/******/ 			},
/******/ 			decline: function(dep) {
/******/ 				if (dep === undefined) hot._selfDeclined = true;
/******/ 				else if (typeof dep === "object")
/******/ 					for (var i = 0; i < dep.length; i++)
/******/ 						hot._declinedDependencies[dep[i]] = true;
/******/ 				else hot._declinedDependencies[dep] = true;
/******/ 			},
/******/ 			dispose: function(callback) {
/******/ 				hot._disposeHandlers.push(callback);
/******/ 			},
/******/ 			addDisposeHandler: function(callback) {
/******/ 				hot._disposeHandlers.push(callback);
/******/ 			},
/******/ 			removeDisposeHandler: function(callback) {
/******/ 				var idx = hot._disposeHandlers.indexOf(callback);
/******/ 				if (idx >= 0) hot._disposeHandlers.splice(idx, 1);
/******/ 			},
/******/ 			invalidate: function() {
/******/ 				this._selfInvalidated = true;
/******/ 				switch (hotStatus) {
/******/ 					case "idle":
/******/ 						hotUpdate = {};
/******/ 						hotUpdate[moduleId] = modules[moduleId];
/******/ 						hotSetStatus("ready");
/******/ 						break;
/******/ 					case "ready":
/******/ 						hotApplyInvalidatedModule(moduleId);
/******/ 						break;
/******/ 					case "prepare":
/******/ 					case "check":
/******/ 					case "dispose":
/******/ 					case "apply":
/******/ 						(hotQueuedInvalidatedModules =
/******/ 							hotQueuedInvalidatedModules || []).push(moduleId);
/******/ 						break;
/******/ 					default:
/******/ 						// ignore requests in error states
/******/ 						break;
/******/ 				}
/******/ 			},
/******/
/******/ 			// Management API
/******/ 			check: hotCheck,
/******/ 			apply: hotApply,
/******/ 			status: function(l) {
/******/ 				if (!l) return hotStatus;
/******/ 				hotStatusHandlers.push(l);
/******/ 			},
/******/ 			addStatusHandler: function(l) {
/******/ 				hotStatusHandlers.push(l);
/******/ 			},
/******/ 			removeStatusHandler: function(l) {
/******/ 				var idx = hotStatusHandlers.indexOf(l);
/******/ 				if (idx >= 0) hotStatusHandlers.splice(idx, 1);
/******/ 			},
/******/
/******/ 			//inherit from previous dispose call
/******/ 			data: hotCurrentModuleData[moduleId]
/******/ 		};
/******/ 		hotCurrentChildModule = undefined;
/******/ 		return hot;
/******/ 	}
/******/
/******/ 	var hotStatusHandlers = [];
/******/ 	var hotStatus = "idle";
/******/
/******/ 	function hotSetStatus(newStatus) {
/******/ 		hotStatus = newStatus;
/******/ 		for (var i = 0; i < hotStatusHandlers.length; i++)
/******/ 			hotStatusHandlers[i].call(null, newStatus);
/******/ 	}
/******/
/******/ 	// while downloading
/******/ 	var hotWaitingFiles = 0;
/******/ 	var hotChunksLoading = 0;
/******/ 	var hotWaitingFilesMap = {};
/******/ 	var hotRequestedFilesMap = {};
/******/ 	var hotAvailableFilesMap = {};
/******/ 	var hotDeferred;
/******/
/******/ 	// The update info
/******/ 	var hotUpdate, hotUpdateNewHash, hotQueuedInvalidatedModules;
/******/
/******/ 	function toModuleId(id) {
/******/ 		var isNumber = +id + "" === id;
/******/ 		return isNumber ? +id : id;
/******/ 	}
/******/
/******/ 	function hotCheck(apply) {
/******/ 		if (hotStatus !== "idle") {
/******/ 			throw new Error("check() is only allowed in idle status");
/******/ 		}
/******/ 		hotApplyOnUpdate = apply;
/******/ 		hotSetStatus("check");
/******/ 		return hotDownloadManifest(hotRequestTimeout).then(function(update) {
/******/ 			if (!update) {
/******/ 				hotSetStatus(hotApplyInvalidatedModules() ? "ready" : "idle");
/******/ 				return null;
/******/ 			}
/******/ 			hotRequestedFilesMap = {};
/******/ 			hotWaitingFilesMap = {};
/******/ 			hotAvailableFilesMap = update.c;
/******/ 			hotUpdateNewHash = update.h;
/******/
/******/ 			hotSetStatus("prepare");
/******/ 			var promise = new Promise(function(resolve, reject) {
/******/ 				hotDeferred = {
/******/ 					resolve: resolve,
/******/ 					reject: reject
/******/ 				};
/******/ 			});
/******/ 			hotUpdate = {};
/******/ 			var chunkId = "bundle";
/******/ 			// eslint-disable-next-line no-lone-blocks
/******/ 			{
/******/ 				hotEnsureUpdateChunk(chunkId);
/******/ 			}
/******/ 			if (
/******/ 				hotStatus === "prepare" &&
/******/ 				hotChunksLoading === 0 &&
/******/ 				hotWaitingFiles === 0
/******/ 			) {
/******/ 				hotUpdateDownloaded();
/******/ 			}
/******/ 			return promise;
/******/ 		});
/******/ 	}
/******/
/******/ 	// eslint-disable-next-line no-unused-vars
/******/ 	function hotAddUpdateChunk(chunkId, moreModules) {
/******/ 		if (!hotAvailableFilesMap[chunkId] || !hotRequestedFilesMap[chunkId])
/******/ 			return;
/******/ 		hotRequestedFilesMap[chunkId] = false;
/******/ 		for (var moduleId in moreModules) {
/******/ 			if (Object.prototype.hasOwnProperty.call(moreModules, moduleId)) {
/******/ 				hotUpdate[moduleId] = moreModules[moduleId];
/******/ 			}
/******/ 		}
/******/ 		if (--hotWaitingFiles === 0 && hotChunksLoading === 0) {
/******/ 			hotUpdateDownloaded();
/******/ 		}
/******/ 	}
/******/
/******/ 	function hotEnsureUpdateChunk(chunkId) {
/******/ 		if (!hotAvailableFilesMap[chunkId]) {
/******/ 			hotWaitingFilesMap[chunkId] = true;
/******/ 		} else {
/******/ 			hotRequestedFilesMap[chunkId] = true;
/******/ 			hotWaitingFiles++;
/******/ 			hotDownloadUpdateChunk(chunkId);
/******/ 		}
/******/ 	}
/******/
/******/ 	function hotUpdateDownloaded() {
/******/ 		hotSetStatus("ready");
/******/ 		var deferred = hotDeferred;
/******/ 		hotDeferred = null;
/******/ 		if (!deferred) return;
/******/ 		if (hotApplyOnUpdate) {
/******/ 			// Wrap deferred object in Promise to mark it as a well-handled Promise to
/******/ 			// avoid triggering uncaught exception warning in Chrome.
/******/ 			// See https://bugs.chromium.org/p/chromium/issues/detail?id=465666
/******/ 			Promise.resolve()
/******/ 				.then(function() {
/******/ 					return hotApply(hotApplyOnUpdate);
/******/ 				})
/******/ 				.then(
/******/ 					function(result) {
/******/ 						deferred.resolve(result);
/******/ 					},
/******/ 					function(err) {
/******/ 						deferred.reject(err);
/******/ 					}
/******/ 				);
/******/ 		} else {
/******/ 			var outdatedModules = [];
/******/ 			for (var id in hotUpdate) {
/******/ 				if (Object.prototype.hasOwnProperty.call(hotUpdate, id)) {
/******/ 					outdatedModules.push(toModuleId(id));
/******/ 				}
/******/ 			}
/******/ 			deferred.resolve(outdatedModules);
/******/ 		}
/******/ 	}
/******/
/******/ 	function hotApply(options) {
/******/ 		if (hotStatus !== "ready")
/******/ 			throw new Error("apply() is only allowed in ready status");
/******/ 		options = options || {};
/******/ 		return hotApplyInternal(options);
/******/ 	}
/******/
/******/ 	function hotApplyInternal(options) {
/******/ 		hotApplyInvalidatedModules();
/******/
/******/ 		var cb;
/******/ 		var i;
/******/ 		var j;
/******/ 		var module;
/******/ 		var moduleId;
/******/
/******/ 		function getAffectedStuff(updateModuleId) {
/******/ 			var outdatedModules = [updateModuleId];
/******/ 			var outdatedDependencies = {};
/******/
/******/ 			var queue = outdatedModules.map(function(id) {
/******/ 				return {
/******/ 					chain: [id],
/******/ 					id: id
/******/ 				};
/******/ 			});
/******/ 			while (queue.length > 0) {
/******/ 				var queueItem = queue.pop();
/******/ 				var moduleId = queueItem.id;
/******/ 				var chain = queueItem.chain;
/******/ 				module = installedModules[moduleId];
/******/ 				if (
/******/ 					!module ||
/******/ 					(module.hot._selfAccepted && !module.hot._selfInvalidated)
/******/ 				)
/******/ 					continue;
/******/ 				if (module.hot._selfDeclined) {
/******/ 					return {
/******/ 						type: "self-declined",
/******/ 						chain: chain,
/******/ 						moduleId: moduleId
/******/ 					};
/******/ 				}
/******/ 				if (module.hot._main) {
/******/ 					return {
/******/ 						type: "unaccepted",
/******/ 						chain: chain,
/******/ 						moduleId: moduleId
/******/ 					};
/******/ 				}
/******/ 				for (var i = 0; i < module.parents.length; i++) {
/******/ 					var parentId = module.parents[i];
/******/ 					var parent = installedModules[parentId];
/******/ 					if (!parent) continue;
/******/ 					if (parent.hot._declinedDependencies[moduleId]) {
/******/ 						return {
/******/ 							type: "declined",
/******/ 							chain: chain.concat([parentId]),
/******/ 							moduleId: moduleId,
/******/ 							parentId: parentId
/******/ 						};
/******/ 					}
/******/ 					if (outdatedModules.indexOf(parentId) !== -1) continue;
/******/ 					if (parent.hot._acceptedDependencies[moduleId]) {
/******/ 						if (!outdatedDependencies[parentId])
/******/ 							outdatedDependencies[parentId] = [];
/******/ 						addAllToSet(outdatedDependencies[parentId], [moduleId]);
/******/ 						continue;
/******/ 					}
/******/ 					delete outdatedDependencies[parentId];
/******/ 					outdatedModules.push(parentId);
/******/ 					queue.push({
/******/ 						chain: chain.concat([parentId]),
/******/ 						id: parentId
/******/ 					});
/******/ 				}
/******/ 			}
/******/
/******/ 			return {
/******/ 				type: "accepted",
/******/ 				moduleId: updateModuleId,
/******/ 				outdatedModules: outdatedModules,
/******/ 				outdatedDependencies: outdatedDependencies
/******/ 			};
/******/ 		}
/******/
/******/ 		function addAllToSet(a, b) {
/******/ 			for (var i = 0; i < b.length; i++) {
/******/ 				var item = b[i];
/******/ 				if (a.indexOf(item) === -1) a.push(item);
/******/ 			}
/******/ 		}
/******/
/******/ 		// at begin all updates modules are outdated
/******/ 		// the "outdated" status can propagate to parents if they don't accept the children
/******/ 		var outdatedDependencies = {};
/******/ 		var outdatedModules = [];
/******/ 		var appliedUpdate = {};
/******/
/******/ 		var warnUnexpectedRequire = function warnUnexpectedRequire() {
/******/ 			console.warn(
/******/ 				"[HMR] unexpected require(" + result.moduleId + ") to disposed module"
/******/ 			);
/******/ 		};
/******/
/******/ 		for (var id in hotUpdate) {
/******/ 			if (Object.prototype.hasOwnProperty.call(hotUpdate, id)) {
/******/ 				moduleId = toModuleId(id);
/******/ 				/** @type {TODO} */
/******/ 				var result;
/******/ 				if (hotUpdate[id]) {
/******/ 					result = getAffectedStuff(moduleId);
/******/ 				} else {
/******/ 					result = {
/******/ 						type: "disposed",
/******/ 						moduleId: id
/******/ 					};
/******/ 				}
/******/ 				/** @type {Error|false} */
/******/ 				var abortError = false;
/******/ 				var doApply = false;
/******/ 				var doDispose = false;
/******/ 				var chainInfo = "";
/******/ 				if (result.chain) {
/******/ 					chainInfo = "\nUpdate propagation: " + result.chain.join(" -> ");
/******/ 				}
/******/ 				switch (result.type) {
/******/ 					case "self-declined":
/******/ 						if (options.onDeclined) options.onDeclined(result);
/******/ 						if (!options.ignoreDeclined)
/******/ 							abortError = new Error(
/******/ 								"Aborted because of self decline: " +
/******/ 									result.moduleId +
/******/ 									chainInfo
/******/ 							);
/******/ 						break;
/******/ 					case "declined":
/******/ 						if (options.onDeclined) options.onDeclined(result);
/******/ 						if (!options.ignoreDeclined)
/******/ 							abortError = new Error(
/******/ 								"Aborted because of declined dependency: " +
/******/ 									result.moduleId +
/******/ 									" in " +
/******/ 									result.parentId +
/******/ 									chainInfo
/******/ 							);
/******/ 						break;
/******/ 					case "unaccepted":
/******/ 						if (options.onUnaccepted) options.onUnaccepted(result);
/******/ 						if (!options.ignoreUnaccepted)
/******/ 							abortError = new Error(
/******/ 								"Aborted because " + moduleId + " is not accepted" + chainInfo
/******/ 							);
/******/ 						break;
/******/ 					case "accepted":
/******/ 						if (options.onAccepted) options.onAccepted(result);
/******/ 						doApply = true;
/******/ 						break;
/******/ 					case "disposed":
/******/ 						if (options.onDisposed) options.onDisposed(result);
/******/ 						doDispose = true;
/******/ 						break;
/******/ 					default:
/******/ 						throw new Error("Unexception type " + result.type);
/******/ 				}
/******/ 				if (abortError) {
/******/ 					hotSetStatus("abort");
/******/ 					return Promise.reject(abortError);
/******/ 				}
/******/ 				if (doApply) {
/******/ 					appliedUpdate[moduleId] = hotUpdate[moduleId];
/******/ 					addAllToSet(outdatedModules, result.outdatedModules);
/******/ 					for (moduleId in result.outdatedDependencies) {
/******/ 						if (
/******/ 							Object.prototype.hasOwnProperty.call(
/******/ 								result.outdatedDependencies,
/******/ 								moduleId
/******/ 							)
/******/ 						) {
/******/ 							if (!outdatedDependencies[moduleId])
/******/ 								outdatedDependencies[moduleId] = [];
/******/ 							addAllToSet(
/******/ 								outdatedDependencies[moduleId],
/******/ 								result.outdatedDependencies[moduleId]
/******/ 							);
/******/ 						}
/******/ 					}
/******/ 				}
/******/ 				if (doDispose) {
/******/ 					addAllToSet(outdatedModules, [result.moduleId]);
/******/ 					appliedUpdate[moduleId] = warnUnexpectedRequire;
/******/ 				}
/******/ 			}
/******/ 		}
/******/
/******/ 		// Store self accepted outdated modules to require them later by the module system
/******/ 		var outdatedSelfAcceptedModules = [];
/******/ 		for (i = 0; i < outdatedModules.length; i++) {
/******/ 			moduleId = outdatedModules[i];
/******/ 			if (
/******/ 				installedModules[moduleId] &&
/******/ 				installedModules[moduleId].hot._selfAccepted &&
/******/ 				// removed self-accepted modules should not be required
/******/ 				appliedUpdate[moduleId] !== warnUnexpectedRequire &&
/******/ 				// when called invalidate self-accepting is not possible
/******/ 				!installedModules[moduleId].hot._selfInvalidated
/******/ 			) {
/******/ 				outdatedSelfAcceptedModules.push({
/******/ 					module: moduleId,
/******/ 					parents: installedModules[moduleId].parents.slice(),
/******/ 					errorHandler: installedModules[moduleId].hot._selfAccepted
/******/ 				});
/******/ 			}
/******/ 		}
/******/
/******/ 		// Now in "dispose" phase
/******/ 		hotSetStatus("dispose");
/******/ 		Object.keys(hotAvailableFilesMap).forEach(function(chunkId) {
/******/ 			if (hotAvailableFilesMap[chunkId] === false) {
/******/ 				hotDisposeChunk(chunkId);
/******/ 			}
/******/ 		});
/******/
/******/ 		var idx;
/******/ 		var queue = outdatedModules.slice();
/******/ 		while (queue.length > 0) {
/******/ 			moduleId = queue.pop();
/******/ 			module = installedModules[moduleId];
/******/ 			if (!module) continue;
/******/
/******/ 			var data = {};
/******/
/******/ 			// Call dispose handlers
/******/ 			var disposeHandlers = module.hot._disposeHandlers;
/******/ 			for (j = 0; j < disposeHandlers.length; j++) {
/******/ 				cb = disposeHandlers[j];
/******/ 				cb(data);
/******/ 			}
/******/ 			hotCurrentModuleData[moduleId] = data;
/******/
/******/ 			// disable module (this disables requires from this module)
/******/ 			module.hot.active = false;
/******/
/******/ 			// remove module from cache
/******/ 			delete installedModules[moduleId];
/******/
/******/ 			// when disposing there is no need to call dispose handler
/******/ 			delete outdatedDependencies[moduleId];
/******/
/******/ 			// remove "parents" references from all children
/******/ 			for (j = 0; j < module.children.length; j++) {
/******/ 				var child = installedModules[module.children[j]];
/******/ 				if (!child) continue;
/******/ 				idx = child.parents.indexOf(moduleId);
/******/ 				if (idx >= 0) {
/******/ 					child.parents.splice(idx, 1);
/******/ 				}
/******/ 			}
/******/ 		}
/******/
/******/ 		// remove outdated dependency from module children
/******/ 		var dependency;
/******/ 		var moduleOutdatedDependencies;
/******/ 		for (moduleId in outdatedDependencies) {
/******/ 			if (
/******/ 				Object.prototype.hasOwnProperty.call(outdatedDependencies, moduleId)
/******/ 			) {
/******/ 				module = installedModules[moduleId];
/******/ 				if (module) {
/******/ 					moduleOutdatedDependencies = outdatedDependencies[moduleId];
/******/ 					for (j = 0; j < moduleOutdatedDependencies.length; j++) {
/******/ 						dependency = moduleOutdatedDependencies[j];
/******/ 						idx = module.children.indexOf(dependency);
/******/ 						if (idx >= 0) module.children.splice(idx, 1);
/******/ 					}
/******/ 				}
/******/ 			}
/******/ 		}
/******/
/******/ 		// Now in "apply" phase
/******/ 		hotSetStatus("apply");
/******/
/******/ 		if (hotUpdateNewHash !== undefined) {
/******/ 			hotCurrentHash = hotUpdateNewHash;
/******/ 			hotUpdateNewHash = undefined;
/******/ 		}
/******/ 		hotUpdate = undefined;
/******/
/******/ 		// insert new code
/******/ 		for (moduleId in appliedUpdate) {
/******/ 			if (Object.prototype.hasOwnProperty.call(appliedUpdate, moduleId)) {
/******/ 				modules[moduleId] = appliedUpdate[moduleId];
/******/ 			}
/******/ 		}
/******/
/******/ 		// call accept handlers
/******/ 		var error = null;
/******/ 		for (moduleId in outdatedDependencies) {
/******/ 			if (
/******/ 				Object.prototype.hasOwnProperty.call(outdatedDependencies, moduleId)
/******/ 			) {
/******/ 				module = installedModules[moduleId];
/******/ 				if (module) {
/******/ 					moduleOutdatedDependencies = outdatedDependencies[moduleId];
/******/ 					var callbacks = [];
/******/ 					for (i = 0; i < moduleOutdatedDependencies.length; i++) {
/******/ 						dependency = moduleOutdatedDependencies[i];
/******/ 						cb = module.hot._acceptedDependencies[dependency];
/******/ 						if (cb) {
/******/ 							if (callbacks.indexOf(cb) !== -1) continue;
/******/ 							callbacks.push(cb);
/******/ 						}
/******/ 					}
/******/ 					for (i = 0; i < callbacks.length; i++) {
/******/ 						cb = callbacks[i];
/******/ 						try {
/******/ 							cb(moduleOutdatedDependencies);
/******/ 						} catch (err) {
/******/ 							if (options.onErrored) {
/******/ 								options.onErrored({
/******/ 									type: "accept-errored",
/******/ 									moduleId: moduleId,
/******/ 									dependencyId: moduleOutdatedDependencies[i],
/******/ 									error: err
/******/ 								});
/******/ 							}
/******/ 							if (!options.ignoreErrored) {
/******/ 								if (!error) error = err;
/******/ 							}
/******/ 						}
/******/ 					}
/******/ 				}
/******/ 			}
/******/ 		}
/******/
/******/ 		// Load self accepted modules
/******/ 		for (i = 0; i < outdatedSelfAcceptedModules.length; i++) {
/******/ 			var item = outdatedSelfAcceptedModules[i];
/******/ 			moduleId = item.module;
/******/ 			hotCurrentParents = item.parents;
/******/ 			hotCurrentChildModule = moduleId;
/******/ 			try {
/******/ 				__webpack_require__(moduleId);
/******/ 			} catch (err) {
/******/ 				if (typeof item.errorHandler === "function") {
/******/ 					try {
/******/ 						item.errorHandler(err);
/******/ 					} catch (err2) {
/******/ 						if (options.onErrored) {
/******/ 							options.onErrored({
/******/ 								type: "self-accept-error-handler-errored",
/******/ 								moduleId: moduleId,
/******/ 								error: err2,
/******/ 								originalError: err
/******/ 							});
/******/ 						}
/******/ 						if (!options.ignoreErrored) {
/******/ 							if (!error) error = err2;
/******/ 						}
/******/ 						if (!error) error = err;
/******/ 					}
/******/ 				} else {
/******/ 					if (options.onErrored) {
/******/ 						options.onErrored({
/******/ 							type: "self-accept-errored",
/******/ 							moduleId: moduleId,
/******/ 							error: err
/******/ 						});
/******/ 					}
/******/ 					if (!options.ignoreErrored) {
/******/ 						if (!error) error = err;
/******/ 					}
/******/ 				}
/******/ 			}
/******/ 		}
/******/
/******/ 		// handle errors in accept handlers and self accepted module load
/******/ 		if (error) {
/******/ 			hotSetStatus("fail");
/******/ 			return Promise.reject(error);
/******/ 		}
/******/
/******/ 		if (hotQueuedInvalidatedModules) {
/******/ 			return hotApplyInternal(options).then(function(list) {
/******/ 				outdatedModules.forEach(function(moduleId) {
/******/ 					if (list.indexOf(moduleId) < 0) list.push(moduleId);
/******/ 				});
/******/ 				return list;
/******/ 			});
/******/ 		}
/******/
/******/ 		hotSetStatus("idle");
/******/ 		return new Promise(function(resolve) {
/******/ 			resolve(outdatedModules);
/******/ 		});
/******/ 	}
/******/
/******/ 	function hotApplyInvalidatedModules() {
/******/ 		if (hotQueuedInvalidatedModules) {
/******/ 			if (!hotUpdate) hotUpdate = {};
/******/ 			hotQueuedInvalidatedModules.forEach(hotApplyInvalidatedModule);
/******/ 			hotQueuedInvalidatedModules = undefined;
/******/ 			return true;
/******/ 		}
/******/ 	}
/******/
/******/ 	function hotApplyInvalidatedModule(moduleId) {
/******/ 		if (!Object.prototype.hasOwnProperty.call(hotUpdate, moduleId))
/******/ 			hotUpdate[moduleId] = modules[moduleId];
/******/ 	}
/******/
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {},
/******/ 			hot: hotCreateModule(moduleId),
/******/ 			parents: (hotCurrentParentsTemp = hotCurrentParents, hotCurrentParents = [], hotCurrentParentsTemp),
/******/ 			children: []
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, hotCreateRequire(moduleId));
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/assets/js";
/******/
/******/ 	// __webpack_hash__
/******/ 	__webpack_require__.h = function() { return hotCurrentHash; };
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return hotCreateRequire(0)(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ({

/***/ "./node_modules/ansi-html-community/index.js":
/*!***************************************************!*\
  !*** ./node_modules/ansi-html-community/index.js ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nmodule.exports = ansiHTML\n\n// Reference to https://github.com/sindresorhus/ansi-regex\nvar _regANSI = /(?:(?:\\u001b\\[)|\\u009b)(?:(?:[0-9]{1,3})?(?:(?:;[0-9]{0,3})*)?[A-M|f-m])|\\u001b[A-M]/\n\nvar _defColors = {\n  reset: ['fff', '000'], // [FOREGROUD_COLOR, BACKGROUND_COLOR]\n  black: '000',\n  red: 'ff0000',\n  green: '209805',\n  yellow: 'e8bf03',\n  blue: '0000ff',\n  magenta: 'ff00ff',\n  cyan: '00ffee',\n  lightgrey: 'f0f0f0',\n  darkgrey: '888'\n}\nvar _styles = {\n  30: 'black',\n  31: 'red',\n  32: 'green',\n  33: 'yellow',\n  34: 'blue',\n  35: 'magenta',\n  36: 'cyan',\n  37: 'lightgrey'\n}\nvar _openTags = {\n  '1': 'font-weight:bold', // bold\n  '2': 'opacity:0.5', // dim\n  '3': '<i>', // italic\n  '4': '<u>', // underscore\n  '8': 'display:none', // hidden\n  '9': '<del>' // delete\n}\nvar _closeTags = {\n  '23': '</i>', // reset italic\n  '24': '</u>', // reset underscore\n  '29': '</del>' // reset delete\n}\n\n;[0, 21, 22, 27, 28, 39, 49].forEach(function (n) {\n  _closeTags[n] = '</span>'\n})\n\n/**\n * Converts text with ANSI color codes to HTML markup.\n * @param {String} text\n * @returns {*}\n */\nfunction ansiHTML (text) {\n  // Returns the text if the string has no ANSI escape code.\n  if (!_regANSI.test(text)) {\n    return text\n  }\n\n  // Cache opened sequence.\n  var ansiCodes = []\n  // Replace with markup.\n  var ret = text.replace(/\\033\\[(\\d+)m/g, function (match, seq) {\n    var ot = _openTags[seq]\n    if (ot) {\n      // If current sequence has been opened, close it.\n      if (!!~ansiCodes.indexOf(seq)) { // eslint-disable-line no-extra-boolean-cast\n        ansiCodes.pop()\n        return '</span>'\n      }\n      // Open tag.\n      ansiCodes.push(seq)\n      return ot[0] === '<' ? ot : '<span style=\"' + ot + ';\">'\n    }\n\n    var ct = _closeTags[seq]\n    if (ct) {\n      // Pop sequence\n      ansiCodes.pop()\n      return ct\n    }\n    return ''\n  })\n\n  // Make sure tags are closed.\n  var l = ansiCodes.length\n  ;(l > 0) && (ret += Array(l + 1).join('</span>'))\n\n  return ret\n}\n\n/**\n * Customize colors.\n * @param {Object} colors reference to _defColors\n */\nansiHTML.setColors = function (colors) {\n  if (typeof colors !== 'object') {\n    throw new Error('`colors` parameter must be an Object.')\n  }\n\n  var _finalColors = {}\n  for (var key in _defColors) {\n    var hex = colors.hasOwnProperty(key) ? colors[key] : null\n    if (!hex) {\n      _finalColors[key] = _defColors[key]\n      continue\n    }\n    if ('reset' === key) {\n      if (typeof hex === 'string') {\n        hex = [hex]\n      }\n      if (!Array.isArray(hex) || hex.length === 0 || hex.some(function (h) {\n        return typeof h !== 'string'\n      })) {\n        throw new Error('The value of `' + key + '` property must be an Array and each item could only be a hex string, e.g.: FF0000')\n      }\n      var defHexColor = _defColors[key]\n      if (!hex[0]) {\n        hex[0] = defHexColor[0]\n      }\n      if (hex.length === 1 || !hex[1]) {\n        hex = [hex[0]]\n        hex.push(defHexColor[1])\n      }\n\n      hex = hex.slice(0, 2)\n    } else if (typeof hex !== 'string') {\n      throw new Error('The value of `' + key + '` property must be a hex string, e.g.: FF0000')\n    }\n    _finalColors[key] = hex\n  }\n  _setTags(_finalColors)\n}\n\n/**\n * Reset colors.\n */\nansiHTML.reset = function () {\n  _setTags(_defColors)\n}\n\n/**\n * Expose tags, including open and close.\n * @type {Object}\n */\nansiHTML.tags = {}\n\nif (Object.defineProperty) {\n  Object.defineProperty(ansiHTML.tags, 'open', {\n    get: function () { return _openTags }\n  })\n  Object.defineProperty(ansiHTML.tags, 'close', {\n    get: function () { return _closeTags }\n  })\n} else {\n  ansiHTML.tags.open = _openTags\n  ansiHTML.tags.close = _closeTags\n}\n\nfunction _setTags (colors) {\n  // reset all\n  _openTags['0'] = 'font-weight:normal;opacity:1;color:#' + colors.reset[0] + ';background:#' + colors.reset[1]\n  // inverse\n  _openTags['7'] = 'color:#' + colors.reset[1] + ';background:#' + colors.reset[0]\n  // dark grey\n  _openTags['90'] = 'color:#' + colors.darkgrey\n\n  for (var code in _styles) {\n    var color = _styles[code]\n    var oriColor = colors[color] || '000'\n    _openTags[code] = 'color:#' + oriColor\n    code = parseInt(code)\n    _openTags[(code + 10).toString()] = 'background:#' + oriColor\n  }\n}\n\nansiHTML.reset()\n\n\n//# sourceURL=webpack:///./node_modules/ansi-html-community/index.js?");

/***/ }),

/***/ "./node_modules/html-entities/lib/index.js":
/*!*************************************************!*\
  !*** ./node_modules/html-entities/lib/index.js ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\nvar __assign = (this && this.__assign) || function () {\n    __assign = Object.assign || function(t) {\n        for (var s, i = 1, n = arguments.length; i < n; i++) {\n            s = arguments[i];\n            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))\n                t[p] = s[p];\n        }\n        return t;\n    };\n    return __assign.apply(this, arguments);\n};\nObject.defineProperty(exports, \"__esModule\", { value: true });\nvar named_references_1 = __webpack_require__(/*! ./named-references */ \"./node_modules/html-entities/lib/named-references.js\");\nvar numeric_unicode_map_1 = __webpack_require__(/*! ./numeric-unicode-map */ \"./node_modules/html-entities/lib/numeric-unicode-map.js\");\nvar surrogate_pairs_1 = __webpack_require__(/*! ./surrogate-pairs */ \"./node_modules/html-entities/lib/surrogate-pairs.js\");\nvar allNamedReferences = __assign(__assign({}, named_references_1.namedReferences), { all: named_references_1.namedReferences.html5 });\nvar encodeRegExps = {\n    specialChars: /[<>'\"&]/g,\n    nonAscii: /(?:[<>'\"&\\u0080-\\uD7FF\\uE000-\\uFFFF]|[\\uD800-\\uDBFF][\\uDC00-\\uDFFF]|[\\uD800-\\uDBFF](?![\\uDC00-\\uDFFF])|(?:[^\\uD800-\\uDBFF]|^)[\\uDC00-\\uDFFF])/g,\n    nonAsciiPrintable: /(?:[<>'\"&\\x01-\\x08\\x11-\\x15\\x17-\\x1F\\x7f-\\uD7FF\\uE000-\\uFFFF]|[\\uD800-\\uDBFF][\\uDC00-\\uDFFF]|[\\uD800-\\uDBFF](?![\\uDC00-\\uDFFF])|(?:[^\\uD800-\\uDBFF]|^)[\\uDC00-\\uDFFF])/g,\n    extensive: /(?:[\\x01-\\x0c\\x0e-\\x1f\\x21-\\x2c\\x2e-\\x2f\\x3a-\\x40\\x5b-\\x60\\x7b-\\x7d\\x7f-\\uD7FF\\uE000-\\uFFFF]|[\\uD800-\\uDBFF][\\uDC00-\\uDFFF]|[\\uD800-\\uDBFF](?![\\uDC00-\\uDFFF])|(?:[^\\uD800-\\uDBFF]|^)[\\uDC00-\\uDFFF])/g\n};\nvar defaultEncodeOptions = {\n    mode: 'specialChars',\n    level: 'all',\n    numeric: 'decimal'\n};\n/** Encodes all the necessary (specified by `level`) characters in the text */\nfunction encode(text, _a) {\n    var _b = _a === void 0 ? defaultEncodeOptions : _a, _c = _b.mode, mode = _c === void 0 ? 'specialChars' : _c, _d = _b.numeric, numeric = _d === void 0 ? 'decimal' : _d, _e = _b.level, level = _e === void 0 ? 'all' : _e;\n    if (!text) {\n        return '';\n    }\n    var encodeRegExp = encodeRegExps[mode];\n    var references = allNamedReferences[level].characters;\n    var isHex = numeric === 'hexadecimal';\n    encodeRegExp.lastIndex = 0;\n    var _b = encodeRegExp.exec(text);\n    var _c;\n    if (_b) {\n        _c = '';\n        var _d = 0;\n        do {\n            if (_d !== _b.index) {\n                _c += text.substring(_d, _b.index);\n            }\n            var _e = _b[0];\n            var result_1 = references[_e];\n            if (!result_1) {\n                var code_1 = _e.length > 1 ? surrogate_pairs_1.getCodePoint(_e, 0) : _e.charCodeAt(0);\n                result_1 = (isHex ? '&#x' + code_1.toString(16) : '&#' + code_1) + ';';\n            }\n            _c += result_1;\n            _d = _b.index + _e.length;\n        } while ((_b = encodeRegExp.exec(text)));\n        if (_d !== text.length) {\n            _c += text.substring(_d);\n        }\n    }\n    else {\n        _c =\n            text;\n    }\n    return _c;\n}\nexports.encode = encode;\nvar defaultDecodeOptions = {\n    scope: 'body',\n    level: 'all'\n};\nvar strict = /&(?:#\\d+|#[xX][\\da-fA-F]+|[0-9a-zA-Z]+);/g;\nvar attribute = /&(?:#\\d+|#[xX][\\da-fA-F]+|[0-9a-zA-Z]+)[;=]?/g;\nvar baseDecodeRegExps = {\n    xml: {\n        strict: strict,\n        attribute: attribute,\n        body: named_references_1.bodyRegExps.xml\n    },\n    html4: {\n        strict: strict,\n        attribute: attribute,\n        body: named_references_1.bodyRegExps.html4\n    },\n    html5: {\n        strict: strict,\n        attribute: attribute,\n        body: named_references_1.bodyRegExps.html5\n    }\n};\nvar decodeRegExps = __assign(__assign({}, baseDecodeRegExps), { all: baseDecodeRegExps.html5 });\nvar fromCharCode = String.fromCharCode;\nvar outOfBoundsChar = fromCharCode(65533);\nvar defaultDecodeEntityOptions = {\n    level: 'all'\n};\n/** Decodes a single entity */\nfunction decodeEntity(entity, _a) {\n    var _b = (_a === void 0 ? defaultDecodeEntityOptions : _a).level, level = _b === void 0 ? 'all' : _b;\n    if (!entity) {\n        return '';\n    }\n    var _b = entity;\n    var decodeEntityLastChar_1 = entity[entity.length - 1];\n    if (false) {}\n    else if (false) {}\n    else {\n        var decodeResultByReference_1 = allNamedReferences[level].entities[entity];\n        if (decodeResultByReference_1) {\n            _b = decodeResultByReference_1;\n        }\n        else if (entity[0] === '&' && entity[1] === '#') {\n            var decodeSecondChar_1 = entity[2];\n            var decodeCode_1 = decodeSecondChar_1 == 'x' || decodeSecondChar_1 == 'X'\n                ? parseInt(entity.substr(3), 16)\n                : parseInt(entity.substr(2));\n            _b =\n                decodeCode_1 >= 0x10ffff\n                    ? outOfBoundsChar\n                    : decodeCode_1 > 65535\n                        ? surrogate_pairs_1.fromCodePoint(decodeCode_1)\n                        : fromCharCode(numeric_unicode_map_1.numericUnicodeMap[decodeCode_1] || decodeCode_1);\n        }\n    }\n    return _b;\n}\nexports.decodeEntity = decodeEntity;\n/** Decodes all entities in the text */\nfunction decode(text, _a) {\n    var decodeSecondChar_1 = _a === void 0 ? defaultDecodeOptions : _a, decodeCode_1 = decodeSecondChar_1.level, level = decodeCode_1 === void 0 ? 'all' : decodeCode_1, _b = decodeSecondChar_1.scope, scope = _b === void 0 ? level === 'xml' ? 'strict' : 'body' : _b;\n    if (!text) {\n        return '';\n    }\n    var decodeRegExp = decodeRegExps[level][scope];\n    var references = allNamedReferences[level].entities;\n    var isAttribute = scope === 'attribute';\n    var isStrict = scope === 'strict';\n    decodeRegExp.lastIndex = 0;\n    var replaceMatch_1 = decodeRegExp.exec(text);\n    var replaceResult_1;\n    if (replaceMatch_1) {\n        replaceResult_1 = '';\n        var replaceLastIndex_1 = 0;\n        do {\n            if (replaceLastIndex_1 !== replaceMatch_1.index) {\n                replaceResult_1 += text.substring(replaceLastIndex_1, replaceMatch_1.index);\n            }\n            var replaceInput_1 = replaceMatch_1[0];\n            var decodeResult_1 = replaceInput_1;\n            var decodeEntityLastChar_2 = replaceInput_1[replaceInput_1.length - 1];\n            if (isAttribute\n                && decodeEntityLastChar_2 === '=') {\n                decodeResult_1 = replaceInput_1;\n            }\n            else if (isStrict\n                && decodeEntityLastChar_2 !== ';') {\n                decodeResult_1 = replaceInput_1;\n            }\n            else {\n                var decodeResultByReference_2 = references[replaceInput_1];\n                if (decodeResultByReference_2) {\n                    decodeResult_1 = decodeResultByReference_2;\n                }\n                else if (replaceInput_1[0] === '&' && replaceInput_1[1] === '#') {\n                    var decodeSecondChar_2 = replaceInput_1[2];\n                    var decodeCode_2 = decodeSecondChar_2 == 'x' || decodeSecondChar_2 == 'X'\n                        ? parseInt(replaceInput_1.substr(3), 16)\n                        : parseInt(replaceInput_1.substr(2));\n                    decodeResult_1 =\n                        decodeCode_2 >= 0x10ffff\n                            ? outOfBoundsChar\n                            : decodeCode_2 > 65535\n                                ? surrogate_pairs_1.fromCodePoint(decodeCode_2)\n                                : fromCharCode(numeric_unicode_map_1.numericUnicodeMap[decodeCode_2] || decodeCode_2);\n                }\n            }\n            replaceResult_1 += decodeResult_1;\n            replaceLastIndex_1 = replaceMatch_1.index + replaceInput_1.length;\n        } while ((replaceMatch_1 = decodeRegExp.exec(text)));\n        if (replaceLastIndex_1 !== text.length) {\n            replaceResult_1 += text.substring(replaceLastIndex_1);\n        }\n    }\n    else {\n        replaceResult_1 =\n            text;\n    }\n    return replaceResult_1;\n}\nexports.decode = decode;\n\n\n//# sourceURL=webpack:///./node_modules/html-entities/lib/index.js?");

/***/ }),

/***/ "./node_modules/html-entities/lib/named-references.js":
/*!************************************************************!*\
  !*** ./node_modules/html-entities/lib/named-references.js ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("Object.defineProperty(exports,\"__esModule\",{value:true});exports.bodyRegExps={xml:/&(?:#\\d+|#[xX][\\da-fA-F]+|[0-9a-zA-Z]+);?/g,html4:/&(?:nbsp|iexcl|cent|pound|curren|yen|brvbar|sect|uml|copy|ordf|laquo|not|shy|reg|macr|deg|plusmn|sup2|sup3|acute|micro|para|middot|cedil|sup1|ordm|raquo|frac14|frac12|frac34|iquest|Agrave|Aacute|Acirc|Atilde|Auml|Aring|AElig|Ccedil|Egrave|Eacute|Ecirc|Euml|Igrave|Iacute|Icirc|Iuml|ETH|Ntilde|Ograve|Oacute|Ocirc|Otilde|Ouml|times|Oslash|Ugrave|Uacute|Ucirc|Uuml|Yacute|THORN|szlig|agrave|aacute|acirc|atilde|auml|aring|aelig|ccedil|egrave|eacute|ecirc|euml|igrave|iacute|icirc|iuml|eth|ntilde|ograve|oacute|ocirc|otilde|ouml|divide|oslash|ugrave|uacute|ucirc|uuml|yacute|thorn|yuml|quot|amp|lt|gt|#\\d+|#[xX][\\da-fA-F]+|[0-9a-zA-Z]+);?/g,html5:/&(?:AElig|AMP|Aacute|Acirc|Agrave|Aring|Atilde|Auml|COPY|Ccedil|ETH|Eacute|Ecirc|Egrave|Euml|GT|Iacute|Icirc|Igrave|Iuml|LT|Ntilde|Oacute|Ocirc|Ograve|Oslash|Otilde|Ouml|QUOT|REG|THORN|Uacute|Ucirc|Ugrave|Uuml|Yacute|aacute|acirc|acute|aelig|agrave|amp|aring|atilde|auml|brvbar|ccedil|cedil|cent|copy|curren|deg|divide|eacute|ecirc|egrave|eth|euml|frac12|frac14|frac34|gt|iacute|icirc|iexcl|igrave|iquest|iuml|laquo|lt|macr|micro|middot|nbsp|not|ntilde|oacute|ocirc|ograve|ordf|ordm|oslash|otilde|ouml|para|plusmn|pound|quot|raquo|reg|sect|shy|sup1|sup2|sup3|szlig|thorn|times|uacute|ucirc|ugrave|uml|uuml|yacute|yen|yuml|#\\d+|#[xX][\\da-fA-F]+|[0-9a-zA-Z]+);?/g};exports.namedReferences={xml:{entities:{\"&lt;\":\"<\",\"&gt;\":\">\",\"&quot;\":'\"',\"&apos;\":\"'\",\"&amp;\":\"&\"},characters:{\"<\":\"&lt;\",\">\":\"&gt;\",'\"':\"&quot;\",\"'\":\"&apos;\",\"&\":\"&amp;\"}},html4:{entities:{\"&apos;\":\"'\",\"&nbsp\":\" \",\"&nbsp;\":\" \",\"&iexcl\":\"¡\",\"&iexcl;\":\"¡\",\"&cent\":\"¢\",\"&cent;\":\"¢\",\"&pound\":\"£\",\"&pound;\":\"£\",\"&curren\":\"¤\",\"&curren;\":\"¤\",\"&yen\":\"¥\",\"&yen;\":\"¥\",\"&brvbar\":\"¦\",\"&brvbar;\":\"¦\",\"&sect\":\"§\",\"&sect;\":\"§\",\"&uml\":\"¨\",\"&uml;\":\"¨\",\"&copy\":\"©\",\"&copy;\":\"©\",\"&ordf\":\"ª\",\"&ordf;\":\"ª\",\"&laquo\":\"«\",\"&laquo;\":\"«\",\"&not\":\"¬\",\"&not;\":\"¬\",\"&shy\":\"­\",\"&shy;\":\"­\",\"&reg\":\"®\",\"&reg;\":\"®\",\"&macr\":\"¯\",\"&macr;\":\"¯\",\"&deg\":\"°\",\"&deg;\":\"°\",\"&plusmn\":\"±\",\"&plusmn;\":\"±\",\"&sup2\":\"²\",\"&sup2;\":\"²\",\"&sup3\":\"³\",\"&sup3;\":\"³\",\"&acute\":\"´\",\"&acute;\":\"´\",\"&micro\":\"µ\",\"&micro;\":\"µ\",\"&para\":\"¶\",\"&para;\":\"¶\",\"&middot\":\"·\",\"&middot;\":\"·\",\"&cedil\":\"¸\",\"&cedil;\":\"¸\",\"&sup1\":\"¹\",\"&sup1;\":\"¹\",\"&ordm\":\"º\",\"&ordm;\":\"º\",\"&raquo\":\"»\",\"&raquo;\":\"»\",\"&frac14\":\"¼\",\"&frac14;\":\"¼\",\"&frac12\":\"½\",\"&frac12;\":\"½\",\"&frac34\":\"¾\",\"&frac34;\":\"¾\",\"&iquest\":\"¿\",\"&iquest;\":\"¿\",\"&Agrave\":\"À\",\"&Agrave;\":\"À\",\"&Aacute\":\"Á\",\"&Aacute;\":\"Á\",\"&Acirc\":\"Â\",\"&Acirc;\":\"Â\",\"&Atilde\":\"Ã\",\"&Atilde;\":\"Ã\",\"&Auml\":\"Ä\",\"&Auml;\":\"Ä\",\"&Aring\":\"Å\",\"&Aring;\":\"Å\",\"&AElig\":\"Æ\",\"&AElig;\":\"Æ\",\"&Ccedil\":\"Ç\",\"&Ccedil;\":\"Ç\",\"&Egrave\":\"È\",\"&Egrave;\":\"È\",\"&Eacute\":\"É\",\"&Eacute;\":\"É\",\"&Ecirc\":\"Ê\",\"&Ecirc;\":\"Ê\",\"&Euml\":\"Ë\",\"&Euml;\":\"Ë\",\"&Igrave\":\"Ì\",\"&Igrave;\":\"Ì\",\"&Iacute\":\"Í\",\"&Iacute;\":\"Í\",\"&Icirc\":\"Î\",\"&Icirc;\":\"Î\",\"&Iuml\":\"Ï\",\"&Iuml;\":\"Ï\",\"&ETH\":\"Ð\",\"&ETH;\":\"Ð\",\"&Ntilde\":\"Ñ\",\"&Ntilde;\":\"Ñ\",\"&Ograve\":\"Ò\",\"&Ograve;\":\"Ò\",\"&Oacute\":\"Ó\",\"&Oacute;\":\"Ó\",\"&Ocirc\":\"Ô\",\"&Ocirc;\":\"Ô\",\"&Otilde\":\"Õ\",\"&Otilde;\":\"Õ\",\"&Ouml\":\"Ö\",\"&Ouml;\":\"Ö\",\"&times\":\"×\",\"&times;\":\"×\",\"&Oslash\":\"Ø\",\"&Oslash;\":\"Ø\",\"&Ugrave\":\"Ù\",\"&Ugrave;\":\"Ù\",\"&Uacute\":\"Ú\",\"&Uacute;\":\"Ú\",\"&Ucirc\":\"Û\",\"&Ucirc;\":\"Û\",\"&Uuml\":\"Ü\",\"&Uuml;\":\"Ü\",\"&Yacute\":\"Ý\",\"&Yacute;\":\"Ý\",\"&THORN\":\"Þ\",\"&THORN;\":\"Þ\",\"&szlig\":\"ß\",\"&szlig;\":\"ß\",\"&agrave\":\"à\",\"&agrave;\":\"à\",\"&aacute\":\"á\",\"&aacute;\":\"á\",\"&acirc\":\"â\",\"&acirc;\":\"â\",\"&atilde\":\"ã\",\"&atilde;\":\"ã\",\"&auml\":\"ä\",\"&auml;\":\"ä\",\"&aring\":\"å\",\"&aring;\":\"å\",\"&aelig\":\"æ\",\"&aelig;\":\"æ\",\"&ccedil\":\"ç\",\"&ccedil;\":\"ç\",\"&egrave\":\"è\",\"&egrave;\":\"è\",\"&eacute\":\"é\",\"&eacute;\":\"é\",\"&ecirc\":\"ê\",\"&ecirc;\":\"ê\",\"&euml\":\"ë\",\"&euml;\":\"ë\",\"&igrave\":\"ì\",\"&igrave;\":\"ì\",\"&iacute\":\"í\",\"&iacute;\":\"í\",\"&icirc\":\"î\",\"&icirc;\":\"î\",\"&iuml\":\"ï\",\"&iuml;\":\"ï\",\"&eth\":\"ð\",\"&eth;\":\"ð\",\"&ntilde\":\"ñ\",\"&ntilde;\":\"ñ\",\"&ograve\":\"ò\",\"&ograve;\":\"ò\",\"&oacute\":\"ó\",\"&oacute;\":\"ó\",\"&ocirc\":\"ô\",\"&ocirc;\":\"ô\",\"&otilde\":\"õ\",\"&otilde;\":\"õ\",\"&ouml\":\"ö\",\"&ouml;\":\"ö\",\"&divide\":\"÷\",\"&divide;\":\"÷\",\"&oslash\":\"ø\",\"&oslash;\":\"ø\",\"&ugrave\":\"ù\",\"&ugrave;\":\"ù\",\"&uacute\":\"ú\",\"&uacute;\":\"ú\",\"&ucirc\":\"û\",\"&ucirc;\":\"û\",\"&uuml\":\"ü\",\"&uuml;\":\"ü\",\"&yacute\":\"ý\",\"&yacute;\":\"ý\",\"&thorn\":\"þ\",\"&thorn;\":\"þ\",\"&yuml\":\"ÿ\",\"&yuml;\":\"ÿ\",\"&quot\":'\"',\"&quot;\":'\"',\"&amp\":\"&\",\"&amp;\":\"&\",\"&lt\":\"<\",\"&lt;\":\"<\",\"&gt\":\">\",\"&gt;\":\">\",\"&OElig;\":\"Œ\",\"&oelig;\":\"œ\",\"&Scaron;\":\"Š\",\"&scaron;\":\"š\",\"&Yuml;\":\"Ÿ\",\"&circ;\":\"ˆ\",\"&tilde;\":\"˜\",\"&ensp;\":\" \",\"&emsp;\":\" \",\"&thinsp;\":\" \",\"&zwnj;\":\"‌\",\"&zwj;\":\"‍\",\"&lrm;\":\"‎\",\"&rlm;\":\"‏\",\"&ndash;\":\"–\",\"&mdash;\":\"—\",\"&lsquo;\":\"‘\",\"&rsquo;\":\"’\",\"&sbquo;\":\"‚\",\"&ldquo;\":\"“\",\"&rdquo;\":\"”\",\"&bdquo;\":\"„\",\"&dagger;\":\"†\",\"&Dagger;\":\"‡\",\"&permil;\":\"‰\",\"&lsaquo;\":\"‹\",\"&rsaquo;\":\"›\",\"&euro;\":\"€\",\"&fnof;\":\"ƒ\",\"&Alpha;\":\"Α\",\"&Beta;\":\"Β\",\"&Gamma;\":\"Γ\",\"&Delta;\":\"Δ\",\"&Epsilon;\":\"Ε\",\"&Zeta;\":\"Ζ\",\"&Eta;\":\"Η\",\"&Theta;\":\"Θ\",\"&Iota;\":\"Ι\",\"&Kappa;\":\"Κ\",\"&Lambda;\":\"Λ\",\"&Mu;\":\"Μ\",\"&Nu;\":\"Ν\",\"&Xi;\":\"Ξ\",\"&Omicron;\":\"Ο\",\"&Pi;\":\"Π\",\"&Rho;\":\"Ρ\",\"&Sigma;\":\"Σ\",\"&Tau;\":\"Τ\",\"&Upsilon;\":\"Υ\",\"&Phi;\":\"Φ\",\"&Chi;\":\"Χ\",\"&Psi;\":\"Ψ\",\"&Omega;\":\"Ω\",\"&alpha;\":\"α\",\"&beta;\":\"β\",\"&gamma;\":\"γ\",\"&delta;\":\"δ\",\"&epsilon;\":\"ε\",\"&zeta;\":\"ζ\",\"&eta;\":\"η\",\"&theta;\":\"θ\",\"&iota;\":\"ι\",\"&kappa;\":\"κ\",\"&lambda;\":\"λ\",\"&mu;\":\"μ\",\"&nu;\":\"ν\",\"&xi;\":\"ξ\",\"&omicron;\":\"ο\",\"&pi;\":\"π\",\"&rho;\":\"ρ\",\"&sigmaf;\":\"ς\",\"&sigma;\":\"σ\",\"&tau;\":\"τ\",\"&upsilon;\":\"υ\",\"&phi;\":\"φ\",\"&chi;\":\"χ\",\"&psi;\":\"ψ\",\"&omega;\":\"ω\",\"&thetasym;\":\"ϑ\",\"&upsih;\":\"ϒ\",\"&piv;\":\"ϖ\",\"&bull;\":\"•\",\"&hellip;\":\"…\",\"&prime;\":\"′\",\"&Prime;\":\"″\",\"&oline;\":\"‾\",\"&frasl;\":\"⁄\",\"&weierp;\":\"℘\",\"&image;\":\"ℑ\",\"&real;\":\"ℜ\",\"&trade;\":\"™\",\"&alefsym;\":\"ℵ\",\"&larr;\":\"←\",\"&uarr;\":\"↑\",\"&rarr;\":\"→\",\"&darr;\":\"↓\",\"&harr;\":\"↔\",\"&crarr;\":\"↵\",\"&lArr;\":\"⇐\",\"&uArr;\":\"⇑\",\"&rArr;\":\"⇒\",\"&dArr;\":\"⇓\",\"&hArr;\":\"⇔\",\"&forall;\":\"∀\",\"&part;\":\"∂\",\"&exist;\":\"∃\",\"&empty;\":\"∅\",\"&nabla;\":\"∇\",\"&isin;\":\"∈\",\"&notin;\":\"∉\",\"&ni;\":\"∋\",\"&prod;\":\"∏\",\"&sum;\":\"∑\",\"&minus;\":\"−\",\"&lowast;\":\"∗\",\"&radic;\":\"√\",\"&prop;\":\"∝\",\"&infin;\":\"∞\",\"&ang;\":\"∠\",\"&and;\":\"∧\",\"&or;\":\"∨\",\"&cap;\":\"∩\",\"&cup;\":\"∪\",\"&int;\":\"∫\",\"&there4;\":\"∴\",\"&sim;\":\"∼\",\"&cong;\":\"≅\",\"&asymp;\":\"≈\",\"&ne;\":\"≠\",\"&equiv;\":\"≡\",\"&le;\":\"≤\",\"&ge;\":\"≥\",\"&sub;\":\"⊂\",\"&sup;\":\"⊃\",\"&nsub;\":\"⊄\",\"&sube;\":\"⊆\",\"&supe;\":\"⊇\",\"&oplus;\":\"⊕\",\"&otimes;\":\"⊗\",\"&perp;\":\"⊥\",\"&sdot;\":\"⋅\",\"&lceil;\":\"⌈\",\"&rceil;\":\"⌉\",\"&lfloor;\":\"⌊\",\"&rfloor;\":\"⌋\",\"&lang;\":\"〈\",\"&rang;\":\"〉\",\"&loz;\":\"◊\",\"&spades;\":\"♠\",\"&clubs;\":\"♣\",\"&hearts;\":\"♥\",\"&diams;\":\"♦\"},characters:{\"'\":\"&apos;\",\" \":\"&nbsp;\",\"¡\":\"&iexcl;\",\"¢\":\"&cent;\",\"£\":\"&pound;\",\"¤\":\"&curren;\",\"¥\":\"&yen;\",\"¦\":\"&brvbar;\",\"§\":\"&sect;\",\"¨\":\"&uml;\",\"©\":\"&copy;\",\"ª\":\"&ordf;\",\"«\":\"&laquo;\",\"¬\":\"&not;\",\"­\":\"&shy;\",\"®\":\"&reg;\",\"¯\":\"&macr;\",\"°\":\"&deg;\",\"±\":\"&plusmn;\",\"²\":\"&sup2;\",\"³\":\"&sup3;\",\"´\":\"&acute;\",\"µ\":\"&micro;\",\"¶\":\"&para;\",\"·\":\"&middot;\",\"¸\":\"&cedil;\",\"¹\":\"&sup1;\",\"º\":\"&ordm;\",\"»\":\"&raquo;\",\"¼\":\"&frac14;\",\"½\":\"&frac12;\",\"¾\":\"&frac34;\",\"¿\":\"&iquest;\",\"À\":\"&Agrave;\",\"Á\":\"&Aacute;\",\"Â\":\"&Acirc;\",\"Ã\":\"&Atilde;\",\"Ä\":\"&Auml;\",\"Å\":\"&Aring;\",\"Æ\":\"&AElig;\",\"Ç\":\"&Ccedil;\",\"È\":\"&Egrave;\",\"É\":\"&Eacute;\",\"Ê\":\"&Ecirc;\",\"Ë\":\"&Euml;\",\"Ì\":\"&Igrave;\",\"Í\":\"&Iacute;\",\"Î\":\"&Icirc;\",\"Ï\":\"&Iuml;\",\"Ð\":\"&ETH;\",\"Ñ\":\"&Ntilde;\",\"Ò\":\"&Ograve;\",\"Ó\":\"&Oacute;\",\"Ô\":\"&Ocirc;\",\"Õ\":\"&Otilde;\",\"Ö\":\"&Ouml;\",\"×\":\"&times;\",\"Ø\":\"&Oslash;\",\"Ù\":\"&Ugrave;\",\"Ú\":\"&Uacute;\",\"Û\":\"&Ucirc;\",\"Ü\":\"&Uuml;\",\"Ý\":\"&Yacute;\",\"Þ\":\"&THORN;\",\"ß\":\"&szlig;\",\"à\":\"&agrave;\",\"á\":\"&aacute;\",\"â\":\"&acirc;\",\"ã\":\"&atilde;\",\"ä\":\"&auml;\",\"å\":\"&aring;\",\"æ\":\"&aelig;\",\"ç\":\"&ccedil;\",\"è\":\"&egrave;\",\"é\":\"&eacute;\",\"ê\":\"&ecirc;\",\"ë\":\"&euml;\",\"ì\":\"&igrave;\",\"í\":\"&iacute;\",\"î\":\"&icirc;\",\"ï\":\"&iuml;\",\"ð\":\"&eth;\",\"ñ\":\"&ntilde;\",\"ò\":\"&ograve;\",\"ó\":\"&oacute;\",\"ô\":\"&ocirc;\",\"õ\":\"&otilde;\",\"ö\":\"&ouml;\",\"÷\":\"&divide;\",\"ø\":\"&oslash;\",\"ù\":\"&ugrave;\",\"ú\":\"&uacute;\",\"û\":\"&ucirc;\",\"ü\":\"&uuml;\",\"ý\":\"&yacute;\",\"þ\":\"&thorn;\",\"ÿ\":\"&yuml;\",'\"':\"&quot;\",\"&\":\"&amp;\",\"<\":\"&lt;\",\">\":\"&gt;\",\"Œ\":\"&OElig;\",\"œ\":\"&oelig;\",\"Š\":\"&Scaron;\",\"š\":\"&scaron;\",\"Ÿ\":\"&Yuml;\",\"ˆ\":\"&circ;\",\"˜\":\"&tilde;\",\" \":\"&ensp;\",\" \":\"&emsp;\",\" \":\"&thinsp;\",\"‌\":\"&zwnj;\",\"‍\":\"&zwj;\",\"‎\":\"&lrm;\",\"‏\":\"&rlm;\",\"–\":\"&ndash;\",\"—\":\"&mdash;\",\"‘\":\"&lsquo;\",\"’\":\"&rsquo;\",\"‚\":\"&sbquo;\",\"“\":\"&ldquo;\",\"”\":\"&rdquo;\",\"„\":\"&bdquo;\",\"†\":\"&dagger;\",\"‡\":\"&Dagger;\",\"‰\":\"&permil;\",\"‹\":\"&lsaquo;\",\"›\":\"&rsaquo;\",\"€\":\"&euro;\",\"ƒ\":\"&fnof;\",\"Α\":\"&Alpha;\",\"Β\":\"&Beta;\",\"Γ\":\"&Gamma;\",\"Δ\":\"&Delta;\",\"Ε\":\"&Epsilon;\",\"Ζ\":\"&Zeta;\",\"Η\":\"&Eta;\",\"Θ\":\"&Theta;\",\"Ι\":\"&Iota;\",\"Κ\":\"&Kappa;\",\"Λ\":\"&Lambda;\",\"Μ\":\"&Mu;\",\"Ν\":\"&Nu;\",\"Ξ\":\"&Xi;\",\"Ο\":\"&Omicron;\",\"Π\":\"&Pi;\",\"Ρ\":\"&Rho;\",\"Σ\":\"&Sigma;\",\"Τ\":\"&Tau;\",\"Υ\":\"&Upsilon;\",\"Φ\":\"&Phi;\",\"Χ\":\"&Chi;\",\"Ψ\":\"&Psi;\",\"Ω\":\"&Omega;\",\"α\":\"&alpha;\",\"β\":\"&beta;\",\"γ\":\"&gamma;\",\"δ\":\"&delta;\",\"ε\":\"&epsilon;\",\"ζ\":\"&zeta;\",\"η\":\"&eta;\",\"θ\":\"&theta;\",\"ι\":\"&iota;\",\"κ\":\"&kappa;\",\"λ\":\"&lambda;\",\"μ\":\"&mu;\",\"ν\":\"&nu;\",\"ξ\":\"&xi;\",\"ο\":\"&omicron;\",\"π\":\"&pi;\",\"ρ\":\"&rho;\",\"ς\":\"&sigmaf;\",\"σ\":\"&sigma;\",\"τ\":\"&tau;\",\"υ\":\"&upsilon;\",\"φ\":\"&phi;\",\"χ\":\"&chi;\",\"ψ\":\"&psi;\",\"ω\":\"&omega;\",\"ϑ\":\"&thetasym;\",\"ϒ\":\"&upsih;\",\"ϖ\":\"&piv;\",\"•\":\"&bull;\",\"…\":\"&hellip;\",\"′\":\"&prime;\",\"″\":\"&Prime;\",\"‾\":\"&oline;\",\"⁄\":\"&frasl;\",\"℘\":\"&weierp;\",\"ℑ\":\"&image;\",\"ℜ\":\"&real;\",\"™\":\"&trade;\",\"ℵ\":\"&alefsym;\",\"←\":\"&larr;\",\"↑\":\"&uarr;\",\"→\":\"&rarr;\",\"↓\":\"&darr;\",\"↔\":\"&harr;\",\"↵\":\"&crarr;\",\"⇐\":\"&lArr;\",\"⇑\":\"&uArr;\",\"⇒\":\"&rArr;\",\"⇓\":\"&dArr;\",\"⇔\":\"&hArr;\",\"∀\":\"&forall;\",\"∂\":\"&part;\",\"∃\":\"&exist;\",\"∅\":\"&empty;\",\"∇\":\"&nabla;\",\"∈\":\"&isin;\",\"∉\":\"&notin;\",\"∋\":\"&ni;\",\"∏\":\"&prod;\",\"∑\":\"&sum;\",\"−\":\"&minus;\",\"∗\":\"&lowast;\",\"√\":\"&radic;\",\"∝\":\"&prop;\",\"∞\":\"&infin;\",\"∠\":\"&ang;\",\"∧\":\"&and;\",\"∨\":\"&or;\",\"∩\":\"&cap;\",\"∪\":\"&cup;\",\"∫\":\"&int;\",\"∴\":\"&there4;\",\"∼\":\"&sim;\",\"≅\":\"&cong;\",\"≈\":\"&asymp;\",\"≠\":\"&ne;\",\"≡\":\"&equiv;\",\"≤\":\"&le;\",\"≥\":\"&ge;\",\"⊂\":\"&sub;\",\"⊃\":\"&sup;\",\"⊄\":\"&nsub;\",\"⊆\":\"&sube;\",\"⊇\":\"&supe;\",\"⊕\":\"&oplus;\",\"⊗\":\"&otimes;\",\"⊥\":\"&perp;\",\"⋅\":\"&sdot;\",\"⌈\":\"&lceil;\",\"⌉\":\"&rceil;\",\"⌊\":\"&lfloor;\",\"⌋\":\"&rfloor;\",\"〈\":\"&lang;\",\"〉\":\"&rang;\",\"◊\":\"&loz;\",\"♠\":\"&spades;\",\"♣\":\"&clubs;\",\"♥\":\"&hearts;\",\"♦\":\"&diams;\"}},html5:{entities:{\"&AElig\":\"Æ\",\"&AElig;\":\"Æ\",\"&AMP\":\"&\",\"&AMP;\":\"&\",\"&Aacute\":\"Á\",\"&Aacute;\":\"Á\",\"&Abreve;\":\"Ă\",\"&Acirc\":\"Â\",\"&Acirc;\":\"Â\",\"&Acy;\":\"А\",\"&Afr;\":\"𝔄\",\"&Agrave\":\"À\",\"&Agrave;\":\"À\",\"&Alpha;\":\"Α\",\"&Amacr;\":\"Ā\",\"&And;\":\"⩓\",\"&Aogon;\":\"Ą\",\"&Aopf;\":\"𝔸\",\"&ApplyFunction;\":\"⁡\",\"&Aring\":\"Å\",\"&Aring;\":\"Å\",\"&Ascr;\":\"𝒜\",\"&Assign;\":\"≔\",\"&Atilde\":\"Ã\",\"&Atilde;\":\"Ã\",\"&Auml\":\"Ä\",\"&Auml;\":\"Ä\",\"&Backslash;\":\"∖\",\"&Barv;\":\"⫧\",\"&Barwed;\":\"⌆\",\"&Bcy;\":\"Б\",\"&Because;\":\"∵\",\"&Bernoullis;\":\"ℬ\",\"&Beta;\":\"Β\",\"&Bfr;\":\"𝔅\",\"&Bopf;\":\"𝔹\",\"&Breve;\":\"˘\",\"&Bscr;\":\"ℬ\",\"&Bumpeq;\":\"≎\",\"&CHcy;\":\"Ч\",\"&COPY\":\"©\",\"&COPY;\":\"©\",\"&Cacute;\":\"Ć\",\"&Cap;\":\"⋒\",\"&CapitalDifferentialD;\":\"ⅅ\",\"&Cayleys;\":\"ℭ\",\"&Ccaron;\":\"Č\",\"&Ccedil\":\"Ç\",\"&Ccedil;\":\"Ç\",\"&Ccirc;\":\"Ĉ\",\"&Cconint;\":\"∰\",\"&Cdot;\":\"Ċ\",\"&Cedilla;\":\"¸\",\"&CenterDot;\":\"·\",\"&Cfr;\":\"ℭ\",\"&Chi;\":\"Χ\",\"&CircleDot;\":\"⊙\",\"&CircleMinus;\":\"⊖\",\"&CirclePlus;\":\"⊕\",\"&CircleTimes;\":\"⊗\",\"&ClockwiseContourIntegral;\":\"∲\",\"&CloseCurlyDoubleQuote;\":\"”\",\"&CloseCurlyQuote;\":\"’\",\"&Colon;\":\"∷\",\"&Colone;\":\"⩴\",\"&Congruent;\":\"≡\",\"&Conint;\":\"∯\",\"&ContourIntegral;\":\"∮\",\"&Copf;\":\"ℂ\",\"&Coproduct;\":\"∐\",\"&CounterClockwiseContourIntegral;\":\"∳\",\"&Cross;\":\"⨯\",\"&Cscr;\":\"𝒞\",\"&Cup;\":\"⋓\",\"&CupCap;\":\"≍\",\"&DD;\":\"ⅅ\",\"&DDotrahd;\":\"⤑\",\"&DJcy;\":\"Ђ\",\"&DScy;\":\"Ѕ\",\"&DZcy;\":\"Џ\",\"&Dagger;\":\"‡\",\"&Darr;\":\"↡\",\"&Dashv;\":\"⫤\",\"&Dcaron;\":\"Ď\",\"&Dcy;\":\"Д\",\"&Del;\":\"∇\",\"&Delta;\":\"Δ\",\"&Dfr;\":\"𝔇\",\"&DiacriticalAcute;\":\"´\",\"&DiacriticalDot;\":\"˙\",\"&DiacriticalDoubleAcute;\":\"˝\",\"&DiacriticalGrave;\":\"`\",\"&DiacriticalTilde;\":\"˜\",\"&Diamond;\":\"⋄\",\"&DifferentialD;\":\"ⅆ\",\"&Dopf;\":\"𝔻\",\"&Dot;\":\"¨\",\"&DotDot;\":\"⃜\",\"&DotEqual;\":\"≐\",\"&DoubleContourIntegral;\":\"∯\",\"&DoubleDot;\":\"¨\",\"&DoubleDownArrow;\":\"⇓\",\"&DoubleLeftArrow;\":\"⇐\",\"&DoubleLeftRightArrow;\":\"⇔\",\"&DoubleLeftTee;\":\"⫤\",\"&DoubleLongLeftArrow;\":\"⟸\",\"&DoubleLongLeftRightArrow;\":\"⟺\",\"&DoubleLongRightArrow;\":\"⟹\",\"&DoubleRightArrow;\":\"⇒\",\"&DoubleRightTee;\":\"⊨\",\"&DoubleUpArrow;\":\"⇑\",\"&DoubleUpDownArrow;\":\"⇕\",\"&DoubleVerticalBar;\":\"∥\",\"&DownArrow;\":\"↓\",\"&DownArrowBar;\":\"⤓\",\"&DownArrowUpArrow;\":\"⇵\",\"&DownBreve;\":\"̑\",\"&DownLeftRightVector;\":\"⥐\",\"&DownLeftTeeVector;\":\"⥞\",\"&DownLeftVector;\":\"↽\",\"&DownLeftVectorBar;\":\"⥖\",\"&DownRightTeeVector;\":\"⥟\",\"&DownRightVector;\":\"⇁\",\"&DownRightVectorBar;\":\"⥗\",\"&DownTee;\":\"⊤\",\"&DownTeeArrow;\":\"↧\",\"&Downarrow;\":\"⇓\",\"&Dscr;\":\"𝒟\",\"&Dstrok;\":\"Đ\",\"&ENG;\":\"Ŋ\",\"&ETH\":\"Ð\",\"&ETH;\":\"Ð\",\"&Eacute\":\"É\",\"&Eacute;\":\"É\",\"&Ecaron;\":\"Ě\",\"&Ecirc\":\"Ê\",\"&Ecirc;\":\"Ê\",\"&Ecy;\":\"Э\",\"&Edot;\":\"Ė\",\"&Efr;\":\"𝔈\",\"&Egrave\":\"È\",\"&Egrave;\":\"È\",\"&Element;\":\"∈\",\"&Emacr;\":\"Ē\",\"&EmptySmallSquare;\":\"◻\",\"&EmptyVerySmallSquare;\":\"▫\",\"&Eogon;\":\"Ę\",\"&Eopf;\":\"𝔼\",\"&Epsilon;\":\"Ε\",\"&Equal;\":\"⩵\",\"&EqualTilde;\":\"≂\",\"&Equilibrium;\":\"⇌\",\"&Escr;\":\"ℰ\",\"&Esim;\":\"⩳\",\"&Eta;\":\"Η\",\"&Euml\":\"Ë\",\"&Euml;\":\"Ë\",\"&Exists;\":\"∃\",\"&ExponentialE;\":\"ⅇ\",\"&Fcy;\":\"Ф\",\"&Ffr;\":\"𝔉\",\"&FilledSmallSquare;\":\"◼\",\"&FilledVerySmallSquare;\":\"▪\",\"&Fopf;\":\"𝔽\",\"&ForAll;\":\"∀\",\"&Fouriertrf;\":\"ℱ\",\"&Fscr;\":\"ℱ\",\"&GJcy;\":\"Ѓ\",\"&GT\":\">\",\"&GT;\":\">\",\"&Gamma;\":\"Γ\",\"&Gammad;\":\"Ϝ\",\"&Gbreve;\":\"Ğ\",\"&Gcedil;\":\"Ģ\",\"&Gcirc;\":\"Ĝ\",\"&Gcy;\":\"Г\",\"&Gdot;\":\"Ġ\",\"&Gfr;\":\"𝔊\",\"&Gg;\":\"⋙\",\"&Gopf;\":\"𝔾\",\"&GreaterEqual;\":\"≥\",\"&GreaterEqualLess;\":\"⋛\",\"&GreaterFullEqual;\":\"≧\",\"&GreaterGreater;\":\"⪢\",\"&GreaterLess;\":\"≷\",\"&GreaterSlantEqual;\":\"⩾\",\"&GreaterTilde;\":\"≳\",\"&Gscr;\":\"𝒢\",\"&Gt;\":\"≫\",\"&HARDcy;\":\"Ъ\",\"&Hacek;\":\"ˇ\",\"&Hat;\":\"^\",\"&Hcirc;\":\"Ĥ\",\"&Hfr;\":\"ℌ\",\"&HilbertSpace;\":\"ℋ\",\"&Hopf;\":\"ℍ\",\"&HorizontalLine;\":\"─\",\"&Hscr;\":\"ℋ\",\"&Hstrok;\":\"Ħ\",\"&HumpDownHump;\":\"≎\",\"&HumpEqual;\":\"≏\",\"&IEcy;\":\"Е\",\"&IJlig;\":\"Ĳ\",\"&IOcy;\":\"Ё\",\"&Iacute\":\"Í\",\"&Iacute;\":\"Í\",\"&Icirc\":\"Î\",\"&Icirc;\":\"Î\",\"&Icy;\":\"И\",\"&Idot;\":\"İ\",\"&Ifr;\":\"ℑ\",\"&Igrave\":\"Ì\",\"&Igrave;\":\"Ì\",\"&Im;\":\"ℑ\",\"&Imacr;\":\"Ī\",\"&ImaginaryI;\":\"ⅈ\",\"&Implies;\":\"⇒\",\"&Int;\":\"∬\",\"&Integral;\":\"∫\",\"&Intersection;\":\"⋂\",\"&InvisibleComma;\":\"⁣\",\"&InvisibleTimes;\":\"⁢\",\"&Iogon;\":\"Į\",\"&Iopf;\":\"𝕀\",\"&Iota;\":\"Ι\",\"&Iscr;\":\"ℐ\",\"&Itilde;\":\"Ĩ\",\"&Iukcy;\":\"І\",\"&Iuml\":\"Ï\",\"&Iuml;\":\"Ï\",\"&Jcirc;\":\"Ĵ\",\"&Jcy;\":\"Й\",\"&Jfr;\":\"𝔍\",\"&Jopf;\":\"𝕁\",\"&Jscr;\":\"𝒥\",\"&Jsercy;\":\"Ј\",\"&Jukcy;\":\"Є\",\"&KHcy;\":\"Х\",\"&KJcy;\":\"Ќ\",\"&Kappa;\":\"Κ\",\"&Kcedil;\":\"Ķ\",\"&Kcy;\":\"К\",\"&Kfr;\":\"𝔎\",\"&Kopf;\":\"𝕂\",\"&Kscr;\":\"𝒦\",\"&LJcy;\":\"Љ\",\"&LT\":\"<\",\"&LT;\":\"<\",\"&Lacute;\":\"Ĺ\",\"&Lambda;\":\"Λ\",\"&Lang;\":\"⟪\",\"&Laplacetrf;\":\"ℒ\",\"&Larr;\":\"↞\",\"&Lcaron;\":\"Ľ\",\"&Lcedil;\":\"Ļ\",\"&Lcy;\":\"Л\",\"&LeftAngleBracket;\":\"⟨\",\"&LeftArrow;\":\"←\",\"&LeftArrowBar;\":\"⇤\",\"&LeftArrowRightArrow;\":\"⇆\",\"&LeftCeiling;\":\"⌈\",\"&LeftDoubleBracket;\":\"⟦\",\"&LeftDownTeeVector;\":\"⥡\",\"&LeftDownVector;\":\"⇃\",\"&LeftDownVectorBar;\":\"⥙\",\"&LeftFloor;\":\"⌊\",\"&LeftRightArrow;\":\"↔\",\"&LeftRightVector;\":\"⥎\",\"&LeftTee;\":\"⊣\",\"&LeftTeeArrow;\":\"↤\",\"&LeftTeeVector;\":\"⥚\",\"&LeftTriangle;\":\"⊲\",\"&LeftTriangleBar;\":\"⧏\",\"&LeftTriangleEqual;\":\"⊴\",\"&LeftUpDownVector;\":\"⥑\",\"&LeftUpTeeVector;\":\"⥠\",\"&LeftUpVector;\":\"↿\",\"&LeftUpVectorBar;\":\"⥘\",\"&LeftVector;\":\"↼\",\"&LeftVectorBar;\":\"⥒\",\"&Leftarrow;\":\"⇐\",\"&Leftrightarrow;\":\"⇔\",\"&LessEqualGreater;\":\"⋚\",\"&LessFullEqual;\":\"≦\",\"&LessGreater;\":\"≶\",\"&LessLess;\":\"⪡\",\"&LessSlantEqual;\":\"⩽\",\"&LessTilde;\":\"≲\",\"&Lfr;\":\"𝔏\",\"&Ll;\":\"⋘\",\"&Lleftarrow;\":\"⇚\",\"&Lmidot;\":\"Ŀ\",\"&LongLeftArrow;\":\"⟵\",\"&LongLeftRightArrow;\":\"⟷\",\"&LongRightArrow;\":\"⟶\",\"&Longleftarrow;\":\"⟸\",\"&Longleftrightarrow;\":\"⟺\",\"&Longrightarrow;\":\"⟹\",\"&Lopf;\":\"𝕃\",\"&LowerLeftArrow;\":\"↙\",\"&LowerRightArrow;\":\"↘\",\"&Lscr;\":\"ℒ\",\"&Lsh;\":\"↰\",\"&Lstrok;\":\"Ł\",\"&Lt;\":\"≪\",\"&Map;\":\"⤅\",\"&Mcy;\":\"М\",\"&MediumSpace;\":\" \",\"&Mellintrf;\":\"ℳ\",\"&Mfr;\":\"𝔐\",\"&MinusPlus;\":\"∓\",\"&Mopf;\":\"𝕄\",\"&Mscr;\":\"ℳ\",\"&Mu;\":\"Μ\",\"&NJcy;\":\"Њ\",\"&Nacute;\":\"Ń\",\"&Ncaron;\":\"Ň\",\"&Ncedil;\":\"Ņ\",\"&Ncy;\":\"Н\",\"&NegativeMediumSpace;\":\"​\",\"&NegativeThickSpace;\":\"​\",\"&NegativeThinSpace;\":\"​\",\"&NegativeVeryThinSpace;\":\"​\",\"&NestedGreaterGreater;\":\"≫\",\"&NestedLessLess;\":\"≪\",\"&NewLine;\":\"\\n\",\"&Nfr;\":\"𝔑\",\"&NoBreak;\":\"⁠\",\"&NonBreakingSpace;\":\" \",\"&Nopf;\":\"ℕ\",\"&Not;\":\"⫬\",\"&NotCongruent;\":\"≢\",\"&NotCupCap;\":\"≭\",\"&NotDoubleVerticalBar;\":\"∦\",\"&NotElement;\":\"∉\",\"&NotEqual;\":\"≠\",\"&NotEqualTilde;\":\"≂̸\",\"&NotExists;\":\"∄\",\"&NotGreater;\":\"≯\",\"&NotGreaterEqual;\":\"≱\",\"&NotGreaterFullEqual;\":\"≧̸\",\"&NotGreaterGreater;\":\"≫̸\",\"&NotGreaterLess;\":\"≹\",\"&NotGreaterSlantEqual;\":\"⩾̸\",\"&NotGreaterTilde;\":\"≵\",\"&NotHumpDownHump;\":\"≎̸\",\"&NotHumpEqual;\":\"≏̸\",\"&NotLeftTriangle;\":\"⋪\",\"&NotLeftTriangleBar;\":\"⧏̸\",\"&NotLeftTriangleEqual;\":\"⋬\",\"&NotLess;\":\"≮\",\"&NotLessEqual;\":\"≰\",\"&NotLessGreater;\":\"≸\",\"&NotLessLess;\":\"≪̸\",\"&NotLessSlantEqual;\":\"⩽̸\",\"&NotLessTilde;\":\"≴\",\"&NotNestedGreaterGreater;\":\"⪢̸\",\"&NotNestedLessLess;\":\"⪡̸\",\"&NotPrecedes;\":\"⊀\",\"&NotPrecedesEqual;\":\"⪯̸\",\"&NotPrecedesSlantEqual;\":\"⋠\",\"&NotReverseElement;\":\"∌\",\"&NotRightTriangle;\":\"⋫\",\"&NotRightTriangleBar;\":\"⧐̸\",\"&NotRightTriangleEqual;\":\"⋭\",\"&NotSquareSubset;\":\"⊏̸\",\"&NotSquareSubsetEqual;\":\"⋢\",\"&NotSquareSuperset;\":\"⊐̸\",\"&NotSquareSupersetEqual;\":\"⋣\",\"&NotSubset;\":\"⊂⃒\",\"&NotSubsetEqual;\":\"⊈\",\"&NotSucceeds;\":\"⊁\",\"&NotSucceedsEqual;\":\"⪰̸\",\"&NotSucceedsSlantEqual;\":\"⋡\",\"&NotSucceedsTilde;\":\"≿̸\",\"&NotSuperset;\":\"⊃⃒\",\"&NotSupersetEqual;\":\"⊉\",\"&NotTilde;\":\"≁\",\"&NotTildeEqual;\":\"≄\",\"&NotTildeFullEqual;\":\"≇\",\"&NotTildeTilde;\":\"≉\",\"&NotVerticalBar;\":\"∤\",\"&Nscr;\":\"𝒩\",\"&Ntilde\":\"Ñ\",\"&Ntilde;\":\"Ñ\",\"&Nu;\":\"Ν\",\"&OElig;\":\"Œ\",\"&Oacute\":\"Ó\",\"&Oacute;\":\"Ó\",\"&Ocirc\":\"Ô\",\"&Ocirc;\":\"Ô\",\"&Ocy;\":\"О\",\"&Odblac;\":\"Ő\",\"&Ofr;\":\"𝔒\",\"&Ograve\":\"Ò\",\"&Ograve;\":\"Ò\",\"&Omacr;\":\"Ō\",\"&Omega;\":\"Ω\",\"&Omicron;\":\"Ο\",\"&Oopf;\":\"𝕆\",\"&OpenCurlyDoubleQuote;\":\"“\",\"&OpenCurlyQuote;\":\"‘\",\"&Or;\":\"⩔\",\"&Oscr;\":\"𝒪\",\"&Oslash\":\"Ø\",\"&Oslash;\":\"Ø\",\"&Otilde\":\"Õ\",\"&Otilde;\":\"Õ\",\"&Otimes;\":\"⨷\",\"&Ouml\":\"Ö\",\"&Ouml;\":\"Ö\",\"&OverBar;\":\"‾\",\"&OverBrace;\":\"⏞\",\"&OverBracket;\":\"⎴\",\"&OverParenthesis;\":\"⏜\",\"&PartialD;\":\"∂\",\"&Pcy;\":\"П\",\"&Pfr;\":\"𝔓\",\"&Phi;\":\"Φ\",\"&Pi;\":\"Π\",\"&PlusMinus;\":\"±\",\"&Poincareplane;\":\"ℌ\",\"&Popf;\":\"ℙ\",\"&Pr;\":\"⪻\",\"&Precedes;\":\"≺\",\"&PrecedesEqual;\":\"⪯\",\"&PrecedesSlantEqual;\":\"≼\",\"&PrecedesTilde;\":\"≾\",\"&Prime;\":\"″\",\"&Product;\":\"∏\",\"&Proportion;\":\"∷\",\"&Proportional;\":\"∝\",\"&Pscr;\":\"𝒫\",\"&Psi;\":\"Ψ\",\"&QUOT\":'\"',\"&QUOT;\":'\"',\"&Qfr;\":\"𝔔\",\"&Qopf;\":\"ℚ\",\"&Qscr;\":\"𝒬\",\"&RBarr;\":\"⤐\",\"&REG\":\"®\",\"&REG;\":\"®\",\"&Racute;\":\"Ŕ\",\"&Rang;\":\"⟫\",\"&Rarr;\":\"↠\",\"&Rarrtl;\":\"⤖\",\"&Rcaron;\":\"Ř\",\"&Rcedil;\":\"Ŗ\",\"&Rcy;\":\"Р\",\"&Re;\":\"ℜ\",\"&ReverseElement;\":\"∋\",\"&ReverseEquilibrium;\":\"⇋\",\"&ReverseUpEquilibrium;\":\"⥯\",\"&Rfr;\":\"ℜ\",\"&Rho;\":\"Ρ\",\"&RightAngleBracket;\":\"⟩\",\"&RightArrow;\":\"→\",\"&RightArrowBar;\":\"⇥\",\"&RightArrowLeftArrow;\":\"⇄\",\"&RightCeiling;\":\"⌉\",\"&RightDoubleBracket;\":\"⟧\",\"&RightDownTeeVector;\":\"⥝\",\"&RightDownVector;\":\"⇂\",\"&RightDownVectorBar;\":\"⥕\",\"&RightFloor;\":\"⌋\",\"&RightTee;\":\"⊢\",\"&RightTeeArrow;\":\"↦\",\"&RightTeeVector;\":\"⥛\",\"&RightTriangle;\":\"⊳\",\"&RightTriangleBar;\":\"⧐\",\"&RightTriangleEqual;\":\"⊵\",\"&RightUpDownVector;\":\"⥏\",\"&RightUpTeeVector;\":\"⥜\",\"&RightUpVector;\":\"↾\",\"&RightUpVectorBar;\":\"⥔\",\"&RightVector;\":\"⇀\",\"&RightVectorBar;\":\"⥓\",\"&Rightarrow;\":\"⇒\",\"&Ropf;\":\"ℝ\",\"&RoundImplies;\":\"⥰\",\"&Rrightarrow;\":\"⇛\",\"&Rscr;\":\"ℛ\",\"&Rsh;\":\"↱\",\"&RuleDelayed;\":\"⧴\",\"&SHCHcy;\":\"Щ\",\"&SHcy;\":\"Ш\",\"&SOFTcy;\":\"Ь\",\"&Sacute;\":\"Ś\",\"&Sc;\":\"⪼\",\"&Scaron;\":\"Š\",\"&Scedil;\":\"Ş\",\"&Scirc;\":\"Ŝ\",\"&Scy;\":\"С\",\"&Sfr;\":\"𝔖\",\"&ShortDownArrow;\":\"↓\",\"&ShortLeftArrow;\":\"←\",\"&ShortRightArrow;\":\"→\",\"&ShortUpArrow;\":\"↑\",\"&Sigma;\":\"Σ\",\"&SmallCircle;\":\"∘\",\"&Sopf;\":\"𝕊\",\"&Sqrt;\":\"√\",\"&Square;\":\"□\",\"&SquareIntersection;\":\"⊓\",\"&SquareSubset;\":\"⊏\",\"&SquareSubsetEqual;\":\"⊑\",\"&SquareSuperset;\":\"⊐\",\"&SquareSupersetEqual;\":\"⊒\",\"&SquareUnion;\":\"⊔\",\"&Sscr;\":\"𝒮\",\"&Star;\":\"⋆\",\"&Sub;\":\"⋐\",\"&Subset;\":\"⋐\",\"&SubsetEqual;\":\"⊆\",\"&Succeeds;\":\"≻\",\"&SucceedsEqual;\":\"⪰\",\"&SucceedsSlantEqual;\":\"≽\",\"&SucceedsTilde;\":\"≿\",\"&SuchThat;\":\"∋\",\"&Sum;\":\"∑\",\"&Sup;\":\"⋑\",\"&Superset;\":\"⊃\",\"&SupersetEqual;\":\"⊇\",\"&Supset;\":\"⋑\",\"&THORN\":\"Þ\",\"&THORN;\":\"Þ\",\"&TRADE;\":\"™\",\"&TSHcy;\":\"Ћ\",\"&TScy;\":\"Ц\",\"&Tab;\":\"\\t\",\"&Tau;\":\"Τ\",\"&Tcaron;\":\"Ť\",\"&Tcedil;\":\"Ţ\",\"&Tcy;\":\"Т\",\"&Tfr;\":\"𝔗\",\"&Therefore;\":\"∴\",\"&Theta;\":\"Θ\",\"&ThickSpace;\":\"  \",\"&ThinSpace;\":\" \",\"&Tilde;\":\"∼\",\"&TildeEqual;\":\"≃\",\"&TildeFullEqual;\":\"≅\",\"&TildeTilde;\":\"≈\",\"&Topf;\":\"𝕋\",\"&TripleDot;\":\"⃛\",\"&Tscr;\":\"𝒯\",\"&Tstrok;\":\"Ŧ\",\"&Uacute\":\"Ú\",\"&Uacute;\":\"Ú\",\"&Uarr;\":\"↟\",\"&Uarrocir;\":\"⥉\",\"&Ubrcy;\":\"Ў\",\"&Ubreve;\":\"Ŭ\",\"&Ucirc\":\"Û\",\"&Ucirc;\":\"Û\",\"&Ucy;\":\"У\",\"&Udblac;\":\"Ű\",\"&Ufr;\":\"𝔘\",\"&Ugrave\":\"Ù\",\"&Ugrave;\":\"Ù\",\"&Umacr;\":\"Ū\",\"&UnderBar;\":\"_\",\"&UnderBrace;\":\"⏟\",\"&UnderBracket;\":\"⎵\",\"&UnderParenthesis;\":\"⏝\",\"&Union;\":\"⋃\",\"&UnionPlus;\":\"⊎\",\"&Uogon;\":\"Ų\",\"&Uopf;\":\"𝕌\",\"&UpArrow;\":\"↑\",\"&UpArrowBar;\":\"⤒\",\"&UpArrowDownArrow;\":\"⇅\",\"&UpDownArrow;\":\"↕\",\"&UpEquilibrium;\":\"⥮\",\"&UpTee;\":\"⊥\",\"&UpTeeArrow;\":\"↥\",\"&Uparrow;\":\"⇑\",\"&Updownarrow;\":\"⇕\",\"&UpperLeftArrow;\":\"↖\",\"&UpperRightArrow;\":\"↗\",\"&Upsi;\":\"ϒ\",\"&Upsilon;\":\"Υ\",\"&Uring;\":\"Ů\",\"&Uscr;\":\"𝒰\",\"&Utilde;\":\"Ũ\",\"&Uuml\":\"Ü\",\"&Uuml;\":\"Ü\",\"&VDash;\":\"⊫\",\"&Vbar;\":\"⫫\",\"&Vcy;\":\"В\",\"&Vdash;\":\"⊩\",\"&Vdashl;\":\"⫦\",\"&Vee;\":\"⋁\",\"&Verbar;\":\"‖\",\"&Vert;\":\"‖\",\"&VerticalBar;\":\"∣\",\"&VerticalLine;\":\"|\",\"&VerticalSeparator;\":\"❘\",\"&VerticalTilde;\":\"≀\",\"&VeryThinSpace;\":\" \",\"&Vfr;\":\"𝔙\",\"&Vopf;\":\"𝕍\",\"&Vscr;\":\"𝒱\",\"&Vvdash;\":\"⊪\",\"&Wcirc;\":\"Ŵ\",\"&Wedge;\":\"⋀\",\"&Wfr;\":\"𝔚\",\"&Wopf;\":\"𝕎\",\"&Wscr;\":\"𝒲\",\"&Xfr;\":\"𝔛\",\"&Xi;\":\"Ξ\",\"&Xopf;\":\"𝕏\",\"&Xscr;\":\"𝒳\",\"&YAcy;\":\"Я\",\"&YIcy;\":\"Ї\",\"&YUcy;\":\"Ю\",\"&Yacute\":\"Ý\",\"&Yacute;\":\"Ý\",\"&Ycirc;\":\"Ŷ\",\"&Ycy;\":\"Ы\",\"&Yfr;\":\"𝔜\",\"&Yopf;\":\"𝕐\",\"&Yscr;\":\"𝒴\",\"&Yuml;\":\"Ÿ\",\"&ZHcy;\":\"Ж\",\"&Zacute;\":\"Ź\",\"&Zcaron;\":\"Ž\",\"&Zcy;\":\"З\",\"&Zdot;\":\"Ż\",\"&ZeroWidthSpace;\":\"​\",\"&Zeta;\":\"Ζ\",\"&Zfr;\":\"ℨ\",\"&Zopf;\":\"ℤ\",\"&Zscr;\":\"𝒵\",\"&aacute\":\"á\",\"&aacute;\":\"á\",\"&abreve;\":\"ă\",\"&ac;\":\"∾\",\"&acE;\":\"∾̳\",\"&acd;\":\"∿\",\"&acirc\":\"â\",\"&acirc;\":\"â\",\"&acute\":\"´\",\"&acute;\":\"´\",\"&acy;\":\"а\",\"&aelig\":\"æ\",\"&aelig;\":\"æ\",\"&af;\":\"⁡\",\"&afr;\":\"𝔞\",\"&agrave\":\"à\",\"&agrave;\":\"à\",\"&alefsym;\":\"ℵ\",\"&aleph;\":\"ℵ\",\"&alpha;\":\"α\",\"&amacr;\":\"ā\",\"&amalg;\":\"⨿\",\"&amp\":\"&\",\"&amp;\":\"&\",\"&and;\":\"∧\",\"&andand;\":\"⩕\",\"&andd;\":\"⩜\",\"&andslope;\":\"⩘\",\"&andv;\":\"⩚\",\"&ang;\":\"∠\",\"&ange;\":\"⦤\",\"&angle;\":\"∠\",\"&angmsd;\":\"∡\",\"&angmsdaa;\":\"⦨\",\"&angmsdab;\":\"⦩\",\"&angmsdac;\":\"⦪\",\"&angmsdad;\":\"⦫\",\"&angmsdae;\":\"⦬\",\"&angmsdaf;\":\"⦭\",\"&angmsdag;\":\"⦮\",\"&angmsdah;\":\"⦯\",\"&angrt;\":\"∟\",\"&angrtvb;\":\"⊾\",\"&angrtvbd;\":\"⦝\",\"&angsph;\":\"∢\",\"&angst;\":\"Å\",\"&angzarr;\":\"⍼\",\"&aogon;\":\"ą\",\"&aopf;\":\"𝕒\",\"&ap;\":\"≈\",\"&apE;\":\"⩰\",\"&apacir;\":\"⩯\",\"&ape;\":\"≊\",\"&apid;\":\"≋\",\"&apos;\":\"'\",\"&approx;\":\"≈\",\"&approxeq;\":\"≊\",\"&aring\":\"å\",\"&aring;\":\"å\",\"&ascr;\":\"𝒶\",\"&ast;\":\"*\",\"&asymp;\":\"≈\",\"&asympeq;\":\"≍\",\"&atilde\":\"ã\",\"&atilde;\":\"ã\",\"&auml\":\"ä\",\"&auml;\":\"ä\",\"&awconint;\":\"∳\",\"&awint;\":\"⨑\",\"&bNot;\":\"⫭\",\"&backcong;\":\"≌\",\"&backepsilon;\":\"϶\",\"&backprime;\":\"‵\",\"&backsim;\":\"∽\",\"&backsimeq;\":\"⋍\",\"&barvee;\":\"⊽\",\"&barwed;\":\"⌅\",\"&barwedge;\":\"⌅\",\"&bbrk;\":\"⎵\",\"&bbrktbrk;\":\"⎶\",\"&bcong;\":\"≌\",\"&bcy;\":\"б\",\"&bdquo;\":\"„\",\"&becaus;\":\"∵\",\"&because;\":\"∵\",\"&bemptyv;\":\"⦰\",\"&bepsi;\":\"϶\",\"&bernou;\":\"ℬ\",\"&beta;\":\"β\",\"&beth;\":\"ℶ\",\"&between;\":\"≬\",\"&bfr;\":\"𝔟\",\"&bigcap;\":\"⋂\",\"&bigcirc;\":\"◯\",\"&bigcup;\":\"⋃\",\"&bigodot;\":\"⨀\",\"&bigoplus;\":\"⨁\",\"&bigotimes;\":\"⨂\",\"&bigsqcup;\":\"⨆\",\"&bigstar;\":\"★\",\"&bigtriangledown;\":\"▽\",\"&bigtriangleup;\":\"△\",\"&biguplus;\":\"⨄\",\"&bigvee;\":\"⋁\",\"&bigwedge;\":\"⋀\",\"&bkarow;\":\"⤍\",\"&blacklozenge;\":\"⧫\",\"&blacksquare;\":\"▪\",\"&blacktriangle;\":\"▴\",\"&blacktriangledown;\":\"▾\",\"&blacktriangleleft;\":\"◂\",\"&blacktriangleright;\":\"▸\",\"&blank;\":\"␣\",\"&blk12;\":\"▒\",\"&blk14;\":\"░\",\"&blk34;\":\"▓\",\"&block;\":\"█\",\"&bne;\":\"=⃥\",\"&bnequiv;\":\"≡⃥\",\"&bnot;\":\"⌐\",\"&bopf;\":\"𝕓\",\"&bot;\":\"⊥\",\"&bottom;\":\"⊥\",\"&bowtie;\":\"⋈\",\"&boxDL;\":\"╗\",\"&boxDR;\":\"╔\",\"&boxDl;\":\"╖\",\"&boxDr;\":\"╓\",\"&boxH;\":\"═\",\"&boxHD;\":\"╦\",\"&boxHU;\":\"╩\",\"&boxHd;\":\"╤\",\"&boxHu;\":\"╧\",\"&boxUL;\":\"╝\",\"&boxUR;\":\"╚\",\"&boxUl;\":\"╜\",\"&boxUr;\":\"╙\",\"&boxV;\":\"║\",\"&boxVH;\":\"╬\",\"&boxVL;\":\"╣\",\"&boxVR;\":\"╠\",\"&boxVh;\":\"╫\",\"&boxVl;\":\"╢\",\"&boxVr;\":\"╟\",\"&boxbox;\":\"⧉\",\"&boxdL;\":\"╕\",\"&boxdR;\":\"╒\",\"&boxdl;\":\"┐\",\"&boxdr;\":\"┌\",\"&boxh;\":\"─\",\"&boxhD;\":\"╥\",\"&boxhU;\":\"╨\",\"&boxhd;\":\"┬\",\"&boxhu;\":\"┴\",\"&boxminus;\":\"⊟\",\"&boxplus;\":\"⊞\",\"&boxtimes;\":\"⊠\",\"&boxuL;\":\"╛\",\"&boxuR;\":\"╘\",\"&boxul;\":\"┘\",\"&boxur;\":\"└\",\"&boxv;\":\"│\",\"&boxvH;\":\"╪\",\"&boxvL;\":\"╡\",\"&boxvR;\":\"╞\",\"&boxvh;\":\"┼\",\"&boxvl;\":\"┤\",\"&boxvr;\":\"├\",\"&bprime;\":\"‵\",\"&breve;\":\"˘\",\"&brvbar\":\"¦\",\"&brvbar;\":\"¦\",\"&bscr;\":\"𝒷\",\"&bsemi;\":\"⁏\",\"&bsim;\":\"∽\",\"&bsime;\":\"⋍\",\"&bsol;\":\"\\\\\",\"&bsolb;\":\"⧅\",\"&bsolhsub;\":\"⟈\",\"&bull;\":\"•\",\"&bullet;\":\"•\",\"&bump;\":\"≎\",\"&bumpE;\":\"⪮\",\"&bumpe;\":\"≏\",\"&bumpeq;\":\"≏\",\"&cacute;\":\"ć\",\"&cap;\":\"∩\",\"&capand;\":\"⩄\",\"&capbrcup;\":\"⩉\",\"&capcap;\":\"⩋\",\"&capcup;\":\"⩇\",\"&capdot;\":\"⩀\",\"&caps;\":\"∩︀\",\"&caret;\":\"⁁\",\"&caron;\":\"ˇ\",\"&ccaps;\":\"⩍\",\"&ccaron;\":\"č\",\"&ccedil\":\"ç\",\"&ccedil;\":\"ç\",\"&ccirc;\":\"ĉ\",\"&ccups;\":\"⩌\",\"&ccupssm;\":\"⩐\",\"&cdot;\":\"ċ\",\"&cedil\":\"¸\",\"&cedil;\":\"¸\",\"&cemptyv;\":\"⦲\",\"&cent\":\"¢\",\"&cent;\":\"¢\",\"&centerdot;\":\"·\",\"&cfr;\":\"𝔠\",\"&chcy;\":\"ч\",\"&check;\":\"✓\",\"&checkmark;\":\"✓\",\"&chi;\":\"χ\",\"&cir;\":\"○\",\"&cirE;\":\"⧃\",\"&circ;\":\"ˆ\",\"&circeq;\":\"≗\",\"&circlearrowleft;\":\"↺\",\"&circlearrowright;\":\"↻\",\"&circledR;\":\"®\",\"&circledS;\":\"Ⓢ\",\"&circledast;\":\"⊛\",\"&circledcirc;\":\"⊚\",\"&circleddash;\":\"⊝\",\"&cire;\":\"≗\",\"&cirfnint;\":\"⨐\",\"&cirmid;\":\"⫯\",\"&cirscir;\":\"⧂\",\"&clubs;\":\"♣\",\"&clubsuit;\":\"♣\",\"&colon;\":\":\",\"&colone;\":\"≔\",\"&coloneq;\":\"≔\",\"&comma;\":\",\",\"&commat;\":\"@\",\"&comp;\":\"∁\",\"&compfn;\":\"∘\",\"&complement;\":\"∁\",\"&complexes;\":\"ℂ\",\"&cong;\":\"≅\",\"&congdot;\":\"⩭\",\"&conint;\":\"∮\",\"&copf;\":\"𝕔\",\"&coprod;\":\"∐\",\"&copy\":\"©\",\"&copy;\":\"©\",\"&copysr;\":\"℗\",\"&crarr;\":\"↵\",\"&cross;\":\"✗\",\"&cscr;\":\"𝒸\",\"&csub;\":\"⫏\",\"&csube;\":\"⫑\",\"&csup;\":\"⫐\",\"&csupe;\":\"⫒\",\"&ctdot;\":\"⋯\",\"&cudarrl;\":\"⤸\",\"&cudarrr;\":\"⤵\",\"&cuepr;\":\"⋞\",\"&cuesc;\":\"⋟\",\"&cularr;\":\"↶\",\"&cularrp;\":\"⤽\",\"&cup;\":\"∪\",\"&cupbrcap;\":\"⩈\",\"&cupcap;\":\"⩆\",\"&cupcup;\":\"⩊\",\"&cupdot;\":\"⊍\",\"&cupor;\":\"⩅\",\"&cups;\":\"∪︀\",\"&curarr;\":\"↷\",\"&curarrm;\":\"⤼\",\"&curlyeqprec;\":\"⋞\",\"&curlyeqsucc;\":\"⋟\",\"&curlyvee;\":\"⋎\",\"&curlywedge;\":\"⋏\",\"&curren\":\"¤\",\"&curren;\":\"¤\",\"&curvearrowleft;\":\"↶\",\"&curvearrowright;\":\"↷\",\"&cuvee;\":\"⋎\",\"&cuwed;\":\"⋏\",\"&cwconint;\":\"∲\",\"&cwint;\":\"∱\",\"&cylcty;\":\"⌭\",\"&dArr;\":\"⇓\",\"&dHar;\":\"⥥\",\"&dagger;\":\"†\",\"&daleth;\":\"ℸ\",\"&darr;\":\"↓\",\"&dash;\":\"‐\",\"&dashv;\":\"⊣\",\"&dbkarow;\":\"⤏\",\"&dblac;\":\"˝\",\"&dcaron;\":\"ď\",\"&dcy;\":\"д\",\"&dd;\":\"ⅆ\",\"&ddagger;\":\"‡\",\"&ddarr;\":\"⇊\",\"&ddotseq;\":\"⩷\",\"&deg\":\"°\",\"&deg;\":\"°\",\"&delta;\":\"δ\",\"&demptyv;\":\"⦱\",\"&dfisht;\":\"⥿\",\"&dfr;\":\"𝔡\",\"&dharl;\":\"⇃\",\"&dharr;\":\"⇂\",\"&diam;\":\"⋄\",\"&diamond;\":\"⋄\",\"&diamondsuit;\":\"♦\",\"&diams;\":\"♦\",\"&die;\":\"¨\",\"&digamma;\":\"ϝ\",\"&disin;\":\"⋲\",\"&div;\":\"÷\",\"&divide\":\"÷\",\"&divide;\":\"÷\",\"&divideontimes;\":\"⋇\",\"&divonx;\":\"⋇\",\"&djcy;\":\"ђ\",\"&dlcorn;\":\"⌞\",\"&dlcrop;\":\"⌍\",\"&dollar;\":\"$\",\"&dopf;\":\"𝕕\",\"&dot;\":\"˙\",\"&doteq;\":\"≐\",\"&doteqdot;\":\"≑\",\"&dotminus;\":\"∸\",\"&dotplus;\":\"∔\",\"&dotsquare;\":\"⊡\",\"&doublebarwedge;\":\"⌆\",\"&downarrow;\":\"↓\",\"&downdownarrows;\":\"⇊\",\"&downharpoonleft;\":\"⇃\",\"&downharpoonright;\":\"⇂\",\"&drbkarow;\":\"⤐\",\"&drcorn;\":\"⌟\",\"&drcrop;\":\"⌌\",\"&dscr;\":\"𝒹\",\"&dscy;\":\"ѕ\",\"&dsol;\":\"⧶\",\"&dstrok;\":\"đ\",\"&dtdot;\":\"⋱\",\"&dtri;\":\"▿\",\"&dtrif;\":\"▾\",\"&duarr;\":\"⇵\",\"&duhar;\":\"⥯\",\"&dwangle;\":\"⦦\",\"&dzcy;\":\"џ\",\"&dzigrarr;\":\"⟿\",\"&eDDot;\":\"⩷\",\"&eDot;\":\"≑\",\"&eacute\":\"é\",\"&eacute;\":\"é\",\"&easter;\":\"⩮\",\"&ecaron;\":\"ě\",\"&ecir;\":\"≖\",\"&ecirc\":\"ê\",\"&ecirc;\":\"ê\",\"&ecolon;\":\"≕\",\"&ecy;\":\"э\",\"&edot;\":\"ė\",\"&ee;\":\"ⅇ\",\"&efDot;\":\"≒\",\"&efr;\":\"𝔢\",\"&eg;\":\"⪚\",\"&egrave\":\"è\",\"&egrave;\":\"è\",\"&egs;\":\"⪖\",\"&egsdot;\":\"⪘\",\"&el;\":\"⪙\",\"&elinters;\":\"⏧\",\"&ell;\":\"ℓ\",\"&els;\":\"⪕\",\"&elsdot;\":\"⪗\",\"&emacr;\":\"ē\",\"&empty;\":\"∅\",\"&emptyset;\":\"∅\",\"&emptyv;\":\"∅\",\"&emsp13;\":\" \",\"&emsp14;\":\" \",\"&emsp;\":\" \",\"&eng;\":\"ŋ\",\"&ensp;\":\" \",\"&eogon;\":\"ę\",\"&eopf;\":\"𝕖\",\"&epar;\":\"⋕\",\"&eparsl;\":\"⧣\",\"&eplus;\":\"⩱\",\"&epsi;\":\"ε\",\"&epsilon;\":\"ε\",\"&epsiv;\":\"ϵ\",\"&eqcirc;\":\"≖\",\"&eqcolon;\":\"≕\",\"&eqsim;\":\"≂\",\"&eqslantgtr;\":\"⪖\",\"&eqslantless;\":\"⪕\",\"&equals;\":\"=\",\"&equest;\":\"≟\",\"&equiv;\":\"≡\",\"&equivDD;\":\"⩸\",\"&eqvparsl;\":\"⧥\",\"&erDot;\":\"≓\",\"&erarr;\":\"⥱\",\"&escr;\":\"ℯ\",\"&esdot;\":\"≐\",\"&esim;\":\"≂\",\"&eta;\":\"η\",\"&eth\":\"ð\",\"&eth;\":\"ð\",\"&euml\":\"ë\",\"&euml;\":\"ë\",\"&euro;\":\"€\",\"&excl;\":\"!\",\"&exist;\":\"∃\",\"&expectation;\":\"ℰ\",\"&exponentiale;\":\"ⅇ\",\"&fallingdotseq;\":\"≒\",\"&fcy;\":\"ф\",\"&female;\":\"♀\",\"&ffilig;\":\"ﬃ\",\"&fflig;\":\"ﬀ\",\"&ffllig;\":\"ﬄ\",\"&ffr;\":\"𝔣\",\"&filig;\":\"ﬁ\",\"&fjlig;\":\"fj\",\"&flat;\":\"♭\",\"&fllig;\":\"ﬂ\",\"&fltns;\":\"▱\",\"&fnof;\":\"ƒ\",\"&fopf;\":\"𝕗\",\"&forall;\":\"∀\",\"&fork;\":\"⋔\",\"&forkv;\":\"⫙\",\"&fpartint;\":\"⨍\",\"&frac12\":\"½\",\"&frac12;\":\"½\",\"&frac13;\":\"⅓\",\"&frac14\":\"¼\",\"&frac14;\":\"¼\",\"&frac15;\":\"⅕\",\"&frac16;\":\"⅙\",\"&frac18;\":\"⅛\",\"&frac23;\":\"⅔\",\"&frac25;\":\"⅖\",\"&frac34\":\"¾\",\"&frac34;\":\"¾\",\"&frac35;\":\"⅗\",\"&frac38;\":\"⅜\",\"&frac45;\":\"⅘\",\"&frac56;\":\"⅚\",\"&frac58;\":\"⅝\",\"&frac78;\":\"⅞\",\"&frasl;\":\"⁄\",\"&frown;\":\"⌢\",\"&fscr;\":\"𝒻\",\"&gE;\":\"≧\",\"&gEl;\":\"⪌\",\"&gacute;\":\"ǵ\",\"&gamma;\":\"γ\",\"&gammad;\":\"ϝ\",\"&gap;\":\"⪆\",\"&gbreve;\":\"ğ\",\"&gcirc;\":\"ĝ\",\"&gcy;\":\"г\",\"&gdot;\":\"ġ\",\"&ge;\":\"≥\",\"&gel;\":\"⋛\",\"&geq;\":\"≥\",\"&geqq;\":\"≧\",\"&geqslant;\":\"⩾\",\"&ges;\":\"⩾\",\"&gescc;\":\"⪩\",\"&gesdot;\":\"⪀\",\"&gesdoto;\":\"⪂\",\"&gesdotol;\":\"⪄\",\"&gesl;\":\"⋛︀\",\"&gesles;\":\"⪔\",\"&gfr;\":\"𝔤\",\"&gg;\":\"≫\",\"&ggg;\":\"⋙\",\"&gimel;\":\"ℷ\",\"&gjcy;\":\"ѓ\",\"&gl;\":\"≷\",\"&glE;\":\"⪒\",\"&gla;\":\"⪥\",\"&glj;\":\"⪤\",\"&gnE;\":\"≩\",\"&gnap;\":\"⪊\",\"&gnapprox;\":\"⪊\",\"&gne;\":\"⪈\",\"&gneq;\":\"⪈\",\"&gneqq;\":\"≩\",\"&gnsim;\":\"⋧\",\"&gopf;\":\"𝕘\",\"&grave;\":\"`\",\"&gscr;\":\"ℊ\",\"&gsim;\":\"≳\",\"&gsime;\":\"⪎\",\"&gsiml;\":\"⪐\",\"&gt\":\">\",\"&gt;\":\">\",\"&gtcc;\":\"⪧\",\"&gtcir;\":\"⩺\",\"&gtdot;\":\"⋗\",\"&gtlPar;\":\"⦕\",\"&gtquest;\":\"⩼\",\"&gtrapprox;\":\"⪆\",\"&gtrarr;\":\"⥸\",\"&gtrdot;\":\"⋗\",\"&gtreqless;\":\"⋛\",\"&gtreqqless;\":\"⪌\",\"&gtrless;\":\"≷\",\"&gtrsim;\":\"≳\",\"&gvertneqq;\":\"≩︀\",\"&gvnE;\":\"≩︀\",\"&hArr;\":\"⇔\",\"&hairsp;\":\" \",\"&half;\":\"½\",\"&hamilt;\":\"ℋ\",\"&hardcy;\":\"ъ\",\"&harr;\":\"↔\",\"&harrcir;\":\"⥈\",\"&harrw;\":\"↭\",\"&hbar;\":\"ℏ\",\"&hcirc;\":\"ĥ\",\"&hearts;\":\"♥\",\"&heartsuit;\":\"♥\",\"&hellip;\":\"…\",\"&hercon;\":\"⊹\",\"&hfr;\":\"𝔥\",\"&hksearow;\":\"⤥\",\"&hkswarow;\":\"⤦\",\"&hoarr;\":\"⇿\",\"&homtht;\":\"∻\",\"&hookleftarrow;\":\"↩\",\"&hookrightarrow;\":\"↪\",\"&hopf;\":\"𝕙\",\"&horbar;\":\"―\",\"&hscr;\":\"𝒽\",\"&hslash;\":\"ℏ\",\"&hstrok;\":\"ħ\",\"&hybull;\":\"⁃\",\"&hyphen;\":\"‐\",\"&iacute\":\"í\",\"&iacute;\":\"í\",\"&ic;\":\"⁣\",\"&icirc\":\"î\",\"&icirc;\":\"î\",\"&icy;\":\"и\",\"&iecy;\":\"е\",\"&iexcl\":\"¡\",\"&iexcl;\":\"¡\",\"&iff;\":\"⇔\",\"&ifr;\":\"𝔦\",\"&igrave\":\"ì\",\"&igrave;\":\"ì\",\"&ii;\":\"ⅈ\",\"&iiiint;\":\"⨌\",\"&iiint;\":\"∭\",\"&iinfin;\":\"⧜\",\"&iiota;\":\"℩\",\"&ijlig;\":\"ĳ\",\"&imacr;\":\"ī\",\"&image;\":\"ℑ\",\"&imagline;\":\"ℐ\",\"&imagpart;\":\"ℑ\",\"&imath;\":\"ı\",\"&imof;\":\"⊷\",\"&imped;\":\"Ƶ\",\"&in;\":\"∈\",\"&incare;\":\"℅\",\"&infin;\":\"∞\",\"&infintie;\":\"⧝\",\"&inodot;\":\"ı\",\"&int;\":\"∫\",\"&intcal;\":\"⊺\",\"&integers;\":\"ℤ\",\"&intercal;\":\"⊺\",\"&intlarhk;\":\"⨗\",\"&intprod;\":\"⨼\",\"&iocy;\":\"ё\",\"&iogon;\":\"į\",\"&iopf;\":\"𝕚\",\"&iota;\":\"ι\",\"&iprod;\":\"⨼\",\"&iquest\":\"¿\",\"&iquest;\":\"¿\",\"&iscr;\":\"𝒾\",\"&isin;\":\"∈\",\"&isinE;\":\"⋹\",\"&isindot;\":\"⋵\",\"&isins;\":\"⋴\",\"&isinsv;\":\"⋳\",\"&isinv;\":\"∈\",\"&it;\":\"⁢\",\"&itilde;\":\"ĩ\",\"&iukcy;\":\"і\",\"&iuml\":\"ï\",\"&iuml;\":\"ï\",\"&jcirc;\":\"ĵ\",\"&jcy;\":\"й\",\"&jfr;\":\"𝔧\",\"&jmath;\":\"ȷ\",\"&jopf;\":\"𝕛\",\"&jscr;\":\"𝒿\",\"&jsercy;\":\"ј\",\"&jukcy;\":\"є\",\"&kappa;\":\"κ\",\"&kappav;\":\"ϰ\",\"&kcedil;\":\"ķ\",\"&kcy;\":\"к\",\"&kfr;\":\"𝔨\",\"&kgreen;\":\"ĸ\",\"&khcy;\":\"х\",\"&kjcy;\":\"ќ\",\"&kopf;\":\"𝕜\",\"&kscr;\":\"𝓀\",\"&lAarr;\":\"⇚\",\"&lArr;\":\"⇐\",\"&lAtail;\":\"⤛\",\"&lBarr;\":\"⤎\",\"&lE;\":\"≦\",\"&lEg;\":\"⪋\",\"&lHar;\":\"⥢\",\"&lacute;\":\"ĺ\",\"&laemptyv;\":\"⦴\",\"&lagran;\":\"ℒ\",\"&lambda;\":\"λ\",\"&lang;\":\"⟨\",\"&langd;\":\"⦑\",\"&langle;\":\"⟨\",\"&lap;\":\"⪅\",\"&laquo\":\"«\",\"&laquo;\":\"«\",\"&larr;\":\"←\",\"&larrb;\":\"⇤\",\"&larrbfs;\":\"⤟\",\"&larrfs;\":\"⤝\",\"&larrhk;\":\"↩\",\"&larrlp;\":\"↫\",\"&larrpl;\":\"⤹\",\"&larrsim;\":\"⥳\",\"&larrtl;\":\"↢\",\"&lat;\":\"⪫\",\"&latail;\":\"⤙\",\"&late;\":\"⪭\",\"&lates;\":\"⪭︀\",\"&lbarr;\":\"⤌\",\"&lbbrk;\":\"❲\",\"&lbrace;\":\"{\",\"&lbrack;\":\"[\",\"&lbrke;\":\"⦋\",\"&lbrksld;\":\"⦏\",\"&lbrkslu;\":\"⦍\",\"&lcaron;\":\"ľ\",\"&lcedil;\":\"ļ\",\"&lceil;\":\"⌈\",\"&lcub;\":\"{\",\"&lcy;\":\"л\",\"&ldca;\":\"⤶\",\"&ldquo;\":\"“\",\"&ldquor;\":\"„\",\"&ldrdhar;\":\"⥧\",\"&ldrushar;\":\"⥋\",\"&ldsh;\":\"↲\",\"&le;\":\"≤\",\"&leftarrow;\":\"←\",\"&leftarrowtail;\":\"↢\",\"&leftharpoondown;\":\"↽\",\"&leftharpoonup;\":\"↼\",\"&leftleftarrows;\":\"⇇\",\"&leftrightarrow;\":\"↔\",\"&leftrightarrows;\":\"⇆\",\"&leftrightharpoons;\":\"⇋\",\"&leftrightsquigarrow;\":\"↭\",\"&leftthreetimes;\":\"⋋\",\"&leg;\":\"⋚\",\"&leq;\":\"≤\",\"&leqq;\":\"≦\",\"&leqslant;\":\"⩽\",\"&les;\":\"⩽\",\"&lescc;\":\"⪨\",\"&lesdot;\":\"⩿\",\"&lesdoto;\":\"⪁\",\"&lesdotor;\":\"⪃\",\"&lesg;\":\"⋚︀\",\"&lesges;\":\"⪓\",\"&lessapprox;\":\"⪅\",\"&lessdot;\":\"⋖\",\"&lesseqgtr;\":\"⋚\",\"&lesseqqgtr;\":\"⪋\",\"&lessgtr;\":\"≶\",\"&lesssim;\":\"≲\",\"&lfisht;\":\"⥼\",\"&lfloor;\":\"⌊\",\"&lfr;\":\"𝔩\",\"&lg;\":\"≶\",\"&lgE;\":\"⪑\",\"&lhard;\":\"↽\",\"&lharu;\":\"↼\",\"&lharul;\":\"⥪\",\"&lhblk;\":\"▄\",\"&ljcy;\":\"љ\",\"&ll;\":\"≪\",\"&llarr;\":\"⇇\",\"&llcorner;\":\"⌞\",\"&llhard;\":\"⥫\",\"&lltri;\":\"◺\",\"&lmidot;\":\"ŀ\",\"&lmoust;\":\"⎰\",\"&lmoustache;\":\"⎰\",\"&lnE;\":\"≨\",\"&lnap;\":\"⪉\",\"&lnapprox;\":\"⪉\",\"&lne;\":\"⪇\",\"&lneq;\":\"⪇\",\"&lneqq;\":\"≨\",\"&lnsim;\":\"⋦\",\"&loang;\":\"⟬\",\"&loarr;\":\"⇽\",\"&lobrk;\":\"⟦\",\"&longleftarrow;\":\"⟵\",\"&longleftrightarrow;\":\"⟷\",\"&longmapsto;\":\"⟼\",\"&longrightarrow;\":\"⟶\",\"&looparrowleft;\":\"↫\",\"&looparrowright;\":\"↬\",\"&lopar;\":\"⦅\",\"&lopf;\":\"𝕝\",\"&loplus;\":\"⨭\",\"&lotimes;\":\"⨴\",\"&lowast;\":\"∗\",\"&lowbar;\":\"_\",\"&loz;\":\"◊\",\"&lozenge;\":\"◊\",\"&lozf;\":\"⧫\",\"&lpar;\":\"(\",\"&lparlt;\":\"⦓\",\"&lrarr;\":\"⇆\",\"&lrcorner;\":\"⌟\",\"&lrhar;\":\"⇋\",\"&lrhard;\":\"⥭\",\"&lrm;\":\"‎\",\"&lrtri;\":\"⊿\",\"&lsaquo;\":\"‹\",\"&lscr;\":\"𝓁\",\"&lsh;\":\"↰\",\"&lsim;\":\"≲\",\"&lsime;\":\"⪍\",\"&lsimg;\":\"⪏\",\"&lsqb;\":\"[\",\"&lsquo;\":\"‘\",\"&lsquor;\":\"‚\",\"&lstrok;\":\"ł\",\"&lt\":\"<\",\"&lt;\":\"<\",\"&ltcc;\":\"⪦\",\"&ltcir;\":\"⩹\",\"&ltdot;\":\"⋖\",\"&lthree;\":\"⋋\",\"&ltimes;\":\"⋉\",\"&ltlarr;\":\"⥶\",\"&ltquest;\":\"⩻\",\"&ltrPar;\":\"⦖\",\"&ltri;\":\"◃\",\"&ltrie;\":\"⊴\",\"&ltrif;\":\"◂\",\"&lurdshar;\":\"⥊\",\"&luruhar;\":\"⥦\",\"&lvertneqq;\":\"≨︀\",\"&lvnE;\":\"≨︀\",\"&mDDot;\":\"∺\",\"&macr\":\"¯\",\"&macr;\":\"¯\",\"&male;\":\"♂\",\"&malt;\":\"✠\",\"&maltese;\":\"✠\",\"&map;\":\"↦\",\"&mapsto;\":\"↦\",\"&mapstodown;\":\"↧\",\"&mapstoleft;\":\"↤\",\"&mapstoup;\":\"↥\",\"&marker;\":\"▮\",\"&mcomma;\":\"⨩\",\"&mcy;\":\"м\",\"&mdash;\":\"—\",\"&measuredangle;\":\"∡\",\"&mfr;\":\"𝔪\",\"&mho;\":\"℧\",\"&micro\":\"µ\",\"&micro;\":\"µ\",\"&mid;\":\"∣\",\"&midast;\":\"*\",\"&midcir;\":\"⫰\",\"&middot\":\"·\",\"&middot;\":\"·\",\"&minus;\":\"−\",\"&minusb;\":\"⊟\",\"&minusd;\":\"∸\",\"&minusdu;\":\"⨪\",\"&mlcp;\":\"⫛\",\"&mldr;\":\"…\",\"&mnplus;\":\"∓\",\"&models;\":\"⊧\",\"&mopf;\":\"𝕞\",\"&mp;\":\"∓\",\"&mscr;\":\"𝓂\",\"&mstpos;\":\"∾\",\"&mu;\":\"μ\",\"&multimap;\":\"⊸\",\"&mumap;\":\"⊸\",\"&nGg;\":\"⋙̸\",\"&nGt;\":\"≫⃒\",\"&nGtv;\":\"≫̸\",\"&nLeftarrow;\":\"⇍\",\"&nLeftrightarrow;\":\"⇎\",\"&nLl;\":\"⋘̸\",\"&nLt;\":\"≪⃒\",\"&nLtv;\":\"≪̸\",\"&nRightarrow;\":\"⇏\",\"&nVDash;\":\"⊯\",\"&nVdash;\":\"⊮\",\"&nabla;\":\"∇\",\"&nacute;\":\"ń\",\"&nang;\":\"∠⃒\",\"&nap;\":\"≉\",\"&napE;\":\"⩰̸\",\"&napid;\":\"≋̸\",\"&napos;\":\"ŉ\",\"&napprox;\":\"≉\",\"&natur;\":\"♮\",\"&natural;\":\"♮\",\"&naturals;\":\"ℕ\",\"&nbsp\":\" \",\"&nbsp;\":\" \",\"&nbump;\":\"≎̸\",\"&nbumpe;\":\"≏̸\",\"&ncap;\":\"⩃\",\"&ncaron;\":\"ň\",\"&ncedil;\":\"ņ\",\"&ncong;\":\"≇\",\"&ncongdot;\":\"⩭̸\",\"&ncup;\":\"⩂\",\"&ncy;\":\"н\",\"&ndash;\":\"–\",\"&ne;\":\"≠\",\"&neArr;\":\"⇗\",\"&nearhk;\":\"⤤\",\"&nearr;\":\"↗\",\"&nearrow;\":\"↗\",\"&nedot;\":\"≐̸\",\"&nequiv;\":\"≢\",\"&nesear;\":\"⤨\",\"&nesim;\":\"≂̸\",\"&nexist;\":\"∄\",\"&nexists;\":\"∄\",\"&nfr;\":\"𝔫\",\"&ngE;\":\"≧̸\",\"&nge;\":\"≱\",\"&ngeq;\":\"≱\",\"&ngeqq;\":\"≧̸\",\"&ngeqslant;\":\"⩾̸\",\"&nges;\":\"⩾̸\",\"&ngsim;\":\"≵\",\"&ngt;\":\"≯\",\"&ngtr;\":\"≯\",\"&nhArr;\":\"⇎\",\"&nharr;\":\"↮\",\"&nhpar;\":\"⫲\",\"&ni;\":\"∋\",\"&nis;\":\"⋼\",\"&nisd;\":\"⋺\",\"&niv;\":\"∋\",\"&njcy;\":\"њ\",\"&nlArr;\":\"⇍\",\"&nlE;\":\"≦̸\",\"&nlarr;\":\"↚\",\"&nldr;\":\"‥\",\"&nle;\":\"≰\",\"&nleftarrow;\":\"↚\",\"&nleftrightarrow;\":\"↮\",\"&nleq;\":\"≰\",\"&nleqq;\":\"≦̸\",\"&nleqslant;\":\"⩽̸\",\"&nles;\":\"⩽̸\",\"&nless;\":\"≮\",\"&nlsim;\":\"≴\",\"&nlt;\":\"≮\",\"&nltri;\":\"⋪\",\"&nltrie;\":\"⋬\",\"&nmid;\":\"∤\",\"&nopf;\":\"𝕟\",\"&not\":\"¬\",\"&not;\":\"¬\",\"&notin;\":\"∉\",\"&notinE;\":\"⋹̸\",\"&notindot;\":\"⋵̸\",\"&notinva;\":\"∉\",\"&notinvb;\":\"⋷\",\"&notinvc;\":\"⋶\",\"&notni;\":\"∌\",\"&notniva;\":\"∌\",\"&notnivb;\":\"⋾\",\"&notnivc;\":\"⋽\",\"&npar;\":\"∦\",\"&nparallel;\":\"∦\",\"&nparsl;\":\"⫽⃥\",\"&npart;\":\"∂̸\",\"&npolint;\":\"⨔\",\"&npr;\":\"⊀\",\"&nprcue;\":\"⋠\",\"&npre;\":\"⪯̸\",\"&nprec;\":\"⊀\",\"&npreceq;\":\"⪯̸\",\"&nrArr;\":\"⇏\",\"&nrarr;\":\"↛\",\"&nrarrc;\":\"⤳̸\",\"&nrarrw;\":\"↝̸\",\"&nrightarrow;\":\"↛\",\"&nrtri;\":\"⋫\",\"&nrtrie;\":\"⋭\",\"&nsc;\":\"⊁\",\"&nsccue;\":\"⋡\",\"&nsce;\":\"⪰̸\",\"&nscr;\":\"𝓃\",\"&nshortmid;\":\"∤\",\"&nshortparallel;\":\"∦\",\"&nsim;\":\"≁\",\"&nsime;\":\"≄\",\"&nsimeq;\":\"≄\",\"&nsmid;\":\"∤\",\"&nspar;\":\"∦\",\"&nsqsube;\":\"⋢\",\"&nsqsupe;\":\"⋣\",\"&nsub;\":\"⊄\",\"&nsubE;\":\"⫅̸\",\"&nsube;\":\"⊈\",\"&nsubset;\":\"⊂⃒\",\"&nsubseteq;\":\"⊈\",\"&nsubseteqq;\":\"⫅̸\",\"&nsucc;\":\"⊁\",\"&nsucceq;\":\"⪰̸\",\"&nsup;\":\"⊅\",\"&nsupE;\":\"⫆̸\",\"&nsupe;\":\"⊉\",\"&nsupset;\":\"⊃⃒\",\"&nsupseteq;\":\"⊉\",\"&nsupseteqq;\":\"⫆̸\",\"&ntgl;\":\"≹\",\"&ntilde\":\"ñ\",\"&ntilde;\":\"ñ\",\"&ntlg;\":\"≸\",\"&ntriangleleft;\":\"⋪\",\"&ntrianglelefteq;\":\"⋬\",\"&ntriangleright;\":\"⋫\",\"&ntrianglerighteq;\":\"⋭\",\"&nu;\":\"ν\",\"&num;\":\"#\",\"&numero;\":\"№\",\"&numsp;\":\" \",\"&nvDash;\":\"⊭\",\"&nvHarr;\":\"⤄\",\"&nvap;\":\"≍⃒\",\"&nvdash;\":\"⊬\",\"&nvge;\":\"≥⃒\",\"&nvgt;\":\">⃒\",\"&nvinfin;\":\"⧞\",\"&nvlArr;\":\"⤂\",\"&nvle;\":\"≤⃒\",\"&nvlt;\":\"<⃒\",\"&nvltrie;\":\"⊴⃒\",\"&nvrArr;\":\"⤃\",\"&nvrtrie;\":\"⊵⃒\",\"&nvsim;\":\"∼⃒\",\"&nwArr;\":\"⇖\",\"&nwarhk;\":\"⤣\",\"&nwarr;\":\"↖\",\"&nwarrow;\":\"↖\",\"&nwnear;\":\"⤧\",\"&oS;\":\"Ⓢ\",\"&oacute\":\"ó\",\"&oacute;\":\"ó\",\"&oast;\":\"⊛\",\"&ocir;\":\"⊚\",\"&ocirc\":\"ô\",\"&ocirc;\":\"ô\",\"&ocy;\":\"о\",\"&odash;\":\"⊝\",\"&odblac;\":\"ő\",\"&odiv;\":\"⨸\",\"&odot;\":\"⊙\",\"&odsold;\":\"⦼\",\"&oelig;\":\"œ\",\"&ofcir;\":\"⦿\",\"&ofr;\":\"𝔬\",\"&ogon;\":\"˛\",\"&ograve\":\"ò\",\"&ograve;\":\"ò\",\"&ogt;\":\"⧁\",\"&ohbar;\":\"⦵\",\"&ohm;\":\"Ω\",\"&oint;\":\"∮\",\"&olarr;\":\"↺\",\"&olcir;\":\"⦾\",\"&olcross;\":\"⦻\",\"&oline;\":\"‾\",\"&olt;\":\"⧀\",\"&omacr;\":\"ō\",\"&omega;\":\"ω\",\"&omicron;\":\"ο\",\"&omid;\":\"⦶\",\"&ominus;\":\"⊖\",\"&oopf;\":\"𝕠\",\"&opar;\":\"⦷\",\"&operp;\":\"⦹\",\"&oplus;\":\"⊕\",\"&or;\":\"∨\",\"&orarr;\":\"↻\",\"&ord;\":\"⩝\",\"&order;\":\"ℴ\",\"&orderof;\":\"ℴ\",\"&ordf\":\"ª\",\"&ordf;\":\"ª\",\"&ordm\":\"º\",\"&ordm;\":\"º\",\"&origof;\":\"⊶\",\"&oror;\":\"⩖\",\"&orslope;\":\"⩗\",\"&orv;\":\"⩛\",\"&oscr;\":\"ℴ\",\"&oslash\":\"ø\",\"&oslash;\":\"ø\",\"&osol;\":\"⊘\",\"&otilde\":\"õ\",\"&otilde;\":\"õ\",\"&otimes;\":\"⊗\",\"&otimesas;\":\"⨶\",\"&ouml\":\"ö\",\"&ouml;\":\"ö\",\"&ovbar;\":\"⌽\",\"&par;\":\"∥\",\"&para\":\"¶\",\"&para;\":\"¶\",\"&parallel;\":\"∥\",\"&parsim;\":\"⫳\",\"&parsl;\":\"⫽\",\"&part;\":\"∂\",\"&pcy;\":\"п\",\"&percnt;\":\"%\",\"&period;\":\".\",\"&permil;\":\"‰\",\"&perp;\":\"⊥\",\"&pertenk;\":\"‱\",\"&pfr;\":\"𝔭\",\"&phi;\":\"φ\",\"&phiv;\":\"ϕ\",\"&phmmat;\":\"ℳ\",\"&phone;\":\"☎\",\"&pi;\":\"π\",\"&pitchfork;\":\"⋔\",\"&piv;\":\"ϖ\",\"&planck;\":\"ℏ\",\"&planckh;\":\"ℎ\",\"&plankv;\":\"ℏ\",\"&plus;\":\"+\",\"&plusacir;\":\"⨣\",\"&plusb;\":\"⊞\",\"&pluscir;\":\"⨢\",\"&plusdo;\":\"∔\",\"&plusdu;\":\"⨥\",\"&pluse;\":\"⩲\",\"&plusmn\":\"±\",\"&plusmn;\":\"±\",\"&plussim;\":\"⨦\",\"&plustwo;\":\"⨧\",\"&pm;\":\"±\",\"&pointint;\":\"⨕\",\"&popf;\":\"𝕡\",\"&pound\":\"£\",\"&pound;\":\"£\",\"&pr;\":\"≺\",\"&prE;\":\"⪳\",\"&prap;\":\"⪷\",\"&prcue;\":\"≼\",\"&pre;\":\"⪯\",\"&prec;\":\"≺\",\"&precapprox;\":\"⪷\",\"&preccurlyeq;\":\"≼\",\"&preceq;\":\"⪯\",\"&precnapprox;\":\"⪹\",\"&precneqq;\":\"⪵\",\"&precnsim;\":\"⋨\",\"&precsim;\":\"≾\",\"&prime;\":\"′\",\"&primes;\":\"ℙ\",\"&prnE;\":\"⪵\",\"&prnap;\":\"⪹\",\"&prnsim;\":\"⋨\",\"&prod;\":\"∏\",\"&profalar;\":\"⌮\",\"&profline;\":\"⌒\",\"&profsurf;\":\"⌓\",\"&prop;\":\"∝\",\"&propto;\":\"∝\",\"&prsim;\":\"≾\",\"&prurel;\":\"⊰\",\"&pscr;\":\"𝓅\",\"&psi;\":\"ψ\",\"&puncsp;\":\" \",\"&qfr;\":\"𝔮\",\"&qint;\":\"⨌\",\"&qopf;\":\"𝕢\",\"&qprime;\":\"⁗\",\"&qscr;\":\"𝓆\",\"&quaternions;\":\"ℍ\",\"&quatint;\":\"⨖\",\"&quest;\":\"?\",\"&questeq;\":\"≟\",\"&quot\":'\"',\"&quot;\":'\"',\"&rAarr;\":\"⇛\",\"&rArr;\":\"⇒\",\"&rAtail;\":\"⤜\",\"&rBarr;\":\"⤏\",\"&rHar;\":\"⥤\",\"&race;\":\"∽̱\",\"&racute;\":\"ŕ\",\"&radic;\":\"√\",\"&raemptyv;\":\"⦳\",\"&rang;\":\"⟩\",\"&rangd;\":\"⦒\",\"&range;\":\"⦥\",\"&rangle;\":\"⟩\",\"&raquo\":\"»\",\"&raquo;\":\"»\",\"&rarr;\":\"→\",\"&rarrap;\":\"⥵\",\"&rarrb;\":\"⇥\",\"&rarrbfs;\":\"⤠\",\"&rarrc;\":\"⤳\",\"&rarrfs;\":\"⤞\",\"&rarrhk;\":\"↪\",\"&rarrlp;\":\"↬\",\"&rarrpl;\":\"⥅\",\"&rarrsim;\":\"⥴\",\"&rarrtl;\":\"↣\",\"&rarrw;\":\"↝\",\"&ratail;\":\"⤚\",\"&ratio;\":\"∶\",\"&rationals;\":\"ℚ\",\"&rbarr;\":\"⤍\",\"&rbbrk;\":\"❳\",\"&rbrace;\":\"}\",\"&rbrack;\":\"]\",\"&rbrke;\":\"⦌\",\"&rbrksld;\":\"⦎\",\"&rbrkslu;\":\"⦐\",\"&rcaron;\":\"ř\",\"&rcedil;\":\"ŗ\",\"&rceil;\":\"⌉\",\"&rcub;\":\"}\",\"&rcy;\":\"р\",\"&rdca;\":\"⤷\",\"&rdldhar;\":\"⥩\",\"&rdquo;\":\"”\",\"&rdquor;\":\"”\",\"&rdsh;\":\"↳\",\"&real;\":\"ℜ\",\"&realine;\":\"ℛ\",\"&realpart;\":\"ℜ\",\"&reals;\":\"ℝ\",\"&rect;\":\"▭\",\"&reg\":\"®\",\"&reg;\":\"®\",\"&rfisht;\":\"⥽\",\"&rfloor;\":\"⌋\",\"&rfr;\":\"𝔯\",\"&rhard;\":\"⇁\",\"&rharu;\":\"⇀\",\"&rharul;\":\"⥬\",\"&rho;\":\"ρ\",\"&rhov;\":\"ϱ\",\"&rightarrow;\":\"→\",\"&rightarrowtail;\":\"↣\",\"&rightharpoondown;\":\"⇁\",\"&rightharpoonup;\":\"⇀\",\"&rightleftarrows;\":\"⇄\",\"&rightleftharpoons;\":\"⇌\",\"&rightrightarrows;\":\"⇉\",\"&rightsquigarrow;\":\"↝\",\"&rightthreetimes;\":\"⋌\",\"&ring;\":\"˚\",\"&risingdotseq;\":\"≓\",\"&rlarr;\":\"⇄\",\"&rlhar;\":\"⇌\",\"&rlm;\":\"‏\",\"&rmoust;\":\"⎱\",\"&rmoustache;\":\"⎱\",\"&rnmid;\":\"⫮\",\"&roang;\":\"⟭\",\"&roarr;\":\"⇾\",\"&robrk;\":\"⟧\",\"&ropar;\":\"⦆\",\"&ropf;\":\"𝕣\",\"&roplus;\":\"⨮\",\"&rotimes;\":\"⨵\",\"&rpar;\":\")\",\"&rpargt;\":\"⦔\",\"&rppolint;\":\"⨒\",\"&rrarr;\":\"⇉\",\"&rsaquo;\":\"›\",\"&rscr;\":\"𝓇\",\"&rsh;\":\"↱\",\"&rsqb;\":\"]\",\"&rsquo;\":\"’\",\"&rsquor;\":\"’\",\"&rthree;\":\"⋌\",\"&rtimes;\":\"⋊\",\"&rtri;\":\"▹\",\"&rtrie;\":\"⊵\",\"&rtrif;\":\"▸\",\"&rtriltri;\":\"⧎\",\"&ruluhar;\":\"⥨\",\"&rx;\":\"℞\",\"&sacute;\":\"ś\",\"&sbquo;\":\"‚\",\"&sc;\":\"≻\",\"&scE;\":\"⪴\",\"&scap;\":\"⪸\",\"&scaron;\":\"š\",\"&sccue;\":\"≽\",\"&sce;\":\"⪰\",\"&scedil;\":\"ş\",\"&scirc;\":\"ŝ\",\"&scnE;\":\"⪶\",\"&scnap;\":\"⪺\",\"&scnsim;\":\"⋩\",\"&scpolint;\":\"⨓\",\"&scsim;\":\"≿\",\"&scy;\":\"с\",\"&sdot;\":\"⋅\",\"&sdotb;\":\"⊡\",\"&sdote;\":\"⩦\",\"&seArr;\":\"⇘\",\"&searhk;\":\"⤥\",\"&searr;\":\"↘\",\"&searrow;\":\"↘\",\"&sect\":\"§\",\"&sect;\":\"§\",\"&semi;\":\";\",\"&seswar;\":\"⤩\",\"&setminus;\":\"∖\",\"&setmn;\":\"∖\",\"&sext;\":\"✶\",\"&sfr;\":\"𝔰\",\"&sfrown;\":\"⌢\",\"&sharp;\":\"♯\",\"&shchcy;\":\"щ\",\"&shcy;\":\"ш\",\"&shortmid;\":\"∣\",\"&shortparallel;\":\"∥\",\"&shy\":\"­\",\"&shy;\":\"­\",\"&sigma;\":\"σ\",\"&sigmaf;\":\"ς\",\"&sigmav;\":\"ς\",\"&sim;\":\"∼\",\"&simdot;\":\"⩪\",\"&sime;\":\"≃\",\"&simeq;\":\"≃\",\"&simg;\":\"⪞\",\"&simgE;\":\"⪠\",\"&siml;\":\"⪝\",\"&simlE;\":\"⪟\",\"&simne;\":\"≆\",\"&simplus;\":\"⨤\",\"&simrarr;\":\"⥲\",\"&slarr;\":\"←\",\"&smallsetminus;\":\"∖\",\"&smashp;\":\"⨳\",\"&smeparsl;\":\"⧤\",\"&smid;\":\"∣\",\"&smile;\":\"⌣\",\"&smt;\":\"⪪\",\"&smte;\":\"⪬\",\"&smtes;\":\"⪬︀\",\"&softcy;\":\"ь\",\"&sol;\":\"/\",\"&solb;\":\"⧄\",\"&solbar;\":\"⌿\",\"&sopf;\":\"𝕤\",\"&spades;\":\"♠\",\"&spadesuit;\":\"♠\",\"&spar;\":\"∥\",\"&sqcap;\":\"⊓\",\"&sqcaps;\":\"⊓︀\",\"&sqcup;\":\"⊔\",\"&sqcups;\":\"⊔︀\",\"&sqsub;\":\"⊏\",\"&sqsube;\":\"⊑\",\"&sqsubset;\":\"⊏\",\"&sqsubseteq;\":\"⊑\",\"&sqsup;\":\"⊐\",\"&sqsupe;\":\"⊒\",\"&sqsupset;\":\"⊐\",\"&sqsupseteq;\":\"⊒\",\"&squ;\":\"□\",\"&square;\":\"□\",\"&squarf;\":\"▪\",\"&squf;\":\"▪\",\"&srarr;\":\"→\",\"&sscr;\":\"𝓈\",\"&ssetmn;\":\"∖\",\"&ssmile;\":\"⌣\",\"&sstarf;\":\"⋆\",\"&star;\":\"☆\",\"&starf;\":\"★\",\"&straightepsilon;\":\"ϵ\",\"&straightphi;\":\"ϕ\",\"&strns;\":\"¯\",\"&sub;\":\"⊂\",\"&subE;\":\"⫅\",\"&subdot;\":\"⪽\",\"&sube;\":\"⊆\",\"&subedot;\":\"⫃\",\"&submult;\":\"⫁\",\"&subnE;\":\"⫋\",\"&subne;\":\"⊊\",\"&subplus;\":\"⪿\",\"&subrarr;\":\"⥹\",\"&subset;\":\"⊂\",\"&subseteq;\":\"⊆\",\"&subseteqq;\":\"⫅\",\"&subsetneq;\":\"⊊\",\"&subsetneqq;\":\"⫋\",\"&subsim;\":\"⫇\",\"&subsub;\":\"⫕\",\"&subsup;\":\"⫓\",\"&succ;\":\"≻\",\"&succapprox;\":\"⪸\",\"&succcurlyeq;\":\"≽\",\"&succeq;\":\"⪰\",\"&succnapprox;\":\"⪺\",\"&succneqq;\":\"⪶\",\"&succnsim;\":\"⋩\",\"&succsim;\":\"≿\",\"&sum;\":\"∑\",\"&sung;\":\"♪\",\"&sup1\":\"¹\",\"&sup1;\":\"¹\",\"&sup2\":\"²\",\"&sup2;\":\"²\",\"&sup3\":\"³\",\"&sup3;\":\"³\",\"&sup;\":\"⊃\",\"&supE;\":\"⫆\",\"&supdot;\":\"⪾\",\"&supdsub;\":\"⫘\",\"&supe;\":\"⊇\",\"&supedot;\":\"⫄\",\"&suphsol;\":\"⟉\",\"&suphsub;\":\"⫗\",\"&suplarr;\":\"⥻\",\"&supmult;\":\"⫂\",\"&supnE;\":\"⫌\",\"&supne;\":\"⊋\",\"&supplus;\":\"⫀\",\"&supset;\":\"⊃\",\"&supseteq;\":\"⊇\",\"&supseteqq;\":\"⫆\",\"&supsetneq;\":\"⊋\",\"&supsetneqq;\":\"⫌\",\"&supsim;\":\"⫈\",\"&supsub;\":\"⫔\",\"&supsup;\":\"⫖\",\"&swArr;\":\"⇙\",\"&swarhk;\":\"⤦\",\"&swarr;\":\"↙\",\"&swarrow;\":\"↙\",\"&swnwar;\":\"⤪\",\"&szlig\":\"ß\",\"&szlig;\":\"ß\",\"&target;\":\"⌖\",\"&tau;\":\"τ\",\"&tbrk;\":\"⎴\",\"&tcaron;\":\"ť\",\"&tcedil;\":\"ţ\",\"&tcy;\":\"т\",\"&tdot;\":\"⃛\",\"&telrec;\":\"⌕\",\"&tfr;\":\"𝔱\",\"&there4;\":\"∴\",\"&therefore;\":\"∴\",\"&theta;\":\"θ\",\"&thetasym;\":\"ϑ\",\"&thetav;\":\"ϑ\",\"&thickapprox;\":\"≈\",\"&thicksim;\":\"∼\",\"&thinsp;\":\" \",\"&thkap;\":\"≈\",\"&thksim;\":\"∼\",\"&thorn\":\"þ\",\"&thorn;\":\"þ\",\"&tilde;\":\"˜\",\"&times\":\"×\",\"&times;\":\"×\",\"&timesb;\":\"⊠\",\"&timesbar;\":\"⨱\",\"&timesd;\":\"⨰\",\"&tint;\":\"∭\",\"&toea;\":\"⤨\",\"&top;\":\"⊤\",\"&topbot;\":\"⌶\",\"&topcir;\":\"⫱\",\"&topf;\":\"𝕥\",\"&topfork;\":\"⫚\",\"&tosa;\":\"⤩\",\"&tprime;\":\"‴\",\"&trade;\":\"™\",\"&triangle;\":\"▵\",\"&triangledown;\":\"▿\",\"&triangleleft;\":\"◃\",\"&trianglelefteq;\":\"⊴\",\"&triangleq;\":\"≜\",\"&triangleright;\":\"▹\",\"&trianglerighteq;\":\"⊵\",\"&tridot;\":\"◬\",\"&trie;\":\"≜\",\"&triminus;\":\"⨺\",\"&triplus;\":\"⨹\",\"&trisb;\":\"⧍\",\"&tritime;\":\"⨻\",\"&trpezium;\":\"⏢\",\"&tscr;\":\"𝓉\",\"&tscy;\":\"ц\",\"&tshcy;\":\"ћ\",\"&tstrok;\":\"ŧ\",\"&twixt;\":\"≬\",\"&twoheadleftarrow;\":\"↞\",\"&twoheadrightarrow;\":\"↠\",\"&uArr;\":\"⇑\",\"&uHar;\":\"⥣\",\"&uacute\":\"ú\",\"&uacute;\":\"ú\",\"&uarr;\":\"↑\",\"&ubrcy;\":\"ў\",\"&ubreve;\":\"ŭ\",\"&ucirc\":\"û\",\"&ucirc;\":\"û\",\"&ucy;\":\"у\",\"&udarr;\":\"⇅\",\"&udblac;\":\"ű\",\"&udhar;\":\"⥮\",\"&ufisht;\":\"⥾\",\"&ufr;\":\"𝔲\",\"&ugrave\":\"ù\",\"&ugrave;\":\"ù\",\"&uharl;\":\"↿\",\"&uharr;\":\"↾\",\"&uhblk;\":\"▀\",\"&ulcorn;\":\"⌜\",\"&ulcorner;\":\"⌜\",\"&ulcrop;\":\"⌏\",\"&ultri;\":\"◸\",\"&umacr;\":\"ū\",\"&uml\":\"¨\",\"&uml;\":\"¨\",\"&uogon;\":\"ų\",\"&uopf;\":\"𝕦\",\"&uparrow;\":\"↑\",\"&updownarrow;\":\"↕\",\"&upharpoonleft;\":\"↿\",\"&upharpoonright;\":\"↾\",\"&uplus;\":\"⊎\",\"&upsi;\":\"υ\",\"&upsih;\":\"ϒ\",\"&upsilon;\":\"υ\",\"&upuparrows;\":\"⇈\",\"&urcorn;\":\"⌝\",\"&urcorner;\":\"⌝\",\"&urcrop;\":\"⌎\",\"&uring;\":\"ů\",\"&urtri;\":\"◹\",\"&uscr;\":\"𝓊\",\"&utdot;\":\"⋰\",\"&utilde;\":\"ũ\",\"&utri;\":\"▵\",\"&utrif;\":\"▴\",\"&uuarr;\":\"⇈\",\"&uuml\":\"ü\",\"&uuml;\":\"ü\",\"&uwangle;\":\"⦧\",\"&vArr;\":\"⇕\",\"&vBar;\":\"⫨\",\"&vBarv;\":\"⫩\",\"&vDash;\":\"⊨\",\"&vangrt;\":\"⦜\",\"&varepsilon;\":\"ϵ\",\"&varkappa;\":\"ϰ\",\"&varnothing;\":\"∅\",\"&varphi;\":\"ϕ\",\"&varpi;\":\"ϖ\",\"&varpropto;\":\"∝\",\"&varr;\":\"↕\",\"&varrho;\":\"ϱ\",\"&varsigma;\":\"ς\",\"&varsubsetneq;\":\"⊊︀\",\"&varsubsetneqq;\":\"⫋︀\",\"&varsupsetneq;\":\"⊋︀\",\"&varsupsetneqq;\":\"⫌︀\",\"&vartheta;\":\"ϑ\",\"&vartriangleleft;\":\"⊲\",\"&vartriangleright;\":\"⊳\",\"&vcy;\":\"в\",\"&vdash;\":\"⊢\",\"&vee;\":\"∨\",\"&veebar;\":\"⊻\",\"&veeeq;\":\"≚\",\"&vellip;\":\"⋮\",\"&verbar;\":\"|\",\"&vert;\":\"|\",\"&vfr;\":\"𝔳\",\"&vltri;\":\"⊲\",\"&vnsub;\":\"⊂⃒\",\"&vnsup;\":\"⊃⃒\",\"&vopf;\":\"𝕧\",\"&vprop;\":\"∝\",\"&vrtri;\":\"⊳\",\"&vscr;\":\"𝓋\",\"&vsubnE;\":\"⫋︀\",\"&vsubne;\":\"⊊︀\",\"&vsupnE;\":\"⫌︀\",\"&vsupne;\":\"⊋︀\",\"&vzigzag;\":\"⦚\",\"&wcirc;\":\"ŵ\",\"&wedbar;\":\"⩟\",\"&wedge;\":\"∧\",\"&wedgeq;\":\"≙\",\"&weierp;\":\"℘\",\"&wfr;\":\"𝔴\",\"&wopf;\":\"𝕨\",\"&wp;\":\"℘\",\"&wr;\":\"≀\",\"&wreath;\":\"≀\",\"&wscr;\":\"𝓌\",\"&xcap;\":\"⋂\",\"&xcirc;\":\"◯\",\"&xcup;\":\"⋃\",\"&xdtri;\":\"▽\",\"&xfr;\":\"𝔵\",\"&xhArr;\":\"⟺\",\"&xharr;\":\"⟷\",\"&xi;\":\"ξ\",\"&xlArr;\":\"⟸\",\"&xlarr;\":\"⟵\",\"&xmap;\":\"⟼\",\"&xnis;\":\"⋻\",\"&xodot;\":\"⨀\",\"&xopf;\":\"𝕩\",\"&xoplus;\":\"⨁\",\"&xotime;\":\"⨂\",\"&xrArr;\":\"⟹\",\"&xrarr;\":\"⟶\",\"&xscr;\":\"𝓍\",\"&xsqcup;\":\"⨆\",\"&xuplus;\":\"⨄\",\"&xutri;\":\"△\",\"&xvee;\":\"⋁\",\"&xwedge;\":\"⋀\",\"&yacute\":\"ý\",\"&yacute;\":\"ý\",\"&yacy;\":\"я\",\"&ycirc;\":\"ŷ\",\"&ycy;\":\"ы\",\"&yen\":\"¥\",\"&yen;\":\"¥\",\"&yfr;\":\"𝔶\",\"&yicy;\":\"ї\",\"&yopf;\":\"𝕪\",\"&yscr;\":\"𝓎\",\"&yucy;\":\"ю\",\"&yuml\":\"ÿ\",\"&yuml;\":\"ÿ\",\"&zacute;\":\"ź\",\"&zcaron;\":\"ž\",\"&zcy;\":\"з\",\"&zdot;\":\"ż\",\"&zeetrf;\":\"ℨ\",\"&zeta;\":\"ζ\",\"&zfr;\":\"𝔷\",\"&zhcy;\":\"ж\",\"&zigrarr;\":\"⇝\",\"&zopf;\":\"𝕫\",\"&zscr;\":\"𝓏\",\"&zwj;\":\"‍\",\"&zwnj;\":\"‌\"},characters:{\"Æ\":\"&AElig;\",\"&\":\"&amp;\",\"Á\":\"&Aacute;\",\"Ă\":\"&Abreve;\",\"Â\":\"&Acirc;\",\"А\":\"&Acy;\",\"𝔄\":\"&Afr;\",\"À\":\"&Agrave;\",\"Α\":\"&Alpha;\",\"Ā\":\"&Amacr;\",\"⩓\":\"&And;\",\"Ą\":\"&Aogon;\",\"𝔸\":\"&Aopf;\",\"⁡\":\"&af;\",\"Å\":\"&angst;\",\"𝒜\":\"&Ascr;\",\"≔\":\"&coloneq;\",\"Ã\":\"&Atilde;\",\"Ä\":\"&Auml;\",\"∖\":\"&ssetmn;\",\"⫧\":\"&Barv;\",\"⌆\":\"&doublebarwedge;\",\"Б\":\"&Bcy;\",\"∵\":\"&because;\",\"ℬ\":\"&bernou;\",\"Β\":\"&Beta;\",\"𝔅\":\"&Bfr;\",\"𝔹\":\"&Bopf;\",\"˘\":\"&breve;\",\"≎\":\"&bump;\",\"Ч\":\"&CHcy;\",\"©\":\"&copy;\",\"Ć\":\"&Cacute;\",\"⋒\":\"&Cap;\",\"ⅅ\":\"&DD;\",\"ℭ\":\"&Cfr;\",\"Č\":\"&Ccaron;\",\"Ç\":\"&Ccedil;\",\"Ĉ\":\"&Ccirc;\",\"∰\":\"&Cconint;\",\"Ċ\":\"&Cdot;\",\"¸\":\"&cedil;\",\"·\":\"&middot;\",\"Χ\":\"&Chi;\",\"⊙\":\"&odot;\",\"⊖\":\"&ominus;\",\"⊕\":\"&oplus;\",\"⊗\":\"&otimes;\",\"∲\":\"&cwconint;\",\"”\":\"&rdquor;\",\"’\":\"&rsquor;\",\"∷\":\"&Proportion;\",\"⩴\":\"&Colone;\",\"≡\":\"&equiv;\",\"∯\":\"&DoubleContourIntegral;\",\"∮\":\"&oint;\",\"ℂ\":\"&complexes;\",\"∐\":\"&coprod;\",\"∳\":\"&awconint;\",\"⨯\":\"&Cross;\",\"𝒞\":\"&Cscr;\",\"⋓\":\"&Cup;\",\"≍\":\"&asympeq;\",\"⤑\":\"&DDotrahd;\",\"Ђ\":\"&DJcy;\",\"Ѕ\":\"&DScy;\",\"Џ\":\"&DZcy;\",\"‡\":\"&ddagger;\",\"↡\":\"&Darr;\",\"⫤\":\"&DoubleLeftTee;\",\"Ď\":\"&Dcaron;\",\"Д\":\"&Dcy;\",\"∇\":\"&nabla;\",\"Δ\":\"&Delta;\",\"𝔇\":\"&Dfr;\",\"´\":\"&acute;\",\"˙\":\"&dot;\",\"˝\":\"&dblac;\",\"`\":\"&grave;\",\"˜\":\"&tilde;\",\"⋄\":\"&diamond;\",\"ⅆ\":\"&dd;\",\"𝔻\":\"&Dopf;\",\"¨\":\"&uml;\",\"⃜\":\"&DotDot;\",\"≐\":\"&esdot;\",\"⇓\":\"&dArr;\",\"⇐\":\"&lArr;\",\"⇔\":\"&iff;\",\"⟸\":\"&xlArr;\",\"⟺\":\"&xhArr;\",\"⟹\":\"&xrArr;\",\"⇒\":\"&rArr;\",\"⊨\":\"&vDash;\",\"⇑\":\"&uArr;\",\"⇕\":\"&vArr;\",\"∥\":\"&spar;\",\"↓\":\"&downarrow;\",\"⤓\":\"&DownArrowBar;\",\"⇵\":\"&duarr;\",\"̑\":\"&DownBreve;\",\"⥐\":\"&DownLeftRightVector;\",\"⥞\":\"&DownLeftTeeVector;\",\"↽\":\"&lhard;\",\"⥖\":\"&DownLeftVectorBar;\",\"⥟\":\"&DownRightTeeVector;\",\"⇁\":\"&rightharpoondown;\",\"⥗\":\"&DownRightVectorBar;\",\"⊤\":\"&top;\",\"↧\":\"&mapstodown;\",\"𝒟\":\"&Dscr;\",\"Đ\":\"&Dstrok;\",\"Ŋ\":\"&ENG;\",\"Ð\":\"&ETH;\",\"É\":\"&Eacute;\",\"Ě\":\"&Ecaron;\",\"Ê\":\"&Ecirc;\",\"Э\":\"&Ecy;\",\"Ė\":\"&Edot;\",\"𝔈\":\"&Efr;\",\"È\":\"&Egrave;\",\"∈\":\"&isinv;\",\"Ē\":\"&Emacr;\",\"◻\":\"&EmptySmallSquare;\",\"▫\":\"&EmptyVerySmallSquare;\",\"Ę\":\"&Eogon;\",\"𝔼\":\"&Eopf;\",\"Ε\":\"&Epsilon;\",\"⩵\":\"&Equal;\",\"≂\":\"&esim;\",\"⇌\":\"&rlhar;\",\"ℰ\":\"&expectation;\",\"⩳\":\"&Esim;\",\"Η\":\"&Eta;\",\"Ë\":\"&Euml;\",\"∃\":\"&exist;\",\"ⅇ\":\"&exponentiale;\",\"Ф\":\"&Fcy;\",\"𝔉\":\"&Ffr;\",\"◼\":\"&FilledSmallSquare;\",\"▪\":\"&squf;\",\"𝔽\":\"&Fopf;\",\"∀\":\"&forall;\",\"ℱ\":\"&Fscr;\",\"Ѓ\":\"&GJcy;\",\">\":\"&gt;\",\"Γ\":\"&Gamma;\",\"Ϝ\":\"&Gammad;\",\"Ğ\":\"&Gbreve;\",\"Ģ\":\"&Gcedil;\",\"Ĝ\":\"&Gcirc;\",\"Г\":\"&Gcy;\",\"Ġ\":\"&Gdot;\",\"𝔊\":\"&Gfr;\",\"⋙\":\"&ggg;\",\"𝔾\":\"&Gopf;\",\"≥\":\"&geq;\",\"⋛\":\"&gtreqless;\",\"≧\":\"&geqq;\",\"⪢\":\"&GreaterGreater;\",\"≷\":\"&gtrless;\",\"⩾\":\"&ges;\",\"≳\":\"&gtrsim;\",\"𝒢\":\"&Gscr;\",\"≫\":\"&gg;\",\"Ъ\":\"&HARDcy;\",\"ˇ\":\"&caron;\",\"^\":\"&Hat;\",\"Ĥ\":\"&Hcirc;\",\"ℌ\":\"&Poincareplane;\",\"ℋ\":\"&hamilt;\",\"ℍ\":\"&quaternions;\",\"─\":\"&boxh;\",\"Ħ\":\"&Hstrok;\",\"≏\":\"&bumpeq;\",\"Е\":\"&IEcy;\",\"Ĳ\":\"&IJlig;\",\"Ё\":\"&IOcy;\",\"Í\":\"&Iacute;\",\"Î\":\"&Icirc;\",\"И\":\"&Icy;\",\"İ\":\"&Idot;\",\"ℑ\":\"&imagpart;\",\"Ì\":\"&Igrave;\",\"Ī\":\"&Imacr;\",\"ⅈ\":\"&ii;\",\"∬\":\"&Int;\",\"∫\":\"&int;\",\"⋂\":\"&xcap;\",\"⁣\":\"&ic;\",\"⁢\":\"&it;\",\"Į\":\"&Iogon;\",\"𝕀\":\"&Iopf;\",\"Ι\":\"&Iota;\",\"ℐ\":\"&imagline;\",\"Ĩ\":\"&Itilde;\",\"І\":\"&Iukcy;\",\"Ï\":\"&Iuml;\",\"Ĵ\":\"&Jcirc;\",\"Й\":\"&Jcy;\",\"𝔍\":\"&Jfr;\",\"𝕁\":\"&Jopf;\",\"𝒥\":\"&Jscr;\",\"Ј\":\"&Jsercy;\",\"Є\":\"&Jukcy;\",\"Х\":\"&KHcy;\",\"Ќ\":\"&KJcy;\",\"Κ\":\"&Kappa;\",\"Ķ\":\"&Kcedil;\",\"К\":\"&Kcy;\",\"𝔎\":\"&Kfr;\",\"𝕂\":\"&Kopf;\",\"𝒦\":\"&Kscr;\",\"Љ\":\"&LJcy;\",\"<\":\"&lt;\",\"Ĺ\":\"&Lacute;\",\"Λ\":\"&Lambda;\",\"⟪\":\"&Lang;\",\"ℒ\":\"&lagran;\",\"↞\":\"&twoheadleftarrow;\",\"Ľ\":\"&Lcaron;\",\"Ļ\":\"&Lcedil;\",\"Л\":\"&Lcy;\",\"⟨\":\"&langle;\",\"←\":\"&slarr;\",\"⇤\":\"&larrb;\",\"⇆\":\"&lrarr;\",\"⌈\":\"&lceil;\",\"⟦\":\"&lobrk;\",\"⥡\":\"&LeftDownTeeVector;\",\"⇃\":\"&downharpoonleft;\",\"⥙\":\"&LeftDownVectorBar;\",\"⌊\":\"&lfloor;\",\"↔\":\"&leftrightarrow;\",\"⥎\":\"&LeftRightVector;\",\"⊣\":\"&dashv;\",\"↤\":\"&mapstoleft;\",\"⥚\":\"&LeftTeeVector;\",\"⊲\":\"&vltri;\",\"⧏\":\"&LeftTriangleBar;\",\"⊴\":\"&trianglelefteq;\",\"⥑\":\"&LeftUpDownVector;\",\"⥠\":\"&LeftUpTeeVector;\",\"↿\":\"&upharpoonleft;\",\"⥘\":\"&LeftUpVectorBar;\",\"↼\":\"&lharu;\",\"⥒\":\"&LeftVectorBar;\",\"⋚\":\"&lesseqgtr;\",\"≦\":\"&leqq;\",\"≶\":\"&lg;\",\"⪡\":\"&LessLess;\",\"⩽\":\"&les;\",\"≲\":\"&lsim;\",\"𝔏\":\"&Lfr;\",\"⋘\":\"&Ll;\",\"⇚\":\"&lAarr;\",\"Ŀ\":\"&Lmidot;\",\"⟵\":\"&xlarr;\",\"⟷\":\"&xharr;\",\"⟶\":\"&xrarr;\",\"𝕃\":\"&Lopf;\",\"↙\":\"&swarrow;\",\"↘\":\"&searrow;\",\"↰\":\"&lsh;\",\"Ł\":\"&Lstrok;\",\"≪\":\"&ll;\",\"⤅\":\"&Map;\",\"М\":\"&Mcy;\",\" \":\"&MediumSpace;\",\"ℳ\":\"&phmmat;\",\"𝔐\":\"&Mfr;\",\"∓\":\"&mp;\",\"𝕄\":\"&Mopf;\",\"Μ\":\"&Mu;\",\"Њ\":\"&NJcy;\",\"Ń\":\"&Nacute;\",\"Ň\":\"&Ncaron;\",\"Ņ\":\"&Ncedil;\",\"Н\":\"&Ncy;\",\"​\":\"&ZeroWidthSpace;\",\"\\n\":\"&NewLine;\",\"𝔑\":\"&Nfr;\",\"⁠\":\"&NoBreak;\",\" \":\"&nbsp;\",\"ℕ\":\"&naturals;\",\"⫬\":\"&Not;\",\"≢\":\"&nequiv;\",\"≭\":\"&NotCupCap;\",\"∦\":\"&nspar;\",\"∉\":\"&notinva;\",\"≠\":\"&ne;\",\"≂̸\":\"&nesim;\",\"∄\":\"&nexists;\",\"≯\":\"&ngtr;\",\"≱\":\"&ngeq;\",\"≧̸\":\"&ngeqq;\",\"≫̸\":\"&nGtv;\",\"≹\":\"&ntgl;\",\"⩾̸\":\"&nges;\",\"≵\":\"&ngsim;\",\"≎̸\":\"&nbump;\",\"≏̸\":\"&nbumpe;\",\"⋪\":\"&ntriangleleft;\",\"⧏̸\":\"&NotLeftTriangleBar;\",\"⋬\":\"&ntrianglelefteq;\",\"≮\":\"&nlt;\",\"≰\":\"&nleq;\",\"≸\":\"&ntlg;\",\"≪̸\":\"&nLtv;\",\"⩽̸\":\"&nles;\",\"≴\":\"&nlsim;\",\"⪢̸\":\"&NotNestedGreaterGreater;\",\"⪡̸\":\"&NotNestedLessLess;\",\"⊀\":\"&nprec;\",\"⪯̸\":\"&npreceq;\",\"⋠\":\"&nprcue;\",\"∌\":\"&notniva;\",\"⋫\":\"&ntriangleright;\",\"⧐̸\":\"&NotRightTriangleBar;\",\"⋭\":\"&ntrianglerighteq;\",\"⊏̸\":\"&NotSquareSubset;\",\"⋢\":\"&nsqsube;\",\"⊐̸\":\"&NotSquareSuperset;\",\"⋣\":\"&nsqsupe;\",\"⊂⃒\":\"&vnsub;\",\"⊈\":\"&nsubseteq;\",\"⊁\":\"&nsucc;\",\"⪰̸\":\"&nsucceq;\",\"⋡\":\"&nsccue;\",\"≿̸\":\"&NotSucceedsTilde;\",\"⊃⃒\":\"&vnsup;\",\"⊉\":\"&nsupseteq;\",\"≁\":\"&nsim;\",\"≄\":\"&nsimeq;\",\"≇\":\"&ncong;\",\"≉\":\"&napprox;\",\"∤\":\"&nsmid;\",\"𝒩\":\"&Nscr;\",\"Ñ\":\"&Ntilde;\",\"Ν\":\"&Nu;\",\"Œ\":\"&OElig;\",\"Ó\":\"&Oacute;\",\"Ô\":\"&Ocirc;\",\"О\":\"&Ocy;\",\"Ő\":\"&Odblac;\",\"𝔒\":\"&Ofr;\",\"Ò\":\"&Ograve;\",\"Ō\":\"&Omacr;\",\"Ω\":\"&ohm;\",\"Ο\":\"&Omicron;\",\"𝕆\":\"&Oopf;\",\"“\":\"&ldquo;\",\"‘\":\"&lsquo;\",\"⩔\":\"&Or;\",\"𝒪\":\"&Oscr;\",\"Ø\":\"&Oslash;\",\"Õ\":\"&Otilde;\",\"⨷\":\"&Otimes;\",\"Ö\":\"&Ouml;\",\"‾\":\"&oline;\",\"⏞\":\"&OverBrace;\",\"⎴\":\"&tbrk;\",\"⏜\":\"&OverParenthesis;\",\"∂\":\"&part;\",\"П\":\"&Pcy;\",\"𝔓\":\"&Pfr;\",\"Φ\":\"&Phi;\",\"Π\":\"&Pi;\",\"±\":\"&pm;\",\"ℙ\":\"&primes;\",\"⪻\":\"&Pr;\",\"≺\":\"&prec;\",\"⪯\":\"&preceq;\",\"≼\":\"&preccurlyeq;\",\"≾\":\"&prsim;\",\"″\":\"&Prime;\",\"∏\":\"&prod;\",\"∝\":\"&vprop;\",\"𝒫\":\"&Pscr;\",\"Ψ\":\"&Psi;\",'\"':\"&quot;\",\"𝔔\":\"&Qfr;\",\"ℚ\":\"&rationals;\",\"𝒬\":\"&Qscr;\",\"⤐\":\"&drbkarow;\",\"®\":\"&reg;\",\"Ŕ\":\"&Racute;\",\"⟫\":\"&Rang;\",\"↠\":\"&twoheadrightarrow;\",\"⤖\":\"&Rarrtl;\",\"Ř\":\"&Rcaron;\",\"Ŗ\":\"&Rcedil;\",\"Р\":\"&Rcy;\",\"ℜ\":\"&realpart;\",\"∋\":\"&niv;\",\"⇋\":\"&lrhar;\",\"⥯\":\"&duhar;\",\"Ρ\":\"&Rho;\",\"⟩\":\"&rangle;\",\"→\":\"&srarr;\",\"⇥\":\"&rarrb;\",\"⇄\":\"&rlarr;\",\"⌉\":\"&rceil;\",\"⟧\":\"&robrk;\",\"⥝\":\"&RightDownTeeVector;\",\"⇂\":\"&downharpoonright;\",\"⥕\":\"&RightDownVectorBar;\",\"⌋\":\"&rfloor;\",\"⊢\":\"&vdash;\",\"↦\":\"&mapsto;\",\"⥛\":\"&RightTeeVector;\",\"⊳\":\"&vrtri;\",\"⧐\":\"&RightTriangleBar;\",\"⊵\":\"&trianglerighteq;\",\"⥏\":\"&RightUpDownVector;\",\"⥜\":\"&RightUpTeeVector;\",\"↾\":\"&upharpoonright;\",\"⥔\":\"&RightUpVectorBar;\",\"⇀\":\"&rightharpoonup;\",\"⥓\":\"&RightVectorBar;\",\"ℝ\":\"&reals;\",\"⥰\":\"&RoundImplies;\",\"⇛\":\"&rAarr;\",\"ℛ\":\"&realine;\",\"↱\":\"&rsh;\",\"⧴\":\"&RuleDelayed;\",\"Щ\":\"&SHCHcy;\",\"Ш\":\"&SHcy;\",\"Ь\":\"&SOFTcy;\",\"Ś\":\"&Sacute;\",\"⪼\":\"&Sc;\",\"Š\":\"&Scaron;\",\"Ş\":\"&Scedil;\",\"Ŝ\":\"&Scirc;\",\"С\":\"&Scy;\",\"𝔖\":\"&Sfr;\",\"↑\":\"&uparrow;\",\"Σ\":\"&Sigma;\",\"∘\":\"&compfn;\",\"𝕊\":\"&Sopf;\",\"√\":\"&radic;\",\"□\":\"&square;\",\"⊓\":\"&sqcap;\",\"⊏\":\"&sqsubset;\",\"⊑\":\"&sqsubseteq;\",\"⊐\":\"&sqsupset;\",\"⊒\":\"&sqsupseteq;\",\"⊔\":\"&sqcup;\",\"𝒮\":\"&Sscr;\",\"⋆\":\"&sstarf;\",\"⋐\":\"&Subset;\",\"⊆\":\"&subseteq;\",\"≻\":\"&succ;\",\"⪰\":\"&succeq;\",\"≽\":\"&succcurlyeq;\",\"≿\":\"&succsim;\",\"∑\":\"&sum;\",\"⋑\":\"&Supset;\",\"⊃\":\"&supset;\",\"⊇\":\"&supseteq;\",\"Þ\":\"&THORN;\",\"™\":\"&trade;\",\"Ћ\":\"&TSHcy;\",\"Ц\":\"&TScy;\",\"\\t\":\"&Tab;\",\"Τ\":\"&Tau;\",\"Ť\":\"&Tcaron;\",\"Ţ\":\"&Tcedil;\",\"Т\":\"&Tcy;\",\"𝔗\":\"&Tfr;\",\"∴\":\"&therefore;\",\"Θ\":\"&Theta;\",\"  \":\"&ThickSpace;\",\" \":\"&thinsp;\",\"∼\":\"&thksim;\",\"≃\":\"&simeq;\",\"≅\":\"&cong;\",\"≈\":\"&thkap;\",\"𝕋\":\"&Topf;\",\"⃛\":\"&tdot;\",\"𝒯\":\"&Tscr;\",\"Ŧ\":\"&Tstrok;\",\"Ú\":\"&Uacute;\",\"↟\":\"&Uarr;\",\"⥉\":\"&Uarrocir;\",\"Ў\":\"&Ubrcy;\",\"Ŭ\":\"&Ubreve;\",\"Û\":\"&Ucirc;\",\"У\":\"&Ucy;\",\"Ű\":\"&Udblac;\",\"𝔘\":\"&Ufr;\",\"Ù\":\"&Ugrave;\",\"Ū\":\"&Umacr;\",_:\"&lowbar;\",\"⏟\":\"&UnderBrace;\",\"⎵\":\"&bbrk;\",\"⏝\":\"&UnderParenthesis;\",\"⋃\":\"&xcup;\",\"⊎\":\"&uplus;\",\"Ų\":\"&Uogon;\",\"𝕌\":\"&Uopf;\",\"⤒\":\"&UpArrowBar;\",\"⇅\":\"&udarr;\",\"↕\":\"&varr;\",\"⥮\":\"&udhar;\",\"⊥\":\"&perp;\",\"↥\":\"&mapstoup;\",\"↖\":\"&nwarrow;\",\"↗\":\"&nearrow;\",\"ϒ\":\"&upsih;\",\"Υ\":\"&Upsilon;\",\"Ů\":\"&Uring;\",\"𝒰\":\"&Uscr;\",\"Ũ\":\"&Utilde;\",\"Ü\":\"&Uuml;\",\"⊫\":\"&VDash;\",\"⫫\":\"&Vbar;\",\"В\":\"&Vcy;\",\"⊩\":\"&Vdash;\",\"⫦\":\"&Vdashl;\",\"⋁\":\"&xvee;\",\"‖\":\"&Vert;\",\"∣\":\"&smid;\",\"|\":\"&vert;\",\"❘\":\"&VerticalSeparator;\",\"≀\":\"&wreath;\",\" \":\"&hairsp;\",\"𝔙\":\"&Vfr;\",\"𝕍\":\"&Vopf;\",\"𝒱\":\"&Vscr;\",\"⊪\":\"&Vvdash;\",\"Ŵ\":\"&Wcirc;\",\"⋀\":\"&xwedge;\",\"𝔚\":\"&Wfr;\",\"𝕎\":\"&Wopf;\",\"𝒲\":\"&Wscr;\",\"𝔛\":\"&Xfr;\",\"Ξ\":\"&Xi;\",\"𝕏\":\"&Xopf;\",\"𝒳\":\"&Xscr;\",\"Я\":\"&YAcy;\",\"Ї\":\"&YIcy;\",\"Ю\":\"&YUcy;\",\"Ý\":\"&Yacute;\",\"Ŷ\":\"&Ycirc;\",\"Ы\":\"&Ycy;\",\"𝔜\":\"&Yfr;\",\"𝕐\":\"&Yopf;\",\"𝒴\":\"&Yscr;\",\"Ÿ\":\"&Yuml;\",\"Ж\":\"&ZHcy;\",\"Ź\":\"&Zacute;\",\"Ž\":\"&Zcaron;\",\"З\":\"&Zcy;\",\"Ż\":\"&Zdot;\",\"Ζ\":\"&Zeta;\",\"ℨ\":\"&zeetrf;\",\"ℤ\":\"&integers;\",\"𝒵\":\"&Zscr;\",\"á\":\"&aacute;\",\"ă\":\"&abreve;\",\"∾\":\"&mstpos;\",\"∾̳\":\"&acE;\",\"∿\":\"&acd;\",\"â\":\"&acirc;\",\"а\":\"&acy;\",\"æ\":\"&aelig;\",\"𝔞\":\"&afr;\",\"à\":\"&agrave;\",\"ℵ\":\"&aleph;\",\"α\":\"&alpha;\",\"ā\":\"&amacr;\",\"⨿\":\"&amalg;\",\"∧\":\"&wedge;\",\"⩕\":\"&andand;\",\"⩜\":\"&andd;\",\"⩘\":\"&andslope;\",\"⩚\":\"&andv;\",\"∠\":\"&angle;\",\"⦤\":\"&ange;\",\"∡\":\"&measuredangle;\",\"⦨\":\"&angmsdaa;\",\"⦩\":\"&angmsdab;\",\"⦪\":\"&angmsdac;\",\"⦫\":\"&angmsdad;\",\"⦬\":\"&angmsdae;\",\"⦭\":\"&angmsdaf;\",\"⦮\":\"&angmsdag;\",\"⦯\":\"&angmsdah;\",\"∟\":\"&angrt;\",\"⊾\":\"&angrtvb;\",\"⦝\":\"&angrtvbd;\",\"∢\":\"&angsph;\",\"⍼\":\"&angzarr;\",\"ą\":\"&aogon;\",\"𝕒\":\"&aopf;\",\"⩰\":\"&apE;\",\"⩯\":\"&apacir;\",\"≊\":\"&approxeq;\",\"≋\":\"&apid;\",\"'\":\"&apos;\",\"å\":\"&aring;\",\"𝒶\":\"&ascr;\",\"*\":\"&midast;\",\"ã\":\"&atilde;\",\"ä\":\"&auml;\",\"⨑\":\"&awint;\",\"⫭\":\"&bNot;\",\"≌\":\"&bcong;\",\"϶\":\"&bepsi;\",\"‵\":\"&bprime;\",\"∽\":\"&bsim;\",\"⋍\":\"&bsime;\",\"⊽\":\"&barvee;\",\"⌅\":\"&barwedge;\",\"⎶\":\"&bbrktbrk;\",\"б\":\"&bcy;\",\"„\":\"&ldquor;\",\"⦰\":\"&bemptyv;\",\"β\":\"&beta;\",\"ℶ\":\"&beth;\",\"≬\":\"&twixt;\",\"𝔟\":\"&bfr;\",\"◯\":\"&xcirc;\",\"⨀\":\"&xodot;\",\"⨁\":\"&xoplus;\",\"⨂\":\"&xotime;\",\"⨆\":\"&xsqcup;\",\"★\":\"&starf;\",\"▽\":\"&xdtri;\",\"△\":\"&xutri;\",\"⨄\":\"&xuplus;\",\"⤍\":\"&rbarr;\",\"⧫\":\"&lozf;\",\"▴\":\"&utrif;\",\"▾\":\"&dtrif;\",\"◂\":\"&ltrif;\",\"▸\":\"&rtrif;\",\"␣\":\"&blank;\",\"▒\":\"&blk12;\",\"░\":\"&blk14;\",\"▓\":\"&blk34;\",\"█\":\"&block;\",\"=⃥\":\"&bne;\",\"≡⃥\":\"&bnequiv;\",\"⌐\":\"&bnot;\",\"𝕓\":\"&bopf;\",\"⋈\":\"&bowtie;\",\"╗\":\"&boxDL;\",\"╔\":\"&boxDR;\",\"╖\":\"&boxDl;\",\"╓\":\"&boxDr;\",\"═\":\"&boxH;\",\"╦\":\"&boxHD;\",\"╩\":\"&boxHU;\",\"╤\":\"&boxHd;\",\"╧\":\"&boxHu;\",\"╝\":\"&boxUL;\",\"╚\":\"&boxUR;\",\"╜\":\"&boxUl;\",\"╙\":\"&boxUr;\",\"║\":\"&boxV;\",\"╬\":\"&boxVH;\",\"╣\":\"&boxVL;\",\"╠\":\"&boxVR;\",\"╫\":\"&boxVh;\",\"╢\":\"&boxVl;\",\"╟\":\"&boxVr;\",\"⧉\":\"&boxbox;\",\"╕\":\"&boxdL;\",\"╒\":\"&boxdR;\",\"┐\":\"&boxdl;\",\"┌\":\"&boxdr;\",\"╥\":\"&boxhD;\",\"╨\":\"&boxhU;\",\"┬\":\"&boxhd;\",\"┴\":\"&boxhu;\",\"⊟\":\"&minusb;\",\"⊞\":\"&plusb;\",\"⊠\":\"&timesb;\",\"╛\":\"&boxuL;\",\"╘\":\"&boxuR;\",\"┘\":\"&boxul;\",\"└\":\"&boxur;\",\"│\":\"&boxv;\",\"╪\":\"&boxvH;\",\"╡\":\"&boxvL;\",\"╞\":\"&boxvR;\",\"┼\":\"&boxvh;\",\"┤\":\"&boxvl;\",\"├\":\"&boxvr;\",\"¦\":\"&brvbar;\",\"𝒷\":\"&bscr;\",\"⁏\":\"&bsemi;\",\"\\\\\":\"&bsol;\",\"⧅\":\"&bsolb;\",\"⟈\":\"&bsolhsub;\",\"•\":\"&bullet;\",\"⪮\":\"&bumpE;\",\"ć\":\"&cacute;\",\"∩\":\"&cap;\",\"⩄\":\"&capand;\",\"⩉\":\"&capbrcup;\",\"⩋\":\"&capcap;\",\"⩇\":\"&capcup;\",\"⩀\":\"&capdot;\",\"∩︀\":\"&caps;\",\"⁁\":\"&caret;\",\"⩍\":\"&ccaps;\",\"č\":\"&ccaron;\",\"ç\":\"&ccedil;\",\"ĉ\":\"&ccirc;\",\"⩌\":\"&ccups;\",\"⩐\":\"&ccupssm;\",\"ċ\":\"&cdot;\",\"⦲\":\"&cemptyv;\",\"¢\":\"&cent;\",\"𝔠\":\"&cfr;\",\"ч\":\"&chcy;\",\"✓\":\"&checkmark;\",\"χ\":\"&chi;\",\"○\":\"&cir;\",\"⧃\":\"&cirE;\",\"ˆ\":\"&circ;\",\"≗\":\"&cire;\",\"↺\":\"&olarr;\",\"↻\":\"&orarr;\",\"Ⓢ\":\"&oS;\",\"⊛\":\"&oast;\",\"⊚\":\"&ocir;\",\"⊝\":\"&odash;\",\"⨐\":\"&cirfnint;\",\"⫯\":\"&cirmid;\",\"⧂\":\"&cirscir;\",\"♣\":\"&clubsuit;\",\":\":\"&colon;\",\",\":\"&comma;\",\"@\":\"&commat;\",\"∁\":\"&complement;\",\"⩭\":\"&congdot;\",\"𝕔\":\"&copf;\",\"℗\":\"&copysr;\",\"↵\":\"&crarr;\",\"✗\":\"&cross;\",\"𝒸\":\"&cscr;\",\"⫏\":\"&csub;\",\"⫑\":\"&csube;\",\"⫐\":\"&csup;\",\"⫒\":\"&csupe;\",\"⋯\":\"&ctdot;\",\"⤸\":\"&cudarrl;\",\"⤵\":\"&cudarrr;\",\"⋞\":\"&curlyeqprec;\",\"⋟\":\"&curlyeqsucc;\",\"↶\":\"&curvearrowleft;\",\"⤽\":\"&cularrp;\",\"∪\":\"&cup;\",\"⩈\":\"&cupbrcap;\",\"⩆\":\"&cupcap;\",\"⩊\":\"&cupcup;\",\"⊍\":\"&cupdot;\",\"⩅\":\"&cupor;\",\"∪︀\":\"&cups;\",\"↷\":\"&curvearrowright;\",\"⤼\":\"&curarrm;\",\"⋎\":\"&cuvee;\",\"⋏\":\"&cuwed;\",\"¤\":\"&curren;\",\"∱\":\"&cwint;\",\"⌭\":\"&cylcty;\",\"⥥\":\"&dHar;\",\"†\":\"&dagger;\",\"ℸ\":\"&daleth;\",\"‐\":\"&hyphen;\",\"⤏\":\"&rBarr;\",\"ď\":\"&dcaron;\",\"д\":\"&dcy;\",\"⇊\":\"&downdownarrows;\",\"⩷\":\"&eDDot;\",\"°\":\"&deg;\",\"δ\":\"&delta;\",\"⦱\":\"&demptyv;\",\"⥿\":\"&dfisht;\",\"𝔡\":\"&dfr;\",\"♦\":\"&diams;\",\"ϝ\":\"&gammad;\",\"⋲\":\"&disin;\",\"÷\":\"&divide;\",\"⋇\":\"&divonx;\",\"ђ\":\"&djcy;\",\"⌞\":\"&llcorner;\",\"⌍\":\"&dlcrop;\",$:\"&dollar;\",\"𝕕\":\"&dopf;\",\"≑\":\"&eDot;\",\"∸\":\"&minusd;\",\"∔\":\"&plusdo;\",\"⊡\":\"&sdotb;\",\"⌟\":\"&lrcorner;\",\"⌌\":\"&drcrop;\",\"𝒹\":\"&dscr;\",\"ѕ\":\"&dscy;\",\"⧶\":\"&dsol;\",\"đ\":\"&dstrok;\",\"⋱\":\"&dtdot;\",\"▿\":\"&triangledown;\",\"⦦\":\"&dwangle;\",\"џ\":\"&dzcy;\",\"⟿\":\"&dzigrarr;\",\"é\":\"&eacute;\",\"⩮\":\"&easter;\",\"ě\":\"&ecaron;\",\"≖\":\"&eqcirc;\",\"ê\":\"&ecirc;\",\"≕\":\"&eqcolon;\",\"э\":\"&ecy;\",\"ė\":\"&edot;\",\"≒\":\"&fallingdotseq;\",\"𝔢\":\"&efr;\",\"⪚\":\"&eg;\",\"è\":\"&egrave;\",\"⪖\":\"&eqslantgtr;\",\"⪘\":\"&egsdot;\",\"⪙\":\"&el;\",\"⏧\":\"&elinters;\",\"ℓ\":\"&ell;\",\"⪕\":\"&eqslantless;\",\"⪗\":\"&elsdot;\",\"ē\":\"&emacr;\",\"∅\":\"&varnothing;\",\" \":\"&emsp13;\",\" \":\"&emsp14;\",\" \":\"&emsp;\",\"ŋ\":\"&eng;\",\" \":\"&ensp;\",\"ę\":\"&eogon;\",\"𝕖\":\"&eopf;\",\"⋕\":\"&epar;\",\"⧣\":\"&eparsl;\",\"⩱\":\"&eplus;\",\"ε\":\"&epsilon;\",\"ϵ\":\"&varepsilon;\",\"=\":\"&equals;\",\"≟\":\"&questeq;\",\"⩸\":\"&equivDD;\",\"⧥\":\"&eqvparsl;\",\"≓\":\"&risingdotseq;\",\"⥱\":\"&erarr;\",\"ℯ\":\"&escr;\",\"η\":\"&eta;\",\"ð\":\"&eth;\",\"ë\":\"&euml;\",\"€\":\"&euro;\",\"!\":\"&excl;\",\"ф\":\"&fcy;\",\"♀\":\"&female;\",\"ﬃ\":\"&ffilig;\",\"ﬀ\":\"&fflig;\",\"ﬄ\":\"&ffllig;\",\"𝔣\":\"&ffr;\",\"ﬁ\":\"&filig;\",fj:\"&fjlig;\",\"♭\":\"&flat;\",\"ﬂ\":\"&fllig;\",\"▱\":\"&fltns;\",\"ƒ\":\"&fnof;\",\"𝕗\":\"&fopf;\",\"⋔\":\"&pitchfork;\",\"⫙\":\"&forkv;\",\"⨍\":\"&fpartint;\",\"½\":\"&half;\",\"⅓\":\"&frac13;\",\"¼\":\"&frac14;\",\"⅕\":\"&frac15;\",\"⅙\":\"&frac16;\",\"⅛\":\"&frac18;\",\"⅔\":\"&frac23;\",\"⅖\":\"&frac25;\",\"¾\":\"&frac34;\",\"⅗\":\"&frac35;\",\"⅜\":\"&frac38;\",\"⅘\":\"&frac45;\",\"⅚\":\"&frac56;\",\"⅝\":\"&frac58;\",\"⅞\":\"&frac78;\",\"⁄\":\"&frasl;\",\"⌢\":\"&sfrown;\",\"𝒻\":\"&fscr;\",\"⪌\":\"&gtreqqless;\",\"ǵ\":\"&gacute;\",\"γ\":\"&gamma;\",\"⪆\":\"&gtrapprox;\",\"ğ\":\"&gbreve;\",\"ĝ\":\"&gcirc;\",\"г\":\"&gcy;\",\"ġ\":\"&gdot;\",\"⪩\":\"&gescc;\",\"⪀\":\"&gesdot;\",\"⪂\":\"&gesdoto;\",\"⪄\":\"&gesdotol;\",\"⋛︀\":\"&gesl;\",\"⪔\":\"&gesles;\",\"𝔤\":\"&gfr;\",\"ℷ\":\"&gimel;\",\"ѓ\":\"&gjcy;\",\"⪒\":\"&glE;\",\"⪥\":\"&gla;\",\"⪤\":\"&glj;\",\"≩\":\"&gneqq;\",\"⪊\":\"&gnapprox;\",\"⪈\":\"&gneq;\",\"⋧\":\"&gnsim;\",\"𝕘\":\"&gopf;\",\"ℊ\":\"&gscr;\",\"⪎\":\"&gsime;\",\"⪐\":\"&gsiml;\",\"⪧\":\"&gtcc;\",\"⩺\":\"&gtcir;\",\"⋗\":\"&gtrdot;\",\"⦕\":\"&gtlPar;\",\"⩼\":\"&gtquest;\",\"⥸\":\"&gtrarr;\",\"≩︀\":\"&gvnE;\",\"ъ\":\"&hardcy;\",\"⥈\":\"&harrcir;\",\"↭\":\"&leftrightsquigarrow;\",\"ℏ\":\"&plankv;\",\"ĥ\":\"&hcirc;\",\"♥\":\"&heartsuit;\",\"…\":\"&mldr;\",\"⊹\":\"&hercon;\",\"𝔥\":\"&hfr;\",\"⤥\":\"&searhk;\",\"⤦\":\"&swarhk;\",\"⇿\":\"&hoarr;\",\"∻\":\"&homtht;\",\"↩\":\"&larrhk;\",\"↪\":\"&rarrhk;\",\"𝕙\":\"&hopf;\",\"―\":\"&horbar;\",\"𝒽\":\"&hscr;\",\"ħ\":\"&hstrok;\",\"⁃\":\"&hybull;\",\"í\":\"&iacute;\",\"î\":\"&icirc;\",\"и\":\"&icy;\",\"е\":\"&iecy;\",\"¡\":\"&iexcl;\",\"𝔦\":\"&ifr;\",\"ì\":\"&igrave;\",\"⨌\":\"&qint;\",\"∭\":\"&tint;\",\"⧜\":\"&iinfin;\",\"℩\":\"&iiota;\",\"ĳ\":\"&ijlig;\",\"ī\":\"&imacr;\",\"ı\":\"&inodot;\",\"⊷\":\"&imof;\",\"Ƶ\":\"&imped;\",\"℅\":\"&incare;\",\"∞\":\"&infin;\",\"⧝\":\"&infintie;\",\"⊺\":\"&intercal;\",\"⨗\":\"&intlarhk;\",\"⨼\":\"&iprod;\",\"ё\":\"&iocy;\",\"į\":\"&iogon;\",\"𝕚\":\"&iopf;\",\"ι\":\"&iota;\",\"¿\":\"&iquest;\",\"𝒾\":\"&iscr;\",\"⋹\":\"&isinE;\",\"⋵\":\"&isindot;\",\"⋴\":\"&isins;\",\"⋳\":\"&isinsv;\",\"ĩ\":\"&itilde;\",\"і\":\"&iukcy;\",\"ï\":\"&iuml;\",\"ĵ\":\"&jcirc;\",\"й\":\"&jcy;\",\"𝔧\":\"&jfr;\",\"ȷ\":\"&jmath;\",\"𝕛\":\"&jopf;\",\"𝒿\":\"&jscr;\",\"ј\":\"&jsercy;\",\"є\":\"&jukcy;\",\"κ\":\"&kappa;\",\"ϰ\":\"&varkappa;\",\"ķ\":\"&kcedil;\",\"к\":\"&kcy;\",\"𝔨\":\"&kfr;\",\"ĸ\":\"&kgreen;\",\"х\":\"&khcy;\",\"ќ\":\"&kjcy;\",\"𝕜\":\"&kopf;\",\"𝓀\":\"&kscr;\",\"⤛\":\"&lAtail;\",\"⤎\":\"&lBarr;\",\"⪋\":\"&lesseqqgtr;\",\"⥢\":\"&lHar;\",\"ĺ\":\"&lacute;\",\"⦴\":\"&laemptyv;\",\"λ\":\"&lambda;\",\"⦑\":\"&langd;\",\"⪅\":\"&lessapprox;\",\"«\":\"&laquo;\",\"⤟\":\"&larrbfs;\",\"⤝\":\"&larrfs;\",\"↫\":\"&looparrowleft;\",\"⤹\":\"&larrpl;\",\"⥳\":\"&larrsim;\",\"↢\":\"&leftarrowtail;\",\"⪫\":\"&lat;\",\"⤙\":\"&latail;\",\"⪭\":\"&late;\",\"⪭︀\":\"&lates;\",\"⤌\":\"&lbarr;\",\"❲\":\"&lbbrk;\",\"{\":\"&lcub;\",\"[\":\"&lsqb;\",\"⦋\":\"&lbrke;\",\"⦏\":\"&lbrksld;\",\"⦍\":\"&lbrkslu;\",\"ľ\":\"&lcaron;\",\"ļ\":\"&lcedil;\",\"л\":\"&lcy;\",\"⤶\":\"&ldca;\",\"⥧\":\"&ldrdhar;\",\"⥋\":\"&ldrushar;\",\"↲\":\"&ldsh;\",\"≤\":\"&leq;\",\"⇇\":\"&llarr;\",\"⋋\":\"&lthree;\",\"⪨\":\"&lescc;\",\"⩿\":\"&lesdot;\",\"⪁\":\"&lesdoto;\",\"⪃\":\"&lesdotor;\",\"⋚︀\":\"&lesg;\",\"⪓\":\"&lesges;\",\"⋖\":\"&ltdot;\",\"⥼\":\"&lfisht;\",\"𝔩\":\"&lfr;\",\"⪑\":\"&lgE;\",\"⥪\":\"&lharul;\",\"▄\":\"&lhblk;\",\"љ\":\"&ljcy;\",\"⥫\":\"&llhard;\",\"◺\":\"&lltri;\",\"ŀ\":\"&lmidot;\",\"⎰\":\"&lmoustache;\",\"≨\":\"&lneqq;\",\"⪉\":\"&lnapprox;\",\"⪇\":\"&lneq;\",\"⋦\":\"&lnsim;\",\"⟬\":\"&loang;\",\"⇽\":\"&loarr;\",\"⟼\":\"&xmap;\",\"↬\":\"&rarrlp;\",\"⦅\":\"&lopar;\",\"𝕝\":\"&lopf;\",\"⨭\":\"&loplus;\",\"⨴\":\"&lotimes;\",\"∗\":\"&lowast;\",\"◊\":\"&lozenge;\",\"(\":\"&lpar;\",\"⦓\":\"&lparlt;\",\"⥭\":\"&lrhard;\",\"‎\":\"&lrm;\",\"⊿\":\"&lrtri;\",\"‹\":\"&lsaquo;\",\"𝓁\":\"&lscr;\",\"⪍\":\"&lsime;\",\"⪏\":\"&lsimg;\",\"‚\":\"&sbquo;\",\"ł\":\"&lstrok;\",\"⪦\":\"&ltcc;\",\"⩹\":\"&ltcir;\",\"⋉\":\"&ltimes;\",\"⥶\":\"&ltlarr;\",\"⩻\":\"&ltquest;\",\"⦖\":\"&ltrPar;\",\"◃\":\"&triangleleft;\",\"⥊\":\"&lurdshar;\",\"⥦\":\"&luruhar;\",\"≨︀\":\"&lvnE;\",\"∺\":\"&mDDot;\",\"¯\":\"&strns;\",\"♂\":\"&male;\",\"✠\":\"&maltese;\",\"▮\":\"&marker;\",\"⨩\":\"&mcomma;\",\"м\":\"&mcy;\",\"—\":\"&mdash;\",\"𝔪\":\"&mfr;\",\"℧\":\"&mho;\",\"µ\":\"&micro;\",\"⫰\":\"&midcir;\",\"−\":\"&minus;\",\"⨪\":\"&minusdu;\",\"⫛\":\"&mlcp;\",\"⊧\":\"&models;\",\"𝕞\":\"&mopf;\",\"𝓂\":\"&mscr;\",\"μ\":\"&mu;\",\"⊸\":\"&mumap;\",\"⋙̸\":\"&nGg;\",\"≫⃒\":\"&nGt;\",\"⇍\":\"&nlArr;\",\"⇎\":\"&nhArr;\",\"⋘̸\":\"&nLl;\",\"≪⃒\":\"&nLt;\",\"⇏\":\"&nrArr;\",\"⊯\":\"&nVDash;\",\"⊮\":\"&nVdash;\",\"ń\":\"&nacute;\",\"∠⃒\":\"&nang;\",\"⩰̸\":\"&napE;\",\"≋̸\":\"&napid;\",\"ŉ\":\"&napos;\",\"♮\":\"&natural;\",\"⩃\":\"&ncap;\",\"ň\":\"&ncaron;\",\"ņ\":\"&ncedil;\",\"⩭̸\":\"&ncongdot;\",\"⩂\":\"&ncup;\",\"н\":\"&ncy;\",\"–\":\"&ndash;\",\"⇗\":\"&neArr;\",\"⤤\":\"&nearhk;\",\"≐̸\":\"&nedot;\",\"⤨\":\"&toea;\",\"𝔫\":\"&nfr;\",\"↮\":\"&nleftrightarrow;\",\"⫲\":\"&nhpar;\",\"⋼\":\"&nis;\",\"⋺\":\"&nisd;\",\"њ\":\"&njcy;\",\"≦̸\":\"&nleqq;\",\"↚\":\"&nleftarrow;\",\"‥\":\"&nldr;\",\"𝕟\":\"&nopf;\",\"¬\":\"&not;\",\"⋹̸\":\"&notinE;\",\"⋵̸\":\"&notindot;\",\"⋷\":\"&notinvb;\",\"⋶\":\"&notinvc;\",\"⋾\":\"&notnivb;\",\"⋽\":\"&notnivc;\",\"⫽⃥\":\"&nparsl;\",\"∂̸\":\"&npart;\",\"⨔\":\"&npolint;\",\"↛\":\"&nrightarrow;\",\"⤳̸\":\"&nrarrc;\",\"↝̸\":\"&nrarrw;\",\"𝓃\":\"&nscr;\",\"⊄\":\"&nsub;\",\"⫅̸\":\"&nsubseteqq;\",\"⊅\":\"&nsup;\",\"⫆̸\":\"&nsupseteqq;\",\"ñ\":\"&ntilde;\",\"ν\":\"&nu;\",\"#\":\"&num;\",\"№\":\"&numero;\",\" \":\"&numsp;\",\"⊭\":\"&nvDash;\",\"⤄\":\"&nvHarr;\",\"≍⃒\":\"&nvap;\",\"⊬\":\"&nvdash;\",\"≥⃒\":\"&nvge;\",\">⃒\":\"&nvgt;\",\"⧞\":\"&nvinfin;\",\"⤂\":\"&nvlArr;\",\"≤⃒\":\"&nvle;\",\"<⃒\":\"&nvlt;\",\"⊴⃒\":\"&nvltrie;\",\"⤃\":\"&nvrArr;\",\"⊵⃒\":\"&nvrtrie;\",\"∼⃒\":\"&nvsim;\",\"⇖\":\"&nwArr;\",\"⤣\":\"&nwarhk;\",\"⤧\":\"&nwnear;\",\"ó\":\"&oacute;\",\"ô\":\"&ocirc;\",\"о\":\"&ocy;\",\"ő\":\"&odblac;\",\"⨸\":\"&odiv;\",\"⦼\":\"&odsold;\",\"œ\":\"&oelig;\",\"⦿\":\"&ofcir;\",\"𝔬\":\"&ofr;\",\"˛\":\"&ogon;\",\"ò\":\"&ograve;\",\"⧁\":\"&ogt;\",\"⦵\":\"&ohbar;\",\"⦾\":\"&olcir;\",\"⦻\":\"&olcross;\",\"⧀\":\"&olt;\",\"ō\":\"&omacr;\",\"ω\":\"&omega;\",\"ο\":\"&omicron;\",\"⦶\":\"&omid;\",\"𝕠\":\"&oopf;\",\"⦷\":\"&opar;\",\"⦹\":\"&operp;\",\"∨\":\"&vee;\",\"⩝\":\"&ord;\",\"ℴ\":\"&oscr;\",\"ª\":\"&ordf;\",\"º\":\"&ordm;\",\"⊶\":\"&origof;\",\"⩖\":\"&oror;\",\"⩗\":\"&orslope;\",\"⩛\":\"&orv;\",\"ø\":\"&oslash;\",\"⊘\":\"&osol;\",\"õ\":\"&otilde;\",\"⨶\":\"&otimesas;\",\"ö\":\"&ouml;\",\"⌽\":\"&ovbar;\",\"¶\":\"&para;\",\"⫳\":\"&parsim;\",\"⫽\":\"&parsl;\",\"п\":\"&pcy;\",\"%\":\"&percnt;\",\".\":\"&period;\",\"‰\":\"&permil;\",\"‱\":\"&pertenk;\",\"𝔭\":\"&pfr;\",\"φ\":\"&phi;\",\"ϕ\":\"&varphi;\",\"☎\":\"&phone;\",\"π\":\"&pi;\",\"ϖ\":\"&varpi;\",\"ℎ\":\"&planckh;\",\"+\":\"&plus;\",\"⨣\":\"&plusacir;\",\"⨢\":\"&pluscir;\",\"⨥\":\"&plusdu;\",\"⩲\":\"&pluse;\",\"⨦\":\"&plussim;\",\"⨧\":\"&plustwo;\",\"⨕\":\"&pointint;\",\"𝕡\":\"&popf;\",\"£\":\"&pound;\",\"⪳\":\"&prE;\",\"⪷\":\"&precapprox;\",\"⪹\":\"&prnap;\",\"⪵\":\"&prnE;\",\"⋨\":\"&prnsim;\",\"′\":\"&prime;\",\"⌮\":\"&profalar;\",\"⌒\":\"&profline;\",\"⌓\":\"&profsurf;\",\"⊰\":\"&prurel;\",\"𝓅\":\"&pscr;\",\"ψ\":\"&psi;\",\" \":\"&puncsp;\",\"𝔮\":\"&qfr;\",\"𝕢\":\"&qopf;\",\"⁗\":\"&qprime;\",\"𝓆\":\"&qscr;\",\"⨖\":\"&quatint;\",\"?\":\"&quest;\",\"⤜\":\"&rAtail;\",\"⥤\":\"&rHar;\",\"∽̱\":\"&race;\",\"ŕ\":\"&racute;\",\"⦳\":\"&raemptyv;\",\"⦒\":\"&rangd;\",\"⦥\":\"&range;\",\"»\":\"&raquo;\",\"⥵\":\"&rarrap;\",\"⤠\":\"&rarrbfs;\",\"⤳\":\"&rarrc;\",\"⤞\":\"&rarrfs;\",\"⥅\":\"&rarrpl;\",\"⥴\":\"&rarrsim;\",\"↣\":\"&rightarrowtail;\",\"↝\":\"&rightsquigarrow;\",\"⤚\":\"&ratail;\",\"∶\":\"&ratio;\",\"❳\":\"&rbbrk;\",\"}\":\"&rcub;\",\"]\":\"&rsqb;\",\"⦌\":\"&rbrke;\",\"⦎\":\"&rbrksld;\",\"⦐\":\"&rbrkslu;\",\"ř\":\"&rcaron;\",\"ŗ\":\"&rcedil;\",\"р\":\"&rcy;\",\"⤷\":\"&rdca;\",\"⥩\":\"&rdldhar;\",\"↳\":\"&rdsh;\",\"▭\":\"&rect;\",\"⥽\":\"&rfisht;\",\"𝔯\":\"&rfr;\",\"⥬\":\"&rharul;\",\"ρ\":\"&rho;\",\"ϱ\":\"&varrho;\",\"⇉\":\"&rrarr;\",\"⋌\":\"&rthree;\",\"˚\":\"&ring;\",\"‏\":\"&rlm;\",\"⎱\":\"&rmoustache;\",\"⫮\":\"&rnmid;\",\"⟭\":\"&roang;\",\"⇾\":\"&roarr;\",\"⦆\":\"&ropar;\",\"𝕣\":\"&ropf;\",\"⨮\":\"&roplus;\",\"⨵\":\"&rotimes;\",\")\":\"&rpar;\",\"⦔\":\"&rpargt;\",\"⨒\":\"&rppolint;\",\"›\":\"&rsaquo;\",\"𝓇\":\"&rscr;\",\"⋊\":\"&rtimes;\",\"▹\":\"&triangleright;\",\"⧎\":\"&rtriltri;\",\"⥨\":\"&ruluhar;\",\"℞\":\"&rx;\",\"ś\":\"&sacute;\",\"⪴\":\"&scE;\",\"⪸\":\"&succapprox;\",\"š\":\"&scaron;\",\"ş\":\"&scedil;\",\"ŝ\":\"&scirc;\",\"⪶\":\"&succneqq;\",\"⪺\":\"&succnapprox;\",\"⋩\":\"&succnsim;\",\"⨓\":\"&scpolint;\",\"с\":\"&scy;\",\"⋅\":\"&sdot;\",\"⩦\":\"&sdote;\",\"⇘\":\"&seArr;\",\"§\":\"&sect;\",\";\":\"&semi;\",\"⤩\":\"&tosa;\",\"✶\":\"&sext;\",\"𝔰\":\"&sfr;\",\"♯\":\"&sharp;\",\"щ\":\"&shchcy;\",\"ш\":\"&shcy;\",\"­\":\"&shy;\",\"σ\":\"&sigma;\",\"ς\":\"&varsigma;\",\"⩪\":\"&simdot;\",\"⪞\":\"&simg;\",\"⪠\":\"&simgE;\",\"⪝\":\"&siml;\",\"⪟\":\"&simlE;\",\"≆\":\"&simne;\",\"⨤\":\"&simplus;\",\"⥲\":\"&simrarr;\",\"⨳\":\"&smashp;\",\"⧤\":\"&smeparsl;\",\"⌣\":\"&ssmile;\",\"⪪\":\"&smt;\",\"⪬\":\"&smte;\",\"⪬︀\":\"&smtes;\",\"ь\":\"&softcy;\",\"/\":\"&sol;\",\"⧄\":\"&solb;\",\"⌿\":\"&solbar;\",\"𝕤\":\"&sopf;\",\"♠\":\"&spadesuit;\",\"⊓︀\":\"&sqcaps;\",\"⊔︀\":\"&sqcups;\",\"𝓈\":\"&sscr;\",\"☆\":\"&star;\",\"⊂\":\"&subset;\",\"⫅\":\"&subseteqq;\",\"⪽\":\"&subdot;\",\"⫃\":\"&subedot;\",\"⫁\":\"&submult;\",\"⫋\":\"&subsetneqq;\",\"⊊\":\"&subsetneq;\",\"⪿\":\"&subplus;\",\"⥹\":\"&subrarr;\",\"⫇\":\"&subsim;\",\"⫕\":\"&subsub;\",\"⫓\":\"&subsup;\",\"♪\":\"&sung;\",\"¹\":\"&sup1;\",\"²\":\"&sup2;\",\"³\":\"&sup3;\",\"⫆\":\"&supseteqq;\",\"⪾\":\"&supdot;\",\"⫘\":\"&supdsub;\",\"⫄\":\"&supedot;\",\"⟉\":\"&suphsol;\",\"⫗\":\"&suphsub;\",\"⥻\":\"&suplarr;\",\"⫂\":\"&supmult;\",\"⫌\":\"&supsetneqq;\",\"⊋\":\"&supsetneq;\",\"⫀\":\"&supplus;\",\"⫈\":\"&supsim;\",\"⫔\":\"&supsub;\",\"⫖\":\"&supsup;\",\"⇙\":\"&swArr;\",\"⤪\":\"&swnwar;\",\"ß\":\"&szlig;\",\"⌖\":\"&target;\",\"τ\":\"&tau;\",\"ť\":\"&tcaron;\",\"ţ\":\"&tcedil;\",\"т\":\"&tcy;\",\"⌕\":\"&telrec;\",\"𝔱\":\"&tfr;\",\"θ\":\"&theta;\",\"ϑ\":\"&vartheta;\",\"þ\":\"&thorn;\",\"×\":\"&times;\",\"⨱\":\"&timesbar;\",\"⨰\":\"&timesd;\",\"⌶\":\"&topbot;\",\"⫱\":\"&topcir;\",\"𝕥\":\"&topf;\",\"⫚\":\"&topfork;\",\"‴\":\"&tprime;\",\"▵\":\"&utri;\",\"≜\":\"&trie;\",\"◬\":\"&tridot;\",\"⨺\":\"&triminus;\",\"⨹\":\"&triplus;\",\"⧍\":\"&trisb;\",\"⨻\":\"&tritime;\",\"⏢\":\"&trpezium;\",\"𝓉\":\"&tscr;\",\"ц\":\"&tscy;\",\"ћ\":\"&tshcy;\",\"ŧ\":\"&tstrok;\",\"⥣\":\"&uHar;\",\"ú\":\"&uacute;\",\"ў\":\"&ubrcy;\",\"ŭ\":\"&ubreve;\",\"û\":\"&ucirc;\",\"у\":\"&ucy;\",\"ű\":\"&udblac;\",\"⥾\":\"&ufisht;\",\"𝔲\":\"&ufr;\",\"ù\":\"&ugrave;\",\"▀\":\"&uhblk;\",\"⌜\":\"&ulcorner;\",\"⌏\":\"&ulcrop;\",\"◸\":\"&ultri;\",\"ū\":\"&umacr;\",\"ų\":\"&uogon;\",\"𝕦\":\"&uopf;\",\"υ\":\"&upsilon;\",\"⇈\":\"&uuarr;\",\"⌝\":\"&urcorner;\",\"⌎\":\"&urcrop;\",\"ů\":\"&uring;\",\"◹\":\"&urtri;\",\"𝓊\":\"&uscr;\",\"⋰\":\"&utdot;\",\"ũ\":\"&utilde;\",\"ü\":\"&uuml;\",\"⦧\":\"&uwangle;\",\"⫨\":\"&vBar;\",\"⫩\":\"&vBarv;\",\"⦜\":\"&vangrt;\",\"⊊︀\":\"&vsubne;\",\"⫋︀\":\"&vsubnE;\",\"⊋︀\":\"&vsupne;\",\"⫌︀\":\"&vsupnE;\",\"в\":\"&vcy;\",\"⊻\":\"&veebar;\",\"≚\":\"&veeeq;\",\"⋮\":\"&vellip;\",\"𝔳\":\"&vfr;\",\"𝕧\":\"&vopf;\",\"𝓋\":\"&vscr;\",\"⦚\":\"&vzigzag;\",\"ŵ\":\"&wcirc;\",\"⩟\":\"&wedbar;\",\"≙\":\"&wedgeq;\",\"℘\":\"&wp;\",\"𝔴\":\"&wfr;\",\"𝕨\":\"&wopf;\",\"𝓌\":\"&wscr;\",\"𝔵\":\"&xfr;\",\"ξ\":\"&xi;\",\"⋻\":\"&xnis;\",\"𝕩\":\"&xopf;\",\"𝓍\":\"&xscr;\",\"ý\":\"&yacute;\",\"я\":\"&yacy;\",\"ŷ\":\"&ycirc;\",\"ы\":\"&ycy;\",\"¥\":\"&yen;\",\"𝔶\":\"&yfr;\",\"ї\":\"&yicy;\",\"𝕪\":\"&yopf;\",\"𝓎\":\"&yscr;\",\"ю\":\"&yucy;\",\"ÿ\":\"&yuml;\",\"ź\":\"&zacute;\",\"ž\":\"&zcaron;\",\"з\":\"&zcy;\",\"ż\":\"&zdot;\",\"ζ\":\"&zeta;\",\"𝔷\":\"&zfr;\",\"ж\":\"&zhcy;\",\"⇝\":\"&zigrarr;\",\"𝕫\":\"&zopf;\",\"𝓏\":\"&zscr;\",\"‍\":\"&zwj;\",\"‌\":\"&zwnj;\"}}};\n\n//# sourceURL=webpack:///./node_modules/html-entities/lib/named-references.js?");

/***/ }),

/***/ "./node_modules/html-entities/lib/numeric-unicode-map.js":
/*!***************************************************************!*\
  !*** ./node_modules/html-entities/lib/numeric-unicode-map.js ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("Object.defineProperty(exports,\"__esModule\",{value:true});exports.numericUnicodeMap={0:65533,128:8364,130:8218,131:402,132:8222,133:8230,134:8224,135:8225,136:710,137:8240,138:352,139:8249,140:338,142:381,145:8216,146:8217,147:8220,148:8221,149:8226,150:8211,151:8212,152:732,153:8482,154:353,155:8250,156:339,158:382,159:376};\n\n//# sourceURL=webpack:///./node_modules/html-entities/lib/numeric-unicode-map.js?");

/***/ }),

/***/ "./node_modules/html-entities/lib/surrogate-pairs.js":
/*!***********************************************************!*\
  !*** ./node_modules/html-entities/lib/surrogate-pairs.js ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("Object.defineProperty(exports,\"__esModule\",{value:true});exports.fromCodePoint=String.fromCodePoint||function(astralCodePoint){return String.fromCharCode(Math.floor((astralCodePoint-65536)/1024)+55296,(astralCodePoint-65536)%1024+56320)};exports.getCodePoint=String.prototype.codePointAt?function(input,position){return input.codePointAt(position)}:function(input,position){return(input.charCodeAt(position)-55296)*1024+input.charCodeAt(position+1)-56320+65536};exports.highSurrogateFrom=55296;exports.highSurrogateTo=56319;\n\n//# sourceURL=webpack:///./node_modules/html-entities/lib/surrogate-pairs.js?");

/***/ }),

/***/ "./node_modules/webpack-hot-middleware/client-overlay.js":
/*!**************************************************!*\
  !*** (webpack)-hot-middleware/client-overlay.js ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("/*eslint-env browser*/\n\nvar clientOverlay = document.createElement('div');\nclientOverlay.id = 'webpack-hot-middleware-clientOverlay';\nvar styles = {\n  background: 'rgba(0,0,0,0.85)',\n  color: '#e8e8e8',\n  lineHeight: '1.6',\n  whiteSpace: 'pre',\n  fontFamily: 'Menlo, Consolas, monospace',\n  fontSize: '13px',\n  position: 'fixed',\n  zIndex: 9999,\n  padding: '10px',\n  left: 0,\n  right: 0,\n  top: 0,\n  bottom: 0,\n  overflow: 'auto',\n  dir: 'ltr',\n  textAlign: 'left',\n};\n\nvar ansiHTML = __webpack_require__(/*! ansi-html-community */ \"./node_modules/ansi-html-community/index.js\");\nvar colors = {\n  reset: ['transparent', 'transparent'],\n  black: '181818',\n  red: 'ff3348',\n  green: '3fff4f',\n  yellow: 'ffd30e',\n  blue: '169be0',\n  magenta: 'f840b7',\n  cyan: '0ad8e9',\n  lightgrey: 'ebe7e3',\n  darkgrey: '6d7891',\n};\n\nvar htmlEntities = __webpack_require__(/*! html-entities */ \"./node_modules/html-entities/lib/index.js\");\n\nfunction showProblems(type, lines) {\n  clientOverlay.innerHTML = '';\n  lines.forEach(function (msg) {\n    msg = ansiHTML(htmlEntities.encode(msg));\n    var div = document.createElement('div');\n    div.style.marginBottom = '26px';\n    div.innerHTML = problemType(type) + ' in ' + msg;\n    clientOverlay.appendChild(div);\n  });\n  if (document.body) {\n    document.body.appendChild(clientOverlay);\n  }\n}\n\nfunction clear() {\n  if (document.body && clientOverlay.parentNode) {\n    document.body.removeChild(clientOverlay);\n  }\n}\n\nfunction problemType(type) {\n  var problemColors = {\n    errors: colors.red,\n    warnings: colors.yellow,\n  };\n  var color = problemColors[type] || colors.red;\n  return (\n    '<span style=\"background-color:#' +\n    color +\n    '; color:#000000; padding:3px 6px; border-radius: 4px;\">' +\n    type.slice(0, -1).toUpperCase() +\n    '</span>'\n  );\n}\n\nmodule.exports = function (options) {\n  for (var color in options.ansiColors) {\n    if (color in colors) {\n      colors[color] = options.ansiColors[color];\n    }\n    ansiHTML.setColors(colors);\n  }\n\n  for (var style in options.overlayStyles) {\n    styles[style] = options.overlayStyles[style];\n  }\n\n  for (var key in styles) {\n    clientOverlay.style[key] = styles[key];\n  }\n\n  return {\n    showProblems: showProblems,\n    clear: clear,\n  };\n};\n\nmodule.exports.clear = clear;\nmodule.exports.showProblems = showProblems;\n\n\n//# sourceURL=webpack:///(webpack)-hot-middleware/client-overlay.js?");

/***/ }),

/***/ "./node_modules/webpack-hot-middleware/client.js?quiet=true&noInfo=true":
/*!*****************************************************************!*\
  !*** (webpack)-hot-middleware/client.js?quiet=true&noInfo=true ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("/* WEBPACK VAR INJECTION */(function(__resourceQuery, module) {/*eslint-env browser*/\n/*global __resourceQuery __webpack_public_path__*/\n\nvar options = {\n  path: '/__webpack_hmr',\n  timeout: 20 * 1000,\n  overlay: true,\n  reload: false,\n  log: true,\n  warn: true,\n  name: '',\n  autoConnect: true,\n  overlayStyles: {},\n  overlayWarnings: false,\n  ansiColors: {},\n};\nif (true) {\n  var overrides = Object.fromEntries(\n    new URLSearchParams(__resourceQuery.slice(1))\n  );\n  setOverrides(overrides);\n}\n\nif (typeof window === 'undefined') {\n  // do nothing\n} else if (typeof window.EventSource === 'undefined') {\n  console.warn(\n    \"webpack-hot-middleware's client requires EventSource to work. \" +\n      'You should include a polyfill if you want to support this browser: ' +\n      'https://developer.mozilla.org/en-US/docs/Web/API/Server-sent_events#Tools'\n  );\n} else {\n  if (options.autoConnect) {\n    connect();\n  }\n}\n\n/* istanbul ignore next */\nfunction setOptionsAndConnect(overrides) {\n  setOverrides(overrides);\n  connect();\n}\n\nfunction setOverrides(overrides) {\n  if (overrides.autoConnect)\n    options.autoConnect = overrides.autoConnect == 'true';\n  if (overrides.path) options.path = overrides.path;\n  if (overrides.timeout) options.timeout = overrides.timeout;\n  if (overrides.overlay) options.overlay = overrides.overlay !== 'false';\n  if (overrides.reload) options.reload = overrides.reload !== 'false';\n  if (overrides.noInfo && overrides.noInfo !== 'false') {\n    options.log = false;\n  }\n  if (overrides.name) {\n    options.name = overrides.name;\n  }\n  if (overrides.quiet && overrides.quiet !== 'false') {\n    options.log = false;\n    options.warn = false;\n  }\n\n  if (overrides.dynamicPublicPath) {\n    options.path = __webpack_require__.p + options.path;\n  }\n\n  if (overrides.ansiColors)\n    options.ansiColors = JSON.parse(overrides.ansiColors);\n  if (overrides.overlayStyles)\n    options.overlayStyles = JSON.parse(overrides.overlayStyles);\n\n  if (overrides.overlayWarnings) {\n    options.overlayWarnings = overrides.overlayWarnings == 'true';\n  }\n}\n\nfunction EventSourceWrapper() {\n  var source;\n  var lastActivity = new Date();\n  var listeners = [];\n\n  init();\n  var timer = setInterval(function () {\n    if (new Date() - lastActivity > options.timeout) {\n      handleDisconnect();\n    }\n  }, options.timeout / 2);\n\n  function init() {\n    source = new window.EventSource(options.path);\n    source.onopen = handleOnline;\n    source.onerror = handleDisconnect;\n    source.onmessage = handleMessage;\n  }\n\n  function handleOnline() {\n    if (options.log) console.log('[HMR] connected');\n    lastActivity = new Date();\n  }\n\n  function handleMessage(event) {\n    lastActivity = new Date();\n    for (var i = 0; i < listeners.length; i++) {\n      listeners[i](event);\n    }\n  }\n\n  function handleDisconnect() {\n    clearInterval(timer);\n    source.close();\n    setTimeout(init, options.timeout);\n  }\n\n  return {\n    addMessageListener: function (fn) {\n      listeners.push(fn);\n    },\n  };\n}\n\nfunction getEventSourceWrapper() {\n  if (!window.__whmEventSourceWrapper) {\n    window.__whmEventSourceWrapper = {};\n  }\n  if (!window.__whmEventSourceWrapper[options.path]) {\n    // cache the wrapper for other entries loaded on\n    // the same page with the same options.path\n    window.__whmEventSourceWrapper[options.path] = EventSourceWrapper();\n  }\n  return window.__whmEventSourceWrapper[options.path];\n}\n\nfunction connect() {\n  getEventSourceWrapper().addMessageListener(handleMessage);\n\n  function handleMessage(event) {\n    if (event.data == '\\uD83D\\uDC93') {\n      return;\n    }\n    try {\n      processMessage(JSON.parse(event.data));\n    } catch (ex) {\n      if (options.warn) {\n        console.warn('Invalid HMR message: ' + event.data + '\\n' + ex);\n      }\n    }\n  }\n}\n\n// the reporter needs to be a singleton on the page\n// in case the client is being used by multiple bundles\n// we only want to report once.\n// all the errors will go to all clients\nvar singletonKey = '__webpack_hot_middleware_reporter__';\nvar reporter;\nif (typeof window !== 'undefined') {\n  if (!window[singletonKey]) {\n    window[singletonKey] = createReporter();\n  }\n  reporter = window[singletonKey];\n}\n\nfunction createReporter() {\n  var strip = __webpack_require__(/*! strip-ansi */ \"./node_modules/webpack-hot-middleware/node_modules/strip-ansi/index.js\");\n\n  var overlay;\n  if (typeof document !== 'undefined' && options.overlay) {\n    overlay = __webpack_require__(/*! ./client-overlay */ \"./node_modules/webpack-hot-middleware/client-overlay.js\")({\n      ansiColors: options.ansiColors,\n      overlayStyles: options.overlayStyles,\n    });\n  }\n\n  var styles = {\n    errors: 'color: #ff0000;',\n    warnings: 'color: #999933;',\n  };\n  var previousProblems = null;\n  function log(type, obj) {\n    var newProblems = obj[type]\n      .map(function (msg) {\n        return strip(msg);\n      })\n      .join('\\n');\n    if (previousProblems == newProblems) {\n      return;\n    } else {\n      previousProblems = newProblems;\n    }\n\n    var style = styles[type];\n    var name = obj.name ? \"'\" + obj.name + \"' \" : '';\n    var title = '[HMR] bundle ' + name + 'has ' + obj[type].length + ' ' + type;\n    // NOTE: console.warn or console.error will print the stack trace\n    // which isn't helpful here, so using console.log to escape it.\n    if (console.group && console.groupEnd) {\n      console.group('%c' + title, style);\n      console.log('%c' + newProblems, style);\n      console.groupEnd();\n    } else {\n      console.log(\n        '%c' + title + '\\n\\t%c' + newProblems.replace(/\\n/g, '\\n\\t'),\n        style + 'font-weight: bold;',\n        style + 'font-weight: normal;'\n      );\n    }\n  }\n\n  return {\n    cleanProblemsCache: function () {\n      previousProblems = null;\n    },\n    problems: function (type, obj) {\n      if (options.warn) {\n        log(type, obj);\n      }\n      if (overlay) {\n        if (options.overlayWarnings || type === 'errors') {\n          overlay.showProblems(type, obj[type]);\n          return false;\n        }\n        overlay.clear();\n      }\n      return true;\n    },\n    success: function () {\n      if (overlay) overlay.clear();\n    },\n    useCustomOverlay: function (customOverlay) {\n      overlay = customOverlay;\n    },\n  };\n}\n\nvar processUpdate = __webpack_require__(/*! ./process-update */ \"./node_modules/webpack-hot-middleware/process-update.js\");\n\nvar customHandler;\nvar subscribeAllHandler;\nfunction processMessage(obj) {\n  switch (obj.action) {\n    case 'building':\n      if (options.log) {\n        console.log(\n          '[HMR] bundle ' +\n            (obj.name ? \"'\" + obj.name + \"' \" : '') +\n            'rebuilding'\n        );\n      }\n      break;\n    case 'built':\n      if (options.log) {\n        console.log(\n          '[HMR] bundle ' +\n            (obj.name ? \"'\" + obj.name + \"' \" : '') +\n            'rebuilt in ' +\n            obj.time +\n            'ms'\n        );\n      }\n    // fall through\n    case 'sync':\n      if (obj.name && options.name && obj.name !== options.name) {\n        return;\n      }\n      var applyUpdate = true;\n      if (obj.errors.length > 0) {\n        if (reporter) reporter.problems('errors', obj);\n        applyUpdate = false;\n      } else if (obj.warnings.length > 0) {\n        if (reporter) {\n          var overlayShown = reporter.problems('warnings', obj);\n          applyUpdate = overlayShown;\n        }\n      } else {\n        if (reporter) {\n          reporter.cleanProblemsCache();\n          reporter.success();\n        }\n      }\n      if (applyUpdate) {\n        processUpdate(obj.hash, obj.modules, options);\n      }\n      break;\n    default:\n      if (customHandler) {\n        customHandler(obj);\n      }\n  }\n\n  if (subscribeAllHandler) {\n    subscribeAllHandler(obj);\n  }\n}\n\nif (module) {\n  module.exports = {\n    subscribeAll: function subscribeAll(handler) {\n      subscribeAllHandler = handler;\n    },\n    subscribe: function subscribe(handler) {\n      customHandler = handler;\n    },\n    useCustomOverlay: function useCustomOverlay(customOverlay) {\n      if (reporter) reporter.useCustomOverlay(customOverlay);\n    },\n    setOptionsAndConnect: setOptionsAndConnect,\n  };\n}\n\n/* WEBPACK VAR INJECTION */}.call(this, \"?quiet=true&noInfo=true\", __webpack_require__(/*! ./../webpack/buildin/module.js */ \"./node_modules/webpack/buildin/module.js\")(module)))\n\n//# sourceURL=webpack:///(webpack)-hot-middleware/client.js?");

/***/ }),

/***/ "./node_modules/webpack-hot-middleware/node_modules/ansi-regex/index.js":
/*!*****************************************************************!*\
  !*** (webpack)-hot-middleware/node_modules/ansi-regex/index.js ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nmodule.exports = ({onlyFirst = false} = {}) => {\n\tconst pattern = [\n\t\t'[\\\\u001B\\\\u009B][[\\\\]()#;?]*(?:(?:(?:(?:;[-a-zA-Z\\\\d\\\\/#&.:=?%@~_]+)*|[a-zA-Z\\\\d]+(?:;[-a-zA-Z\\\\d\\\\/#&.:=?%@~_]*)*)?\\\\u0007)',\n\t\t'(?:(?:\\\\d{1,4}(?:;\\\\d{0,4})*)?[\\\\dA-PR-TZcf-ntqry=><~]))'\n\t].join('|');\n\n\treturn new RegExp(pattern, onlyFirst ? undefined : 'g');\n};\n\n\n//# sourceURL=webpack:///(webpack)-hot-middleware/node_modules/ansi-regex/index.js?");

/***/ }),

/***/ "./node_modules/webpack-hot-middleware/node_modules/strip-ansi/index.js":
/*!*****************************************************************!*\
  !*** (webpack)-hot-middleware/node_modules/strip-ansi/index.js ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\nconst ansiRegex = __webpack_require__(/*! ansi-regex */ \"./node_modules/webpack-hot-middleware/node_modules/ansi-regex/index.js\");\n\nmodule.exports = string => typeof string === 'string' ? string.replace(ansiRegex(), '') : string;\n\n\n//# sourceURL=webpack:///(webpack)-hot-middleware/node_modules/strip-ansi/index.js?");

/***/ }),

/***/ "./node_modules/webpack-hot-middleware/process-update.js":
/*!**************************************************!*\
  !*** (webpack)-hot-middleware/process-update.js ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("/**\n * Based heavily on https://github.com/webpack/webpack/blob/\n *  c0afdf9c6abc1dd70707c594e473802a566f7b6e/hot/only-dev-server.js\n * Original copyright Tobias Koppers @sokra (MIT license)\n */\n\n/* global window __webpack_hash__ */\n\nif (false) {}\n\nvar hmrDocsUrl = 'https://webpack.js.org/concepts/hot-module-replacement/'; // eslint-disable-line max-len\n\nvar lastHash;\nvar failureStatuses = { abort: 1, fail: 1 };\nvar applyOptions = {\n  ignoreUnaccepted: true,\n  ignoreDeclined: true,\n  ignoreErrored: true,\n  onUnaccepted: function (data) {\n    console.warn(\n      'Ignored an update to unaccepted module ' + data.chain.join(' -> ')\n    );\n  },\n  onDeclined: function (data) {\n    console.warn(\n      'Ignored an update to declined module ' + data.chain.join(' -> ')\n    );\n  },\n  onErrored: function (data) {\n    console.error(data.error);\n    console.warn(\n      'Ignored an error while updating module ' +\n        data.moduleId +\n        ' (' +\n        data.type +\n        ')'\n    );\n  },\n};\n\nfunction upToDate(hash) {\n  if (hash) lastHash = hash;\n  return lastHash == __webpack_require__.h();\n}\n\nmodule.exports = function (hash, moduleMap, options) {\n  var reload = options.reload;\n  if (!upToDate(hash) && module.hot.status() == 'idle') {\n    if (options.log) console.log('[HMR] Checking for updates on the server...');\n    check();\n  }\n\n  function check() {\n    var cb = function (err, updatedModules) {\n      if (err) return handleError(err);\n\n      if (!updatedModules) {\n        if (options.warn) {\n          console.warn('[HMR] Cannot find update (Full reload needed)');\n          console.warn('[HMR] (Probably because of restarting the server)');\n        }\n        performReload();\n        return null;\n      }\n\n      var applyCallback = function (applyErr, renewedModules) {\n        if (applyErr) return handleError(applyErr);\n\n        if (!upToDate()) check();\n\n        logUpdates(updatedModules, renewedModules);\n      };\n\n      var applyResult = module.hot.apply(applyOptions, applyCallback);\n      // webpack 2 promise\n      if (applyResult && applyResult.then) {\n        // HotModuleReplacement.runtime.js refers to the result as `outdatedModules`\n        applyResult.then(function (outdatedModules) {\n          applyCallback(null, outdatedModules);\n        });\n        applyResult.catch(applyCallback);\n      }\n    };\n\n    var result = module.hot.check(false, cb);\n    // webpack 2 promise\n    if (result && result.then) {\n      result.then(function (updatedModules) {\n        cb(null, updatedModules);\n      });\n      result.catch(cb);\n    }\n  }\n\n  function logUpdates(updatedModules, renewedModules) {\n    var unacceptedModules = updatedModules.filter(function (moduleId) {\n      return renewedModules && renewedModules.indexOf(moduleId) < 0;\n    });\n\n    if (unacceptedModules.length > 0) {\n      if (options.warn) {\n        console.warn(\n          \"[HMR] The following modules couldn't be hot updated: \" +\n            '(Full reload needed)\\n' +\n            'This is usually because the modules which have changed ' +\n            '(and their parents) do not know how to hot reload themselves. ' +\n            'See ' +\n            hmrDocsUrl +\n            ' for more details.'\n        );\n        unacceptedModules.forEach(function (moduleId) {\n          console.warn('[HMR]  - ' + (moduleMap[moduleId] || moduleId));\n        });\n      }\n      performReload();\n      return;\n    }\n\n    if (options.log) {\n      if (!renewedModules || renewedModules.length === 0) {\n        console.log('[HMR] Nothing hot updated.');\n      } else {\n        console.log('[HMR] Updated modules:');\n        renewedModules.forEach(function (moduleId) {\n          console.log('[HMR]  - ' + (moduleMap[moduleId] || moduleId));\n        });\n      }\n\n      if (upToDate()) {\n        console.log('[HMR] App is up to date.');\n      }\n    }\n  }\n\n  function handleError(err) {\n    if (module.hot.status() in failureStatuses) {\n      if (options.warn) {\n        console.warn('[HMR] Cannot check for update (Full reload needed)');\n        console.warn('[HMR] ' + (err.stack || err.message));\n      }\n      performReload();\n      return;\n    }\n    if (options.warn) {\n      console.warn('[HMR] Update check failed: ' + (err.stack || err.message));\n    }\n  }\n\n  function performReload() {\n    if (reload) {\n      if (options.warn) console.warn('[HMR] Reloading page');\n      window.location.reload();\n    }\n  }\n};\n\n\n//# sourceURL=webpack:///(webpack)-hot-middleware/process-update.js?");

/***/ }),

/***/ "./node_modules/webpack/buildin/global.js":
/*!***********************************!*\
  !*** (webpack)/buildin/global.js ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("var g;\n\n// This works in non-strict mode\ng = (function() {\n\treturn this;\n})();\n\ntry {\n\t// This works if eval is allowed (see CSP)\n\tg = g || new Function(\"return this\")();\n} catch (e) {\n\t// This works if the window reference is available\n\tif (typeof window === \"object\") g = window;\n}\n\n// g can still be undefined, but nothing to do about it...\n// We return undefined, instead of nothing here, so it's\n// easier to handle this case. if(!global) { ...}\n\nmodule.exports = g;\n\n\n//# sourceURL=webpack:///(webpack)/buildin/global.js?");

/***/ }),

/***/ "./node_modules/webpack/buildin/module.js":
/*!***********************************!*\
  !*** (webpack)/buildin/module.js ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("module.exports = function(module) {\n\tif (!module.webpackPolyfill) {\n\t\tmodule.deprecate = function() {};\n\t\tmodule.paths = [];\n\t\t// module.parent = undefined by default\n\t\tif (!module.children) module.children = [];\n\t\tObject.defineProperty(module, \"loaded\", {\n\t\t\tenumerable: true,\n\t\t\tget: function() {\n\t\t\t\treturn module.l;\n\t\t\t}\n\t\t});\n\t\tObject.defineProperty(module, \"id\", {\n\t\t\tenumerable: true,\n\t\t\tget: function() {\n\t\t\t\treturn module.i;\n\t\t\t}\n\t\t});\n\t\tmodule.webpackPolyfill = 1;\n\t}\n\treturn module;\n};\n\n\n//# sourceURL=webpack:///(webpack)/buildin/module.js?");

/***/ }),

/***/ "./src/assets/js/index.js":
/*!********************************!*\
  !*** ./src/assets/js/index.js ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("/* WEBPACK VAR INJECTION */(function(global) {function _typeof(obj) { \"@babel/helpers - typeof\"; return _typeof = \"function\" == typeof Symbol && \"symbol\" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && \"function\" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? \"symbol\" : typeof obj; }, _typeof(obj); }\nfunction _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if (\"value\" in descriptor) descriptor.writable = true; Object.defineProperty(target, _toPropertyKey(descriptor.key), descriptor); } }\nfunction _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, \"prototype\", { writable: false }); return Constructor; }\nfunction _toPropertyKey(arg) { var key = _toPrimitive(arg, \"string\"); return _typeof(key) === \"symbol\" ? key : String(key); }\nfunction _toPrimitive(input, hint) { if (_typeof(input) !== \"object\" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || \"default\"); if (_typeof(res) !== \"object\") return res; throw new TypeError(\"@@toPrimitive must return a primitive value.\"); } return (hint === \"string\" ? String : Number)(input); }\nfunction _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError(\"Cannot call a class as a function\"); } }\n// import { gsap } from 'gsap';\n// import { ScrollToPlugin } from 'gsap/ScrollToPlugin.js';\n// gsap.registerPlugin(ScrollToPlugin);\n// global.gsap = gsap;\n// gsap.defaults({\n// \toverwrite: 'auto',\n// });\nvar ProjectApp = /*#__PURE__*/_createClass(function ProjectApp() {\n  _classCallCheck(this, ProjectApp);\n  this.env = __webpack_require__(/*! ./utils/env */ \"./src/assets/js/utils/env.js\")[\"default\"];\n  this.utils = __webpack_require__(/*! ./utils/utils */ \"./src/assets/js/utils/utils.js\")[\"default\"];\n  this.classes = {\n    // Signal: require('./classes/Signal').default,\n  };\n  this.components = {};\n  this.helpers = {};\n  this.modules = {};\n  document.addEventListener('DOMContentLoaded', function () {\n    function cart() {\n      function updateTotal() {\n        var cartItems = document.querySelectorAll('.cart-right__item');\n        var subtotalPriceEl = document.querySelector('.subtotal-price');\n        var shippingEl = document.querySelector('.shipping-price');\n        var taxEl = document.querySelector('.tax-price');\n        var totalPriceEl = document.querySelector('.total-price');\n        var subtotalPrice = 0;\n        cartItems.forEach(function (item) {\n          var itemAmount = item.querySelector('.counter__input');\n          var itemPrice = item.querySelector('.cart-item__price span');\n          var currentPrice = +itemAmount.value * +itemPrice.innerText;\n          subtotalPrice += currentPrice;\n        });\n        subtotalPriceEl.textContent = subtotalPrice;\n        totalPriceEl.textContent = +shippingEl.innerText + +taxEl.innerText + subtotalPrice;\n        if (!cartItems.length) {\n          shippingEl.innerText = 0;\n          taxEl.innerText = 0;\n          subtotalPriceEl.innerText = 0;\n          totalPriceEl.innerText = 0;\n        }\n      }\n      function updateCartItemsCount() {\n        var cartItems = document.querySelectorAll('.cart-right__item');\n        var cartCount = document.querySelector('.cart-btn .count');\n        cartCount.innerText = cartItems.length;\n      }\n      function changeAmountItem() {\n        document.querySelector('.cart-right').addEventListener('click', function (e) {\n          if (e.target.classList.contains('counter__btn--increment') || e.target.classList.contains('counter__btn--decrement')) {\n            if (e.target.classList.contains('counter__btn--increment')) {\n              var counter = e.target.closest('.counter');\n              +counter.querySelector('.counter__input').value++;\n            }\n            if (e.target.classList.contains('counter__btn--decrement')) {\n              var _counter = e.target.closest('.counter');\n              +_counter.querySelector('.counter__input').value--;\n              if (e.target.closest('.cart-right__list') && _counter.querySelector('.counter__input').value < 1) {\n                e.target.closest('.cart-right__item').remove();\n                updateCartItemsCount();\n              }\n            }\n          }\n          if (e.target.classList.contains('cart-item__remove')) {\n            e.target.closest('.cart-right__item').remove();\n            updateTotal();\n            updateCartItemsCount();\n          }\n          if (e.target.classList.contains('counter__btn')) {\n            updateTotal();\n          }\n        });\n      }\n      changeAmountItem();\n      (function showMenu() {\n        if (window.matchMedia('(max-width: 991px)').matches) {\n          var menuBtn = document.querySelector('.cart-btn');\n          var menu = document.querySelector('.cart-right');\n          var body = document.querySelector('body');\n          if (menuBtn && menu) {\n            menuBtn.addEventListener('click', function (e) {\n              menu.classList.toggle('active');\n              body.classList.toggle('no-scroll');\n              menuBtn.classList.toggle('active');\n            });\n          }\n        }\n      })();\n    }\n    cart();\n  });\n}); // class Cart {\n// \tconstructor(name) {\n// \t\t// alert('aaaa');\n// \t\tthis.name = name;\n// \t}\n// \t// changeAmountItem() {\n// \t// \talert('aaa');\n// \t// \tdocument.querySelector('.cart-right').addEventListener('click', e => {\n// \t// \t\tif (\n// \t// \t\t\te.target.classList.contains('counter__btn--increment') ||\n// \t// \t\t\te.target.classList.contains('counter__btn--decrement')\n// \t// \t\t) {\n// \t// \t\t\tif (e.target.classList.contains('counter__btn--increment')) {\n// \t// \t\t\t\tconst counter = e.target.closest('.counter');\n// \t// \t\t\t\t+counter.querySelector('.counter__input').value++;\n// \t// \t\t\t}\n// \t// \t\t\tif (e.target.classList.contains('counter__btn--decrement')) {\n// \t// \t\t\t\tconst counter = e.target.closest('.counter');\n// \t// \t\t\t\t+counter.querySelector('.counter__input').value--;\n// \t// \t\t\t\tif (\n// \t// \t\t\t\t\te.target.closest('.cart-right__list') &&\n// \t// \t\t\t\t\tcounter.querySelector('.counter__input').value < 1\n// \t// \t\t\t\t) {\n// \t// \t\t\t\t\te.target.closest('.cart-right__item').remove();\n// \t// \t\t\t\t\t// updateCartItemsCount();\n// \t// \t\t\t\t}\n// \t// \t\t\t}\n// \t// \t\t}\n// \t// \t\tif (e.target.classList.contains('cart-item__remove')) {\n// \t// \t\t\te.target.closest('.cart-right__item').remove();\n// \t// \t\t\t// updateTotal();\n// \t// \t\t\t// updateCartItemsCount();\n// \t// \t\t}\n// \t// \t\tif (e.target.classList.contains('counter__btn')) {\n// \t// \t\t\t// updateTotal();\n// \t// \t\t}\n// \t// \t});\n// \t// }\n// }\nglobal.ProjectApp = new ProjectApp();\n// global.Cart = new Cart();\n\nif (true) {\n  module.hot.accept();\n}\n/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/webpack/buildin/global.js */ \"./node_modules/webpack/buildin/global.js\")))\n\n//# sourceURL=webpack:///./src/assets/js/index.js?");

/***/ }),

/***/ "./src/assets/js/utils/env.js":
/*!************************************!*\
  !*** ./src/assets/js/utils/env.js ***!
  \************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\nvar envObject = window.environmentObject;\nvar env = {\n  // Platform\n  isMobile: envObject.platform === '_mobile',\n  isDesktop: envObject.platform === '_desktop',\n  // OS\n  isMac: envObject.os === '_mac',\n  isWin: envObject.os === '_win',\n  isLinux: envObject.os === '_linux',\n  isAndroid: envObject.os === '_android',\n  isIOS: envObject.os === '_ios',\n  // Browsers\n  isFF: envObject.browser === '_ff',\n  isOpera: envObject.browser === '_opera',\n  isYandex: envObject.browser === '_yandex',\n  isIE: envObject.browser === '_ie',\n  isEdge: envObject.browser === '_edge',\n  isChrome: envObject.browser === '_chrome',\n  isSafari: envObject.browser === '_safari',\n  // Dev environment\n  isLocal: envObject.isLocal\n};\nwindow.environmentObject = null;\ndelete window.environmentObject;\n/* harmony default export */ __webpack_exports__[\"default\"] = (env);\n\n//# sourceURL=webpack:///./src/assets/js/utils/env.js?");

/***/ }),

/***/ "./src/assets/js/utils/utils.js":
/*!**************************************!*\
  !*** ./src/assets/js/utils/utils.js ***!
  \**************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\nvar utils = {\n  now: function now() {\n    if (window.performance && window.performance.now) {\n      this.now = function () {\n        return window.performance.now();\n      };\n    } else {\n      this.now = function () {\n        return +new Date();\n      };\n    }\n    return this.now();\n  },\n  cubicProgress: function cubicProgress(value) {\n    value = value < 0 ? 0 : value;\n    value = value > 1 ? 1 : value;\n    value /= 1 / 2;\n    if (value < 1) {\n      return 1 / 2 * value * value * value;\n    }\n    value -= 2;\n    return 1 / 2 * (value * value * value + 2);\n  },\n  debounce: function debounce(func) {\n    var wait = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 100;\n    var immediate = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;\n    var timeout;\n    return function () {\n      var context = this;\n      var args = arguments;\n      var later = function later() {\n        timeout = null;\n        !immediate && func.apply(context, args);\n      };\n      var callNow = immediate && !timeout;\n      clearTimeout(timeout);\n      timeout = setTimeout(later, wait);\n      callNow && func.apply(context, args);\n    };\n  },\n  throttle: function throttle(func) {\n    var wait = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 100;\n    var isThrottled = false;\n    var savedArgs;\n    var savedThis;\n    function wrapper() {\n      if (isThrottled) {\n        savedArgs = arguments;\n        savedThis = this;\n      } else {\n        func.apply(this, arguments);\n        isThrottled = true;\n        setTimeout(function () {\n          isThrottled = false;\n          if (savedArgs) {\n            wrapper.apply(savedThis, savedArgs);\n            savedArgs = savedThis = null;\n          }\n        }, wait);\n      }\n    }\n    return wrapper;\n  },\n  formatNumber: function formatNumber(number) {\n    number = number.toString();\n    var result = '';\n    for (var k = number.length - 1, c = 0; k >= 0; k--, c++) {\n      if (c === 3) {\n        c = 0;\n        result = number.substr(k, 1) + ' ' + result;\n      } else {\n        result = number.substr(k, 1) + result;\n      }\n    }\n    return result;\n  },\n  declOfNum: function declOfNum(number, titles) {\n    var cases = [2, 0, 1, 1, 1, 2];\n    return titles[number % 100 > 4 && number % 100 < 20 ? 2 : cases[number % 10 < 5 ? number % 10 : 5]];\n  }\n};\n/* harmony default export */ __webpack_exports__[\"default\"] = (utils);\n\n//# sourceURL=webpack:///./src/assets/js/utils/utils.js?");

/***/ }),

/***/ 0:
/*!*******************************************************************************************!*\
  !*** multi ./src/assets/js/index.js webpack-hot-middleware/client?quiet=true&noInfo=true ***!
  \*******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("__webpack_require__(/*! C:\\Users\\vital\\Desktop\\testovoe\\src\\assets\\js\\index.js */\"./src/assets/js/index.js\");\nmodule.exports = __webpack_require__(/*! webpack-hot-middleware/client?quiet=true&noInfo=true */\"./node_modules/webpack-hot-middleware/client.js?quiet=true&noInfo=true\");\n\n\n//# sourceURL=webpack:///multi_./src/assets/js/index.js_webpack-hot-middleware/client?");

/***/ })

/******/ });